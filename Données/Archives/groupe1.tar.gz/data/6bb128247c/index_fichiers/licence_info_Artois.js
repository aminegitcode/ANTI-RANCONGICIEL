addMaquette({
    "FORMATION": {
        "NOM": "Licence Informatique Artois 2024/25",
        "ETABLISSEMENT": "Université d'Artois",
        "ANNEES": "2024/25",
        "NB_SEMESTRES": 6,
        "LMD": "L",
        "PARCOURS": [],
        "M3C": [],
        "BLOCS": [
            {
                "NOM": "C1",
                "DESCRIPTION": "Elaborer une modélisation numérique d'un problème et de ses données",
                "ID": "C1"
            },
            {
                "NOM": "C2",
                "DESCRIPTION": "Développer une solution informatique",
                "ID": "C2"
            },
            {
                "NOM": "C3",
                "DESCRIPTION": "Administrer une infrastructure informatique",
                "ID": "C3"
            },
            {
                "NOM": "C4",
                "DESCRIPTION": "Mettre en œuvre un projet",
                "ID": "C4"
            },
            {
                "NOM": "C5",
                "DESCRIPTION": "Construire son projet professionnel",
                "ID": "C5"
            }
        ],
        "RESPONSABLES": [],
        "PRESENTATION": []
    },
    "MODULES": [
        {
            "SEMESTRE": 1,
            "ID": "1.1",
            "TITRE": "CALCULUS 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Calculs de sommes",
                "Dérivées",
                "Intégrales (aspect pratique : primitives, intégrations par parties, changements de variables)"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "1.2",
            "TITRE": "METHODES ET OUTILS POUR LES MATHEMATIQUES ET L'INFORMATIQUE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Notions de logique et vocabulaire ensembliste",
                "Arithmétique des entiers",
                "Nombres complexes"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "1.3",
            "TITRE": "CHIMIE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1",
                    "CHOIX": [
                        3,
                        [
                            "1.3",
                            "1.4"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "L'atome (constituants, masse atomique)",
                "Structure électronique des éléments",
                "Le tableau périodique des éléments (historique, règles de construction, identification et propriétés chimiques des blocs)",
                "Tableau périodique et propriétés atomiques",
                "Métaux alcalins et alcalino terreux, halogènes, chalcogènes : évolution des propriétés physico chimiques",
                "Les étudiants seront amenés à réaliser un tableau périodique interactif en Python, langage abordé dans l'unité Algorithmique et Programmation 1",
                "Savoir utiliser le tableau périodique",
                "Décrire les propriétés des éléments par familles et par périodes pour expliquer les structures",
                "Acquérir les notions élémentaires de chimie",
                "Programmation Python et utilisation de l’interface graphique Pygame"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "1.4",
            "TITRE": "PHYSIQUE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1",
                    "CHOIX": [
                        3,
                        [
                            "1.3",
                            "1.4"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "1.5",
            "TITRE": "ALGORITHMIQUE ET PROGRAMMATION 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 7,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Notions de variables et de constantes",
                "Séquence",
                "Instructions conditionnelles",
                "Instructions itératives",
                "Fonctions",
                "Types composés: listes, tuples et dictionnaires",
                "Les dernières semaines, en travaux pratiques, les étudiants sont guidés dans la réalisation d'un jeu graphique mettant en oeuvre tous les concepts abordés"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "1.6",
            "TITRE": "INITIATION RESEAU",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Ce module présente les bases du fonctionnement des réseaux informatiques, et plus spécifiquement le fonctionnement des protocoles TCP et IP en se focalisant sur les concepts (fonctionnalités des différentes couches, des différents matériels) plus que sur les détails (algorithmes de routages, contenu des trames)",
                "Le cours se base sur des exemples de la vie courante, comme par exemple la mise en place et la sécurisation d'un réseau personnel à son domicile derrière une « box »",
                "Comprendre les bases du cheminement de l'information dans un réseau informatique",
                "Comprendre les enjeux d'un monde connecté",
                "Être capable de créer/configurer un réseau local (derrière une « box » par exemple)"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "1.7",
            "TITRE": "RESEAU-WEB 1",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "1.8",
            "TITRE": "ANGLAIS 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "1.9",
            "TITRE": "PPE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.1",
            "TITRE": "ALGEBRE LINEAIRE 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Espaces vectoriels, applications linéaires, matrices"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.2",
            "TITRE": "INITIATION WEB",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "HTML : éléments, balises, attributs, structure, indentation et commentaires, titres et paragraphes, listes, liens internes et externes, images",
                "CSS : sélecteurs, propriétés, mise en forme, id et class, héritage",
                "Produire du code HTML et CSS valide",
                "Maîtriser la distinction structuration/affichage de l'information"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.3",
            "TITRE": "RESEAU-WEB 2",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.4",
            "TITRE": "ALGORITHMIQUE ET PROGRAMMATION 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Dans cette unité, les étudiants vont affermir leur capacité à écrire des fonctions simples utilisant les structures de données classiques (listes, tuples, dictionnaires), mais vont aussi aborder la programmation objet avec la notion de classe",
                "Ils étudieront également des structures de données classiques comme les piles, les files, et les listes chaînées, avec une première approche de la récursivité",
                "Une nouvelle librairie graphique sera utilisée (tkinter), et la programmation événementielle sera ainsi étudiée dans le cadre d'un projet"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.5",
            "TITRE": "PROJET ALGO",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.6",
            "TITRE": "PF1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.7",
            "TITRE": "BIOLOGIE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2",
                    "CHOIX": [
                        3,
                        [
                            "2.7",
                            "2.8"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Généralités sur le monde du vivant",
                "La cellule",
                "Réplication, transcription, traduction",
                "Structure et propriétés des protéines",
                "Génétique et hérédité",
                "Initiation à la bioinformatique"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.8",
            "TITRE": "DECISION DE GROUPE ET THEORIE DU VOTE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2",
                    "CHOIX": [
                        3,
                        [
                            "2.7",
                            "2.8"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Cette unité permet d'illustrer l'utilité des mathématiques pour la modélisation de l'économie et pour la philosophie politique. Nous discutons de la formalisation et de l'étude des procédures de vote et de décision de groupe. Nous montrons les difficultés inhérentes à la décision de groupe, en particulier qu'il n'existe pas de méthode de vote parfaite Cette unité permet d'expliquer les procédures de vote, et leurs possibilités de manipulation, et donc de mieux comprendre le comportement de ces méthodes au coeur du fonctionnement de nos démocraties, et leurs potentielles instrumentalisations.",
                "Découvrir et comprendre les principales méthodes de vote",
                "Formaliser la problématique du vote",
                "Comprendre le théorème d’Arrow et sa démonstration",
                "Comprendre les différentes possibilités de manipulation",
                "Modéliser les indices de pouvoir et des problèmes de partage"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.9",
            "TITRE": "ARCHITECTURE 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Les systèmes de numérations dans des bases binaires, octales et hexadécimales",
                "Description des méthodes de conversions des nombres écrits dans différentes base",
                "Les opérations arithmétiques (addition, soustraction, division, multiplication) dans les systèmes binaire et hexadécimal",
                "La représentation des nombres négatifs (compléments à 1 et compléments à 2)",
                "La représentation des nombres réelles en binaire avec une présentation détaillée de la norme IEEE754",
                "Une introduction aux circuits logiques combinatoires",
                "Simplifications de circuits logiques et tableaux de Karnaugh",
                "Une introduction aux circuits logiques séquentielles et les bascules"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.10",
            "TITRE": "ANGLAIS 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "3.1",
            "TITRE": "STATISTIQUES POUR L'INFORMATIQUE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "3.2",
            "TITRE": "ALGORITHMIQUE ET PROGRAMMATION 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Complexité (complexité en meilleur et pire cas, ordres de grandeur)",
                "Récursivité (récursivité terminale)",
                "Tris (tri fusion, tri rapide)",
                "Listes Chaînées",
                "Arbre Binaire (parcours en profondeur, parcours en largeur,..)",
                "Arbre Binaire de Recherche (Ajout, suppression, tri par arbre)",
                "File de priorité, Tas",
                "Compression de données (Algorithme de Huffman)",
                "Initiation aux graphes"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "3.3",
            "TITRE": "LANGAGE C",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Les types de bases et les variables",
                "Les entrées/sorties",
                "Les instructions conditionnelles et les itérations",
                "Les pointeurs",
                "Les fonctions",
                "Allocations dynamiques",
                "Tableaux à une dimension",
                "Tableaux à deux dimensions",
                "Les chaînes de caractères",
                "Les structures d’enregistrement simples et récursives",
                "Les listes chaînées",
                "Ce cours s'appuie sur la norme C ANSI"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "3.4",
            "TITRE": "PROGRAMMATION WEB 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Javascript : types primitifs, expressions et opérateurs, objets et tableaux, héritage par prototype et classes, interaction avec le DOM et les CSS, gestion d’événements, éléments de programmation fonctionnelle en JavaScript",
                "Les dernières semaines, en travaux pratiques, les étudiants sont guidés dans la réalisation d'un projet qui met en oeuvre les principaux éléments du langage",
                "Etre capable de traiter des problèmes algorithmiques avec le langage",
                "Savoir mofifier une page HTML via le DOM et interagir dynamiquement avec l'utilisateur via la programmation événementielle et fonctionnelle",
                "Fournir un code sûr respectant les bonnes pratiques pour ce langage"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "3.5",
            "TITRE": "UNIX",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Commandes UNIX"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "3.6",
            "TITRE": "PROJET ALGO 3",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C4"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "3.7",
            "TITRE": "PROGRAMMATION WEB 1",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C4"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "3.8",
            "TITRE": "ANGLAIS 3",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "3.9",
            "TITRE": "CPP-CTR",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [
                "Construction du Projet Professionnel de l’étudiant – Communication et Techniques de recrutement",
                "Réfléchir sur son avenir professionnel",
                "Découvrir le monde professionnel",
                "Préparer sa recherche d’emploi"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "4.1",
            "TITRE": "ALGORITHMIQUE ET PROGRAMMATION 4",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "4.2",
            "TITRE": "PROGRAMMATION ORIENTEE OBJET",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 7,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Présentation de Java",
                "Le paradigme objet (Classes, Objets, Héritage)",
                "L’essentiel du langage Java (variables, opérateurs, commandes basiques)",
                "Interfaces et heritage",
                "Nombres et Chaînes de caractères",
                "Paquetages",
                "E/S basique",
                "Exceptions",
                "Généricité",
                "Collections (listes, dictionnaires, ...)",
                "Interface graphique"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "4.3",
            "TITRE": "BASES DE DONNEES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Notions basiques (tables, identifiants, clés étrangères, contraintes d'intégrité)",
                "Modèle entité-association",
                "Modèle relationnel",
                "Langage SQL (LDD, LMD)",
                "Normalisation"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "4.4",
            "TITRE": "ARCHITECTURE 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "4.5",
            "TITRE": "PROJET ALGO 4",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "C4"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "4.6",
            "TITRE": "PROJET BD",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C4"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "4.7",
            "TITRE": "ANGLAIS 4",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "4.8",
            "TITRE": "CPP-CTR",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [
                "Construction du Projet Professionnel de l’étudiant – Communication et Techniques de recrutement"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "5.1",
            "TITRE": "THEORIE DES LANGAGES ET COMPILATION",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 7,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "En théorie des langages seront étudiés les formalismes qui permettent de définir la syntaxe des langages informatiques : langages réguliers (automates et expressions régulières), langages hors-contexte (grammaires hors-contexte)",
                "La partie compilation du cours présente les techniques classiques en compilation, en particulier l'analyse lexicale, syntaxique, sémantique et la génération de code",
                "Les outils UNIX Lex et Yacc seront introduits et utilisés en TP pour mettre en œuvre les étapes essentielles de développement de compilateurs"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "5.2",
            "TITRE": "OUTILS LOGIQUES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Ensembles",
                "Relations, fonctions et applications",
                "Relations d'ordre et treillis",
                "Récursion et induction",
                "Graphes",
                "Modéliser des situations",
                "Abstraire des objets dans le but de raisonner et étudier les propriétés des entités manipulées"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "5.3",
            "TITRE": "ALGORITHMIQUE ET PROGRAMMATION 5",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Rappels de complexité et d’outils d’analyse d’algorithmes (itératifs et récursifs)",
                "Transformations d’algorithmes récursifs en algorithmes itératifs",
                "Arbres (arbres binaires, arbres binaires de recherche, arbres équilibrés (AVL, arbre 2-3-4 et arbres rouges et noirs)",
                "Théorie des graphes (parcours, numérotation et descendance, connexité et forte connexité, graphes sans circuits, plus courts chemins, ...)"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "5.4",
            "TITRE": "C AVANCE ET C++",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 7,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "5.5",
            "TITRE": "PROGRAMMATION SHELL",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "5.6",
            "TITRE": "PROJET SHELL",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "C4"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "5.7",
            "TITRE": "ANGLAIS 5",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "6.1",
            "TITRE": "CONCEPTION ORIENTEE OBJET",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "6.2",
            "TITRE": "PROGRAMMATION WEB 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "PHP : classes et interfaces, traits, itérateurs, gestion des erreurs et des exceptions, type hinting, accès à un SGBD et à des services distants, sécurité",
                "La partie JavaScript se focalisera sur les requêtes distantes asynchrones",
                "Les dernières semaines, en travaux pratiques, les étudiants sont guidés dans la réalisation d'une application 3-tiers (sous forme de projet)",
                "Concevoir et mettre en place d'une application (au moins) 3-tiers faisant intervenir différentes technologies et langages",
                "Fournir un code sûr respectant les bonnes pratiques pour ces langages"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "6.3",
            "TITRE": "LAMBDA-CALCUL ET PROGRAMMATION FONCTIONNELLE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Programmer avec des fonctions",
                "Types",
                "Récursivité",
                "Schéma de programmes",
                "Lambda calcul"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "6.4",
            "TITRE": "ARCHITECTURE 3",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "6.5",
            "TITRE": "MULTI-TIERS",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "C4"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "6.6",
            "TITRE": "TECHNOLOGIES EMERGENTES",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C4"
                }
            ],
            "CONTENU": [
                "Internet des objets et objets connectés",
                "L'objectif du cours est d'acquérir des connaissances et des compétences nécessaires pour concevoir et construire un prototype IoT simple comprenant des capteurs, un dispositif de connectivité, une application mobile et des capacités d'analyse et de visualisation de données",
                "Comprendre les définitions et utilisations du terme «Internet des objets et objets connectés» dans différents contextes et domaines",
                "Connaître les technologies liées à l’IoT (Capteurs, Cloud, mobile, Big data, analytique, ...)"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "6.7",
            "TITRE": "ANGLAIS 6",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "6.8",
            "TITRE": "STAGE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        }
    ]
})