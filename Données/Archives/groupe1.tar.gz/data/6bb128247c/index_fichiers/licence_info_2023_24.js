addMaquette({
    "FORMATION": {
        "NOM": "Licence Informatique 2023/24",
        "ETABLISSEMENT": "Université de Picardie - Jules Verne",
        "ANNEES": "2023/24",
        "NB_SEMESTRES": 6,
        "LMD": "L",
        "PARCOURS": [
            {
                "ID": "PAR_1",
                "NOM": "portail MATH",
                "DESCRIPTION": "Permet la réorientation en L2 Maths",
                "ANNEES": [
                    1
                ]
            },
            {
                "ID": "PAR_2",
                "NOM": "portail SPI",
                "DESCRIPTION": "Permet la réorientation en L2 Sciences Pour l'Ingénieur",
                "ANNEES": [
                    1
                ]
            },
            {
                "ID": "PAR_5",
                "NOM": "orientation DEVELOPPEMENT-GESTION",
                "DESCRIPTION": "",
                "ANNEES": [
                    2
                ]
            },
            {
                "ID": "PAR_6",
                "NOM": "orientation INFORMATIQUE",
                "DESCRIPTION": "",
                "ANNEES": [
                    2
                ]
            },
            {
                "ID": "PAR_3",
                "NOM": "parcours INFO",
                "DESCRIPTION": "",
                "ANNEES": [
                    3
                ]
            },
            {
                "ID": "PAR_4",
                "NOM": "parcours MIAGE",
                "DESCRIPTION": "Méthodes Informatiques Appliquées à la Gestion des Entreprises",
                "ANNEES": [
                    3
                ]
            }
        ],
        "M3C": [
            "Un module est validé si sa note est supérieure ou égale à 10",
            "Un bloc de compétences est validé si la moyenne pondérée des modules du bloc est supérieure ou égale à 10",
            "Si un bloc de compétence est validé, tous les modules du bloc le sont et ne peuvent être repassés",
            "Une année est validée si tous les blocs de compétences de l'année le sont ou si la moyenne pondérée des blocs est supérieure ou égale à 10 avec au moins 8 dans chaque bloc",
            "Un étudiant est AJAC (ajourné autorisé à continuer) s'il n'a pas validé son année mais a validé au moins 45 ECTS",
            "La licence est obtenue quand les 3 années sont validées"
        ],
        "BLOCS": [
            {
                "NOM": "C1",
                "DESCRIPTION": "Elaborer une modélisation numérique d'un problème et de ses données",
                "ID": "COMP_1"
            },
            {
                "NOM": "C2",
                "DESCRIPTION": "Développer une solution informatique",
                "ID": "COMP_2"
            },
            {
                "NOM": "C3",
                "DESCRIPTION": "Administrer une infrastructure informatique",
                "ID": "COMP_3"
            },
            {
                "NOM": "C4",
                "DESCRIPTION": "Mettre en œuvre un projet",
                "ID": "COMP_4"
            },
            {
                "NOM": "CT",
                "DESCRIPTION": "Construire son projet professionnel",
                "ID": "CT"
            },
            {
                "NOM": "C5",
                "DESCRIPTION": "Accompagner le fonctionnement d'une entreprise",
                "ID": "COMP_5"
            }
        ],
        "RESPONSABLES": [],
        "PRESENTATION": []
    },
    "MODULES": [
        {
            "SEMESTRE": 1,
            "ID": "REBAP01",
            "TITRE": "BASES DE PROGRAMMATION",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "COMP_2"
                }
            ],
            "CONTENU": [
                "Algorithmique : notion de problème (données, résultats) et d'algorithmes pour le résoudre",
                "Structure de données (tableau à plusieurs dimensions)",
                "Etude d’un tri (tri par sélection)",
                "Variables, types (entier, réel, chaîne, booléen), expressions, affectations, éléments de logique",
                "Instructions, instructions conditionnelles, instructions répétitives (boucle avec ou sans compteur), indentation",
                "Programmes, sous-programmes, fonctions, passage de paramètres",
                "TPs : connaissances de bases d'un système de fichiers (répertoires ou dossiers, fichiers, création, déplacement, copier-coller...), programmation en langage C (compilation, exécution, débogage)",
                "Connaitre et maitriser les techniques de bases de l'algorithmique et de la programmation  (Structure conditionnelle, structure répétitive, tableaux, fonctions)",
                "Mettre en œuvre correctement un algorithme répondant à un problème simple"
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 24,
            "TP": 12,
            "EFFECTIF": 307,
            "GROUPES_CM": 1,
            "GROUPES_TD": 8,
            "GROUPES_TP": 16,
            "M3C": {
                "SESSION_1": "partiel d'1h + TP noté+ 2*examen de 2h",
                "SECONDE_CHANCE": "écrit",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Pascal Vasseur"
                ],
                "INTERVENANTS": [
                    "Aristotelis Giannakos",
                    "Claire Delaplace",
                    "Yu Li",
                    "Vincent Maille",
                    "Sami Cherif",
                    "Geoffrey Defalque",
                    "Louis Couturier"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "REEXI01",
            "TITRE": "EXPERIENCES INFORMATIQUES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_3"
                }
            ],
            "CONTENU": [
                "Sur la base de 9 séances de 2h en Travaux Pratiques, l'étudiant sera guidé pas-à-pas dans la mise en œuvre progressive de fonctionnalités de petits projets",
                "Les environnements de développement seront de deux types : les cartes à microcontrôleur Arduino seront utilisées pour les projets relatifs aux entrées/sorties et au codage de l'information ; tandis que les notions d'interfaces, d'évènements et de protocole seront illustrées par la production d'applications mobiles sous un environnement basé web",
                "Exemples de thématiques par séance : animation de feux tricolores, résolution d'équations du second degré, partitions musicales, l'avis du public par SMS, compteur digital, réveil géographique, lecture de carte RFID, conversation bluetooth"
            ],
            "PREREQUIS": [],
            "CM": 3,
            "TD": 0,
            "TP": 18,
            "EFFECTIF": 237,
            "GROUPES_CM": 1,
            "GROUPES_TD": 0,
            "GROUPES_TP": 14,
            "M3C": {
                "SESSION_1": "moyenne des 4 moins bonnes notes de TP",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Dominique Lazure"
                ],
                "INTERVENANTS": [
                    "Konstantinos Aiwansedo",
                    "Robert Léo",
                    "Guillaume Béduneau",
                    "Vianney Dupont",
                    "Damien Vidal",
                    "Robin Condat"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "REINW01",
            "TITRE": "INTERNET ET WEB",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Généralités sur Internet : interconnexion de réseaux, TCP/IP, adresse IP, nom de domaines, protocole, URL, le W3C (ping), moteurs de recherche, référencement de site",
                "Communication client/serveur, les protocoles HTTP et HTTPS",
                "HTML et langages à balises : les tags, l'interprétation par les navigateurs (écriture de page), les éditeurs, validateurs de HTML, XHTML",
                "Le CSS : style et feuille de style  (écrire du CSS dans des pages HTML)",
                "Javascript et programmation événementielle",
                "Organiser un contenu structuré dans une page HTML (structuration sémantique et visuelle)",
                "Dissocier contenu et forme"
            ],
            "PREREQUIS": [],
            "CM": 3,
            "TD": 0,
            "TP": 18,
            "EFFECTIF": 241,
            "GROUPES_CM": 1,
            "GROUPES_TD": 0,
            "GROUPES_TP": 14,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Laure Brisoux"
                ],
                "INTERVENANTS": [
                    "Dominique Lazure",
                    "Damiens Vidal",
                    "Konstantinos Aiwansedo",
                    "Sami Cherif",
                    "Guillaume Béduneau",
                    "Robin Condat",
                    "Audrey Amblès"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "REMTC01",
            "TITRE": "METHODES ET TECHNIQUES DE CALCUL",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Fonctions usuelles (logarithme, exponentielles, fonctions puissances, fonctions trigonométriques). Limites et comportement asymptotique, croissances comparées",
                "Suites numériques (monotonie, arithmétique, géométrique, somme des premiers termes)",
                "Continuité, dérivabilité d’une fonction numérique. Tangente, convexité, inflexion. Calcul pratique des dérivées partielles (deux ou trois variables, pas de continuité des fonctions de plusieurs variables), utilisation pour les extrema de fonctions de deux variables",
                "Compléments sur les calculs de primitives et leur application au calcul d’intégrales : Intégration par partie, changement de variables, fractions rationnelles (cas simples)",
                "Equations différentielles linéaires du premier ordre, méthode de la variation de la constante, équations différentielles linéaires du second ordre à coefficients constants. Image d’un intervalle [a,b] par une fonction continue réelle (admis). Egalité et inégalité des accroissements finis (pourra être admis)"
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 250,
            "GROUPES_CM": 1,
            "GROUPES_TD": 7,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "WIMS (20%) + écrit de 2h (80%)",
                "SECONDE_CHANCE": "écrit de 2h ou oral",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Radu Stancu"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "RESTF01",
            "TITRE": "STRUCTURES FONDAMENTALES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Langage du calcul propositionnel (négation, connecteurs logiques, quantificateurs) et de la théorie naïve des ensembles (inclusion, intersection, réunion, complémentaire, produit, applications, injectivité, surjectivité, bijectivité, relations d'équivalence et d'ordre)",
                "Groupe des permutations (cardinalité, ordre d'un élément, transposition, cycle, parties génératrices, signature) et groupe des restes modulo n (structure, congruence, ordre d'un élément, groupe, sous-groupe)",
                "Anneau des entiers (division euclidienne, divisibilité, éléments irréductibles, décomposition en facteurs premiers, ppcm, pgcd et algorithme d'Euclide)",
                "Anneau des polynômes à coefficients réels ou complexes (racines et multiplicité, division euclidienne, divisibilité, décomposition en polynômes irréductibles, ppcm, pgcd et algorithme d'Euclide, théorème de Bézout)",
                "Anneau des restes modulo n (inversibilité, lemme chinois, exemples simples d'équations diophantiennes)",
                "Corps des nombres réels. Partie entière, densité des rationnels et irrationnels",
                "Suites de nombres réels et complexes (monotonie, arithmétique, géométrique, somme des premiers termes). Bornes supérieure et inférieure, limites supérieure et inférieure. Caractérisation des limites de suites. Critère de Cauchy, théorème de Bolzano-Weierstrass"
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 28,
            "TP": 0,
            "EFFECTIF": 140,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "RECAM01",
            "TITRE": "CALCUL MATRICIEL",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Nombres complexes : représentations d’un nombre complexe : conjugué, module, argument. Exponentielle complexe. Forme d’Euler, de Moivre",
                "Racines n-ièmes d’un nombre complexe. Applications à la trigonométrie",
                "Systèmes d’équations linéaires, méthode du pivot de Gauss, rang. On traitera divers exemples d'application aux sciences (électricité, biologie,...)",
                "Calcul matriciel (somme produit, transposée, inverse)",
                "Exemples d’utilisation issus de la géométrie : Equations de droite ou de plan, intersection; produit scalaire, transformations géométriques, changement de repère (cas orthonormé), exemple des coordonnées polaires, cylindriques, sphériques",
                "Notions élémentaires sur le déterminant d’une matrice : méthodes de calcul pour les déterminants 2x2 et 3x3, interprétation géométrique, applications",
                "Formules de Cramer 2x2 et 3x3. Produit mixte et produit vectoriel dans R3",
                "Espaces vectoriels sur le corps des nombres réels: Sous-espace, espace engendré par une partie, somme d’espaces vectoriels, somme directe, sous-espace supplémentaire. Base, dimension"
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 28,
            "TP": 0,
            "EFFECTIF": 142,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "REPHM01",
            "TITRE": "PHYSIQUE DU MOUVEMENT",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Cinématique du point : éléments de calcul vectoriel (produit scalaire, projection d’un vecteur), position, vitesse, accélération, trajectoire, systèmes de coordonnées cartésiennes et polaires",
                "Les différents types de mouvement de translation. Mouvement balistique. Principes fondamentaux : équilibre et mouvement. Théorème de l’énergie cinétique. Principe de conservation de l’énergie mécanique",
                "Notion de quantité de mouvement. Chocs élastiques et inélastiques",
                "Oscillateurs libres (en TP)"
            ],
            "PREREQUIS": [],
            "CM": 21,
            "TD": 21,
            "TP": 6,
            "EFFECTIF": 113,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "RECIE01",
            "TITRE": "CIRCUITS ELECTRIQUES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Circuits en régime continu (lois de Kirchhoff, dipôles passifs, dipôles actifs, théorème de Millman, théorèmes de Thévenin et Norton, théorème de superposition)",
                "Régimes transitoires : étude des circuits RC et RL",
                "Courants alternatifs : propriétés des réseaux en régime sinusoïdal, étude du courant dans un circuit RLC, impédances complexes, introduction au filtrage",
                "TP : Circuits en régime continu, mesures de grandeurs électriques"
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 22,
            "TP": 6,
            "EFFECTIF": 116,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "REANG01",
            "TITRE": "ANGLAIS S1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 0,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [
                "Anglais"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 10,
            "TP": 0,
            "EFFECTIF": 203,
            "GROUPES_CM": 0,
            "GROUPES_TD": 7,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Dominique Morel"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "REMET01",
            "TITRE": "METHODOLOGIE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 4,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 203,
            "GROUPES_CM": 2,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "Assiduité (15%) + exposé en groupe obligatoire (45%) + QCM (40%)",
                "SECONDE_CHANCE": "écrit de 1h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Estelle Bretagne"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "REOPD01",
            "TITRE": "OUTILS POUR LA DOCUMENTATION",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 0,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 203,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Virginie Colin"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "SARPA12",
            "TITRE": "REALISER UN PROJET D'ALGORITHMIQUE SUR UN PROBLEME DE LOGIQUE",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": [
                        1,
                        1
                    ],
                    "BLOCS": [
                        "COMP_1",
                        "COMP_2"
                    ]
                }
            ],
            "CONTENU": [
                "Algorithmes de résolution de problèmes logiques et/ou de raisonnement automatique",
                "Fichiers,  gestion des erreurs, tests",
                "Choisir des structures de données adaptées à un problème",
                "Traduire un problème en règles formelles",
                "Identifier les limites algorithmiques d’un système à base de règles",
                "Identifier les limites de la formalisation du raisonnement",
                "Adapter et raffiner un principe algorithmique (raisonnement formel à l’aide de règles)",
                "Programmer en visant l'efficacité en espace des structures de données et l'efficacité en temps des algorithmes",
                "Comprendre le raisonnement formel à base de règles",
                "Utiliser des fichiers dans un programme",
                "Développer un programme de façon incrémentale",
                "Ecrire du code lisible et commenté",
                "Tester un programme simple",
                "Limiter l’occupation mémoire d’un programme",
                "Limiter le temps de calcul d’un programme"
            ],
            "PREREQUIS": [
                "REBAP01",
                "REALP02",
                "REELF02"
            ],
            "CM": 0,
            "TD": 0,
            "TP": 14,
            "EFFECTIF": 267,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 14,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "non",
                "SESSION_2": "non"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Yu Li"
                ],
                "INTERVENANTS": [
                    "Frédéric Fürst",
                    "Claire Delaplace",
                    "Audrey Amblès",
                    "Rui Shibasaki",
                    "Vassilis Giakoumakis",
                    "Aristotelis Giannakos",
                    "Guillaume Béduneau",
                    "Robin Condat"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "REALP02",
            "TITRE": "ALGORITHMIQUE ET PROGRAMMATION",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "COMP_2"
                }
            ],
            "CONTENU": [
                "Enregistrements, types énumérés",
                "Notions de complexité (espace, temps)",
                "Etude de tris (tris quadratiques)",
                "Savoir utiliser et combiner les tableaux et les enregistrements pour structurer les données",
                "Maitriser les algorithmes de base de recherche d'élément et de tri dans des structures linéaires",
                "Calculer la complexité d'un algorithme itératif"
            ],
            "PREREQUIS": [
                "REBAP01"
            ],
            "CM": 6,
            "TD": 10,
            "TP": 0,
            "EFFECTIF": 242,
            "GROUPES_CM": 1,
            "GROUPES_TD": 7,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Claire Delaplace"
                ],
                "INTERVENANTS": [
                    "Frédéric Fürst",
                    "Audrey Amblès",
                    "Rui Shibasaki",
                    "Sami Cherif",
                    "Aristotelis Giannakos"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "REELF02",
            "TITRE": "ELEMENTS DE LOGIQUE FORMEL ET DU RAISONNEMENT AUTOMATIQUE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Eléments d’histoire et définitions de notions générales, liens avec l’informatique",
                "La logique propositionnelle : définition en tant que langage. Opérateurs logiques et formules. Tautologies. Fonctions booléennes et puissance expressive du langage de logique propositionnelle",
                "La logique du premier ordre : prédicats et fonctions, quantificateurs, occurrences de variables libres/ liées. Définition en tant que langage. Interprétations, évaluations, modèles",
                "Les notions basiques de théories formelles : axiomes, règles de déduction, preuve, théorèmes",
                "Styles de preuve : directe, par l’absurde, induction (au travers d’exemples)",
                "Applications et quelques techniques fondamentales : tiroirs de Dirichlet, diagonalisation, applications aux preuves de programmes",
                "Savoir écrire une formule logique",
                "Etre capable de déterminer si un raisonnement est correct ou non",
                "Savoir modéliser un problème en utilisant un formalisme logique"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 16,
            "TP": 0,
            "EFFECTIF": 253,
            "GROUPES_CM": 1,
            "GROUPES_TD": 6,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Yu Li"
                ],
                "INTERVENANTS": [
                    "Gilles Dequen",
                    "Stéphane Desvismes",
                    "Rui Shibasaki"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "REAOR02",
            "TITRE": "ARCHITECTURE DES ORDINATEURS / REPRESENTATION DE L'INFORMATION",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_3"
                }
            ],
            "CONTENU": [
                "Algèbre de Boole, loi de Morgan, théorème de Shannon",
                "Les portes logiques (NOT, AND, OR, XOR, NOR, NAND)",
                "Les circuits intégrés (du transistor à la porte NOR...)",
                "Quelques circuits de bases : circuits combinatoires (décodeurs, multiplexeur, additionneur,...)",
                "Rappel de Numération : les différentes bases utilisées en Informatique, algorithmes de conversion",
                "Représentation d'informations : les chiffres, caractères, les entiers, entiers signés, les fractionnaires en virgule fixe (signé ou non), les fractionnaires en virgule flottante",
                "Opérations sur les nombres (entiers et réels) : rappel des algorithmes opératoires, identification de la véracité des résultats",
                "Concevoir des circuits logiques",
                "Maitriser l'encodage numérique de l'information",
                "Identifier les limites des codages et de leurs opérations"
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 16,
            "TP": 0,
            "EFFECTIF": 264,
            "GROUPES_CM": 1,
            "GROUPES_TD": 7,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Pascal Vasseur"
                ],
                "INTERVENANTS": [
                    "Dominique Lazure",
                    "Robin Condat",
                    "Léo Robert"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "REIBD02",
            "TITRE": "INITIATION AUX BASES DE DONNEES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Introduction aux Systèmes d'Information",
                "Introduction et utilisation d'un Système de Gestion de Bases de Données",
                "Langage SQL (partie DML) et algèbre relationnelle",
                "Comprendre et ajuster un schéma relationnel existant, en maitrisant les concepts de relations, d’attributs, de clés primaires et étrangères, et appréhender les liens entre les données",
                "Rédiger et exécuter des requêtes SQL sur un SGBD relationnel, en définition de données, à partir d’un schéma relationnel donné.",
                "Rédiger et exécuter des requêtes SQL sur un SGBD relationnel, en manipulations de données (mono-table et multi-table) à partir d’une base existante."
            ],
            "PREREQUIS": [],
            "CM": 8,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 239,
            "GROUPES_CM": 1,
            "GROUPES_TD": 7,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "(TP + examen de 2h)/2",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Céline Joiron"
                ],
                "INTERVENANTS": [
                    "Aristotelis Giannakos",
                    "Stéphane Desvismes",
                    "Laure Brisoux",
                    "Louis Couturier"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "REPRS02",
            "TITRE": "PROBABILITES ET STATISTIQUES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Vocabulaire de la statistique. Statistique descriptive à une et deux variables : représentations graphiques, paramètre de position et de dispersion. Droite de régression des moindres carrés",
                "Introduction au calcul des probabilités. Probabilité conditionnelle. Indépendance",
                "Notions de variables aléatoires réelles discrètes et à densité. Moments. Lois usuelles (dont Binomiale, Poisson, Normale). Approximation de la Binomiale par la Normale, théorème central-limite."
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 250,
            "GROUPES_CM": 1,
            "GROUPES_TD": 7,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "WIMS (20%) + écrit de 2h (80%)",
                "SECONDE_CHANCE": "écrit de 2h ou oral",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Stéphane Ducay"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "REARF02",
            "TITRE": "ANALYSE REELLE FONDAMENTALE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Fonctions numériques (à valeurs réelles et complexes) de la variable réelle : limite d’une fonction en un point, continuité, valeurs intermédiaires, image d’un intervalle, suites de fonctions, convergence point par point",
                "Dérivabilité, égalité et inégalité des accroissements finis, cas des fonctions à valeurs complexes",
                "Intégrale définie (fonctions continues par morceaux), convergence des sommes de Riemann, théorème fondamental de l’Analyse",
                "Savoir restituer et utiliser les résultats et raisonnements fondamentaux d’Analyse",
                "Savoir majorer ou minorer une fonction, ou une intégrale"
            ],
            "PREREQUIS": [
                "REMTC01",
                "RESTF01"
            ],
            "CM": 12,
            "TD": 16,
            "TP": 0,
            "EFFECTIF": 147,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "REARA02",
            "TITRE": "ANALYSE REELLE APPLIQUEE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Relations de comparaison, formule de Taylor, développements limités",
                "Intégrales généralisées : définition, cas positif, convergence absolue, usage des relations de comparaisons",
                "Séries numériques : convergence, cas positif, critères de Cauchy et de d’Alembert, convergence absolue, séries alternées et règle d’Abel",
                "Théorèmes de comparaisons, relations avec l’intégrale",
                "Savoir utiliser un développement limité et les relations de prépondérance entre fonctions usuelles, pour lever une indétermination de limite ou pour étudier la convergence d’une série numérique ou d’une intégrale généralisée",
                "Savoir calculer la somme d’une série ou la valeur d’une intégrale"
            ],
            "PREREQUIS": [
                "REMTC01",
                "RESTF01"
            ],
            "CM": 12,
            "TD": 16,
            "TP": 0,
            "EFFECTIF": 144,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "REALL02",
            "TITRE": "ALGEBRE LINEAIRE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Applications linéaires sur R ou C : images, noyau, espace vectoriel des applications linéaires, endomorphismes linéaires, forme linéaire.",
                "Matrices : définition, sommes et produits de matrice. Espace vectoriel des matrices. Groupe des matrices inversibles. Matrices transposée.",
                "Matrice d’une application linéaire relativement à des bases données.  Matrice d’un endomorphisme. Changement de bases. Matrice de passage. Trace d’un endomorphisme et d’une matrice carrée. Rang d’une matrice. Matrices équivalentes. Matrices semblables.",
                "Matrices de projections, de rotations, de symétries."
            ],
            "PREREQUIS": [
                "RESTF01",
                "RECAM01"
            ],
            "CM": 12,
            "TD": 16,
            "TP": 0,
            "EFFECTIF": 146,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "RESYN02",
            "TITRE": "SYSTEMES NUMERIQUES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Ingénierie système",
                "Logique combinatoire : algèbre de Boole, composants combinatoires et exemples de circuits intégrés (portes, multiplexeurs, codeurs,...)",
                "Logique séquentielle : bascules, registres, compteurs asynchrones et synchrones,...",
                "Composants programmables : analyse structurelle, du PAL au FPGA"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 10,
            "TP": 0,
            "EFFECTIF": 96,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "SARCE02",
            "TITRE": "REALISER UNE CARTE ELECTRONIQUE EN LOGIQUE CABLEE",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Réaliser une carte électronique en logique cablée"
            ],
            "PREREQUIS": [],
            "CM": 4,
            "TD": 16,
            "TP": 12,
            "EFFECTIF": 99,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "SAMSC02",
            "TITRE": "MATLAB / SCILAB",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Eléments de base (calcul sur les nombres complexes, calcul matriciel)",
                "Zéros de fonctions, calcul numérique, calcul littéral et formel",
                "Langage de programmation et utilisation des scripts"
            ],
            "PREREQUIS": [],
            "CM": 9,
            "TD": 9,
            "TP": 12,
            "EFFECTIF": 79,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "REANG02",
            "TITRE": "ANGLAIS S2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [
                "Anglais"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 10,
            "TP": 0,
            "EFFECTIF": 203,
            "GROUPES_CM": 0,
            "GROUPES_TD": 7,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Dominique Morel"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "REMLF02",
            "TITRE": "MAITRISE DE LA LANGUE FRANCAISE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 10,
            "TP": 0,
            "EFFECTIF": 203,
            "GROUPES_CM": 0,
            "GROUPES_TD": 7,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Virginie Viallet"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "RECNU02",
            "TITRE": "CULTURE NUMERIQUE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "CT",
                    "CHOIX": [
                        1,
                        [
                            "RECNU02",
                            "REENG02"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 10,
            "TP": 0,
            "EFFECTIF": 203,
            "GROUPES_CM": 0,
            "GROUPES_TD": 7,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Céline Joiron"
                ],
                "INTERVENANTS": [
                    "Emmanuel Ruzé"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "REENG02",
            "TITRE": "ENGAGEMENT",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "CT",
                    "CHOIX": [
                        1,
                        [
                            "RECNU02",
                            "REENG02"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "SARPL33",
            "TITRE": "REALISER UN PROJET EN LANGAGE C ET SYSTEME D'EXPLOITATION",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": [
                        3,
                        3
                    ],
                    "BLOCS": [
                        "COMP_2",
                        "COMP_3"
                    ]
                }
            ],
            "CONTENU": [
                "Réaliser un projet en langage C et bash"
            ],
            "PREREQUIS": [
                "RESDF03",
                "REPLC03"
            ],
            "CM": 0,
            "TD": 0,
            "TP": 30,
            "EFFECTIF": 119,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "non",
                "SESSION_2": "non"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Florence Levé",
                    "Gilles Dequen"
                ],
                "INTERVENANTS": [
                    "Pascal Vasseur",
                    "Claire Delaplace",
                    "Mhand Hifi",
                    "Guillaume Béduneau",
                    "Sorina Ionica"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "RESDF03",
            "TITRE": "STRUCTURES DE DONNEES FONDAMENTALES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Récursivité",
                "Listes, Piles, Files, queues, table de hachage : spécification et implémentation",
                "Calcul de complexité avancé",
                "Définitions  des arbres, des ABR, des AVL",
                "Programmation récursive",
                "Ecrire un algorithme récursif et calculer sa complexité",
                "Choisir, pour un problème donnée, les structures de données chainées et arborescentes adaptées et construire les algorithmes qui le résolvent"
            ],
            "PREREQUIS": [
                "REALP02"
            ],
            "CM": 26,
            "TD": 34,
            "TP": 0,
            "EFFECTIF": 119,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "examen de 2h",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "David Semé"
                ],
                "INTERVENANTS": [
                    "Christine Irastorza",
                    "Sami Cherif",
                    "Robin Condat"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "REPLC03",
            "TITRE": "PROGRAMMATION ET LANGAGE C",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_2"
                }
            ],
            "CONTENU": [
                "Syntaxe : structures de contrôle, opérateurs et expressions",
                "Types, tableaux et pointeurs, passage de paramètres",
                "Gestion de la mémoire, programmation dynamique et algorithmes génériques",
                "Compilation séparée : pré-processeur, visibilité, édition de liens et atelier de compilation",
                "Librairie standard",
                "Maîtriser les types de données simples et complexes et les fonctions permettant de les manipuler en C",
                "Utiliser les fonctions de la librairie standard",
                "Maîtriser les étapes de la compilation d'un programme, utiliser la compilation séparée",
                "Connaître le fonctionnement du stockage en mémoire des données, utiliser les pointeurs de façon efficace et appropriée",
                "Créer un code clair et modulaire"
            ],
            "PREREQUIS": [
                "REALP02"
            ],
            "CM": 18,
            "TD": 18,
            "TP": 14,
            "EFFECTIF": 118,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Florence Levé"
                ],
                "INTERVENANTS": [
                    "Aristotelis Giannakos",
                    "Rui Shibasaki",
                    "Guillaume Béduneau",
                    "Audrey Amblès",
                    "Sami Cherif"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "REBDR04",
            "TITRE": "BASES DE DONNEES RELATIONNELLES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Modèle E/A étendu",
                "Les règles de transformation du modèle E/A étendu vers le modèle relationnel",
                "Approfondissement du langage SQL : mise en œuvre de requêtes plus complexes à l’aide des fonctions agrégatives",
                "Optimisation algébrique et sous SQL des requêtes",
                "Présentation et justification de la classification des relations sous formes normales",
                "Algorithme de  décomposition des relations",
                "Être capable de  concevoir et mettre en œuvre un schéma relationnel étendu, concevoir un modèle conceptuel des données",
                "Concevoir des requêtes agrégatives",
                "Concevoir des requêtes efficaces"
            ],
            "PREREQUIS": [
                "REIBD02"
            ],
            "CM": 16,
            "TD": 24,
            "TP": 10,
            "EFFECTIF": 115,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "(TP + examen de 2h)/2",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Laure Brisoux"
                ],
                "INTERVENANTS": [
                    "Catherine Barry",
                    "Thomas Bazaille",
                    "Aristotelis Giannakos",
                    "Louis Couturier"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "REAOL03",
            "TITRE": "ARCHITECTURE DES ORDINATEURS / LANGAGE D'ASSEMBLAGE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_6",
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "COMP_3"
                }
            ],
            "CONTENU": [
                "Compléments d'architecture: les bus du Microprocesseur, la mémoire vue du Microprocesseur, les registres du Microprocesseur",
                "Le Langage d'assemblage : les modes d'adressage, écriture d'une ligne de programme, présentation du jeu d'instructions, écriture de programmes, exécution conditionnée, simulation de boucles, les sous-programmes, notion de variables, les Appels Systèmes",
                "Réalisation d'un petit projet",
                "Identifier les éléments fonctionnels d’un système numérique de traitement",
                "Comprendre et écrire des routines simples en langage machine"
            ],
            "PREREQUIS": [
                "REAOR02"
            ],
            "CM": 6,
            "TD": 12,
            "TP": 12,
            "EFFECTIF": 75,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "sup((Projet + ET)/2),ET)",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "David Semé"
                ],
                "INTERVENANTS": [
                    "Pascal Vasseur"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "REPRF03",
            "TITRE": "PROGRAMMATION FONCTIONNELLE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_2"
                }
            ],
            "CONTENU": [
                "Fonctions, fonctions récursives, composition de fonctions",
                "Type, inférence de type",
                "Types construits : types récursifs, types paramétrés",
                "Filtrage, gardes",
                "Portée des expressions",
                "Structures de données : exemple liste, arbres",
                "Gestion des exceptions",
                "Polymorphisme",
                "Applications en CAML ou Haskell",
                "Connaitre les bases de la programmation fonctionnelle",
                "Ecrire des programmes dans un langage de programmation fonctionnelle"
            ],
            "PREREQUIS": [
                "REALP02"
            ],
            "CM": 8,
            "TD": 12,
            "TP": 10,
            "EFFECTIF": 90,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Christine Irastorza"
                ],
                "INTERVENANTS": [
                    "Pascal Vasseur",
                    "Thomas Bazaille"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "REBDG03",
            "TITRE": "BASES DE GESTION, ORGANISATION DES ENTREPRISES ET FONCTION COMMERCIALE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_5",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_5"
                },
                {
                    "PARCOURS": "PAR_6",
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "COMP_5"
                }
            ],
            "CONTENU": [
                "Logique entrepreneuriale et logique managériale",
                "Finalité de l’entreprise et performance",
                "Caractéristiques et choix d’une structure organisationnelle",
                "La démarche mercatique",
                "Le marché et ses composantes (offre, demande, environnement)",
                "Le plan d’actions commerciales (politique produit, politique prix, politique de communication, politique de  distribution)"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 52,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "sup((EP + ET)/2,ET)",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Pascal Pomart"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "REANGI3",
            "TITRE": "ANGLAIS S3",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 10,
            "TP": 0,
            "EFFECTIF": 80,
            "GROUPES_CM": 0,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Caroline Boinet"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "REPPI03",
            "TITRE": "PPI",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "CT",
                    "CHOIX": [
                        2,
                        [
                            "REPPI03",
                            "REPPM03",
                            "REPPE03"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Projet Professionnel et Insertion"
            ],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 4,
            "TP": 0,
            "EFFECTIF": 91,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Céline Joiron"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "REPPM03",
            "TITRE": "PPM2E S3 PROJET PRO VERS METIERS DE L'ENSEIGNEMENT ET L'EDUC",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "CT",
                    "CHOIX": [
                        2,
                        [
                            "REPPI03",
                            "REPPM03",
                            "REPPE03"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "REPPE03",
            "TITRE": "PPM2E + EFME S3 ENSEIGNER LE FRANCAIS ET LES MATHS A L'ECOLE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "CT",
                    "CHOIX": [
                        2,
                        [
                            "REPPI03",
                            "REPPM03",
                            "REPPE03"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "SARPB04",
            "TITRE": "REALISER UN PROJET EN BASE DE DONNEES ET WEB",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": [
                        2,
                        3
                    ],
                    "BLOCS": [
                        "COMP_1",
                        "COMP_2"
                    ]
                }
            ],
            "CONTENU": [
                "réaliser une BDR",
                "réaliser un site Web adossé à une BD"
            ],
            "PREREQUIS": [
                "RESYE03",
                "REBDR04",
                "REPRW04"
            ],
            "CM": 0,
            "TD": 0,
            "TP": 28,
            "EFFECTIF": 111,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "Oral",
                "SECONDE_CHANCE": "non",
                "SESSION_2": "non"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Yoann Dieudonné",
                    "Laure Brisoux"
                ],
                "INTERVENANTS": [
                    "Gil Utard",
                    "Robin Condat",
                    "Audrey Amblès"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "RESYE03",
            "TITRE": "SYSTEME D'EXPLOITATION",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_3"
                }
            ],
            "CONTENU": [
                "Terminologie autour des systèmes d’exploitation et des outils système",
                "Norme POSIX",
                "Interfaçage",
                "Configuration Shell : alias, droit par défaut, positionnement et implication des variables d'environnement, droits étendus, entrée et sortie standards",
                "Shell avancé, Scripting : fonctions, structure de contrôle, paramétrage, approfondissement des commandes built-in",
                "Expressions Régulières : illustration avec Sed, synthèse avec Perl, complément de l'interfaçage avec Tk",
                "Système de Fichiers",
                "Maitriser les commandes et mécanismes de base des environnements UNIX/LINUX côté utilisateur",
                "Écrire des scripts simples exécutables sous Interpréteur de commandes"
            ],
            "PREREQUIS": [],
            "CM": 16,
            "TD": 16,
            "TP": 18,
            "EFFECTIF": 112,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Gilles Dequen"
                ],
                "INTERVENANTS": [
                    "Stéphane Devismes",
                    "Sorina Ionica",
                    "Guillaume Béduneau"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "READG04",
            "TITRE": "ALGORITHMIQUE DES GRAPHES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Définition de base et modélisation des problèmes à l’aide des graphes",
                "Différents implémentation d’un graphe et conséquences du point de vue de la complexité",
                "Parcours d’un graphe, composantes connexes, cycles",
                "Blocs et points d’articulation",
                "Composantes fortement connexes",
                "Graphes sans circuits,  problèmes d’ordonnancement, optimisation du code",
                "Couplage maximum et problèmes d’affectation des tâches",
                "Arbre couvrant de coût minimum,  réalisation d’un réseau connexe à coût minimum",
                "Algorithmes classiques de recherche du plus court chemin dans un graphe",
                "Modéliser un problème sous forme de graphes, choisir le type de graphe le plus adapté",
                "Associer à chaque algorithme un problème et/ou un domaine d’application (p. e. points d’articulation et réseaux tolérants aux pannes etc.)",
                "Choisir et mettre en œuvre l'algorithme de graphe le plus adapté à un problème donné, en tenant compte de son efficacité"
            ],
            "PREREQUIS": [
                "RESDF03"
            ],
            "CM": 22,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 110,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CCI",
                "SECONDE_CHANCE": "non",
                "SESSION_2": "deux meilleures notes de CCI"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Alain Cournier"
                ],
                "INTERVENANTS": [
                    "Stéphane Devismes",
                    "Vassilis Giakoumakis"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "REPOB04",
            "TITRE": "PROGRAMMATION OBJET 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "COMP_2"
                }
            ],
            "CONTENU": [
                "Notion d'objet et de classe, méthodes, constructeurs",
                "Encapsulation, visibilité",
                "Héritage",
                "Polymorphisme",
                "Abstraction : méthodes abstraites, classes abstraites, interfaces",
                "Packages",
                "Interface graphique",
                "Maitriser les différents mécanismes de la programmation objet en Java",
                "Exploiter ces mécanismes pour améliorer la qualité du logiciel produit: robustesse, extensibilité, réutilisabilité",
                "Apprendre à développer des interfaces graphiques"
            ],
            "PREREQUIS": [
                "RESDF03"
            ],
            "CM": 16,
            "TD": 26,
            "TP": 8,
            "EFFECTIF": 132,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Jean-Luc Guérin"
                ],
                "INTERVENANTS": [
                    "Christine Irastorza",
                    "Frédéric Fürst",
                    "Catherine Barry"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "REPRW04",
            "TITRE": "PROGRAMMATION WEB",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Fonctionnement d’une architecture client/serveur de contenu Web : Protocole HTTP, langage PHP, traitement de formulaires, sessions, upload, interfaçage avec une base de données",
                "Concevoir un site web dynamique, qui interagit avec une base de données",
                "Manipuler et conserver, côté serveur, des données provenant des utilisateurs d'un site web."
            ],
            "PREREQUIS": [
                "RESDF03",
                "REINW01",
                "RESYE03"
            ],
            "CM": 10,
            "TD": 0,
            "TP": 20,
            "EFFECTIF": 111,
            "GROUPES_CM": 1,
            "GROUPES_TD": 0,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Yoann Dieudonné"
                ],
                "INTERVENANTS": [
                    "Rui Shibasaki Rui",
                    "Audrey Amblès",
                    "Robin Condat"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "REALA04",
            "TITRE": "ALGORITHMIQUE AVANCEE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_6",
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Compléments sur les arbres : B-arbres, Arbres 2-3-4",
                "Tri par tas",
                "Algorithmique du texte (dont code de Huffman…)",
                "Programmation dynamique"
            ],
            "PREREQUIS": [
                "RESDF03"
            ],
            "CM": 8,
            "TD": 14,
            "TP": 8,
            "EFFECTIF": 41,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Claire Delaplace"
                ],
                "INTERVENANTS": [
                    "Sami Cherif",
                    "Aristotelis Giannakos"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "RESIC04",
            "TITRE": "SYSTEME D'INFORMATIONS COMPTABLES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_5",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_5"
                },
                {
                    "PARCOURS": "PAR_6",
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "COMP_5"
                }
            ],
            "CONTENU": [
                "L’activité économique et sa représentation comptable : comprendre les flux économiques, représenter les flux sous forme comptable, enregistrer les opérations courantes, comprendre le  fonctionnement des comptes",
                "Des comptes à la balance : organiser la comptabilité, codifier les informations, contrôler par la balance",
                "De la balance au bilan et au compte de résultat : comprendre le bilan et le résultat, de la balance au bilan et au résultat, lire le compte de résultat, lire le bilan",
                "L’inventaire et la variation des stocks",
                "L’amortissement des immobilisations : comprendre l’amortissement, enregistrer les amortissements, calculer un amortissement, l’amortissement et les documents de synthèse",
                "Les provisions : comprendre les provisions, calculer une provision pour dépréciation d’actif, enregistrer une provision pour dépréciation d’actif, inscrire une provision au bilan et au résultat"
            ],
            "PREREQUIS": [
                "REBDG03"
            ],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 61,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "sup((EP + ET)/2,ET)",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Pascal Pomart"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "REANGI4",
            "TITRE": "ANGLAIS S4",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 10,
            "TP": 0,
            "EFFECTIF": 88,
            "GROUPES_CM": 0,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Caroline Boinet"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "RECYC04",
            "TITRE": "CYCLE DE CONFERENCES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 0,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 80,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "REMOC04",
            "TITRE": "METHODES ET OUTILS DE COMMUNICATION SCIENTIFIQUE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "CT",
                    "CHOIX": [
                        3,
                        [
                            "REMOC04",
                            "REENGC4",
                            "REPPM04",
                            "REPPE04"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 14,
            "TP": 0,
            "EFFECTIF": 78,
            "GROUPES_CM": 0,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "REPPM04",
            "TITRE": "PPM2E S4 PROJET PRO VERS METIERS DE L'ENSEIGNEMENT ET L'EDUC",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "CT",
                    "CHOIX": [
                        3,
                        [
                            "REMOC04",
                            "REENGC4",
                            "REPPM04",
                            "REPPE04"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "REPPE04",
            "TITRE": "PPM2E + EFME S4 ENSEIGNER LE FRANCAIS ET LES MATHS A L'ECOLE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "CT",
                    "CHOIX": [
                        3,
                        [
                            "REMOC04",
                            "REENGC4",
                            "REPPM04",
                            "REPPE04"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "REENGC4",
            "TITRE": "ENGAGEMENT",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "CT",
                    "CHOIX": [
                        3,
                        [
                            "REMOC04",
                            "REENGC4",
                            "REPPM04",
                            "REPPE04"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 12,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "REPSI05",
            "TITRE": "PROGRAMMATION DES SYSTEMES D'INFORMATION",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_3"
                }
            ],
            "CONTENU": [
                "Processus lourds : clona, synchronisation et signaux système",
                "Descripteurs de flux : redirection des Entrées/Sorties, tube système et tube nommés",
                "Outils orientés Système : gestion de projet sous UNIX, compilation arborescente, versionning, synchronisation",
                "Maîtriser les bases de la programmation système Unix (langage C)",
                "Utiliser les communications inter-processus et les flux d’entrée/sortie des processus (langage C et shell Unix)",
                "Ecrire des scripts efficaces en s’appuyant sur la compréhension des mécanismes système sous-jacents"
            ],
            "PREREQUIS": [
                "REBDR04",
                "REPLC03"
            ],
            "CM": 10,
            "TD": 0,
            "TP": 20,
            "EFFECTIF": 49,
            "GROUPES_CM": 1,
            "GROUPES_TD": 0,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Gaël Le Mahec"
                ],
                "INTERVENANTS": [
                    "Gil Utard"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "RETDS05",
            "TITRE": "THEORIE DES SYSTEMES D'EXPLOITATION 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_3"
                }
            ],
            "CONTENU": [
                "Ressources : définition, classes de ressources, lock, processus, ordonnancement, etc",
                "Représentation des processus",
                "Interaction des processus : allocation de ressources, déterminisme, conditions de Berstein, interblocage, algorithmes du banquier",
                "Système multi-threadés",
                "Mettre en œuvre une application multi-processus",
                "Utiliser les mécanismes de communication et de synchronisation entre processus",
                "Identifier les problèmes liés à l’accès concurrent à des ressources partagées"
            ],
            "PREREQUIS": [
                "REBDR04"
            ],
            "CM": 10,
            "TD": 10,
            "TP": 10,
            "EFFECTIF": 74,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Gil Utard"
                ],
                "INTERVENANTS": [
                    "Gaël Le Mahec",
                    "Guillaume Béduneau"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "RETDS15",
            "TITRE": "THEORIE DES SYSTEMES D'EXPLOITATION 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_3"
                }
            ],
            "CONTENU": [
                "Synchronisation : section critique, algorithme de Peterson, algorithme de Dekker, algorithme de Lamport, sémaphores, moniteurs",
                "Ordonnancement de l'unité centrale et du disque",
                "Mémoire : segmentation, pagination, mémoire virtuelle, algorithme de pagination",
                "Maitriser les mécanismes de synchronisation de processus",
                "Utiliser les différents mécanismes permettant les accès concurrents à la mémoire"
            ],
            "PREREQUIS": [
                "REBDR04"
            ],
            "CM": 10,
            "TD": 10,
            "TP": 10,
            "EFFECTIF": 48,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Gil Utard"
                ],
                "INTERVENANTS": [
                    "Gaël Le Mahec"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "RELAF05",
            "TITRE": "LANGAGES FORMELS",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Notions de base (mots, langages, ...)",
                "Langages reconnaissables, automates finis",
                "Langages et expressions rationnelles (liens avec les outils de recherche utilisant des expressions régulières)",
                "Théorème de Kleene, algorithmes de passage d’un automate à une expression rationnelle et réciproquement Langage reconnu par un automate (algorithme de Mac Naughton et Yamada)",
                "Propriétés de fermeture rationnelles",
                "Déterminisme",
                "Propriétés de fermeture non rationnelles",
                "Minimalité",
                "Langages non reconnaissables, théorème de l'étoile",
                "Notions de grammaires et de langages algébriques",
                "Extraire des règles lexicales caractérisant un texte et concevoir une expression régulière le reconnaissant",
                "Proposer un automate efficace (facilement manipulable) pour représenter un langage",
                "Identifier les langages reconnaissables"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 76,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Florence Levé"
                ],
                "INTERVENANTS": [
                    "Vassilis Giakoumakis"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "REMAC05",
            "TITRE": "METHODES D'ANALYSE ET DE CONCEPTION DES SI",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_4",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                },
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Principes de la conception de SI : niveaux d’abstraction, modèles de représentation, démarches de conception",
                "Méthode de type conceptuelle  avec ses niveaux d’abstraction, ses modèles et sa démarche pour la construction des modèles selon les perspectives données / traitements",
                "Méthode de type objet et ses modèles pour la spécification des fonctions, de la structure et du comportement d’un système",
                "Mise en œuvre d’une méthode donnée sur des études de cas",
                "Mise en œuvre d’un modèle réalisé (implémentation du système)",
                "Conceptualiser un code (selon un méta-modèle donné)",
                "Evaluer la qualité d’un modèle",
                "Analyser et identifier les besoins des utilisateurs",
                "Modéliser l'existant",
                "Identifier les fonctionalités d'un SI",
                "Réaliser une maquette fonctionnelle"
            ],
            "PREREQUIS": [],
            "CM": 8,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 70,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Catherine Barry"
                ],
                "INTERVENANTS": [
                    "Anne Lapujade"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "REMOO05",
            "TITRE": "MODELISATION OBJET",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_4",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                },
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Introduction à la modélisation logicielle : problématique de la modélisation, le cycle de développement logiciel, les principales méthodes de développement (cascade, V, spirale, agile, ...), les méthodologies orientées UML",
                "Le langage UML : vue fonctionnelle du logiciel, vue structurelle du logiciel, vue dynamique du logiciel",
                "Modéliser les besoins avec un diagramme de cas d'utilisation complexe",
                "Concevoir la structure d'un logiciel suivant le paradigme objet",
                "Décrire le système avec des niveaux d'abstractions différents"
            ],
            "PREREQUIS": [
                "REPOB04"
            ],
            "CM": 8,
            "TD": 12,
            "TP": 10,
            "EFFECTIF": 75,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Catherine Barry"
                ],
                "INTERVENANTS": [
                    "Anne Lapujade"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "REPOB05",
            "TITRE": "PROGRAMMATION OBJET 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_4",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_2"
                },
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "COMP_2"
                }
            ],
            "CONTENU": [
                "Techniques de programmation orientée objet avancée : Pattern Observer-Observable, JavaBean, architecture logicielle Modèle-Vue-Contrôleur (réalisation d'un gros projet MVC), généricité et Sérialisation",
                "Programmation multi-thread : thread, mémoire partagée, exclusion mutuelle, synchronisateur, exécution de tache, programmation réactive, application à la programmation graphique (thread event-dispatcher, tache asynchrone)",
                "Maîtriser les techniques de programmation objet avancée : sérialisation, généricité, MVC, thread, programmation réactive"
            ],
            "PREREQUIS": [
                "REPOB04"
            ],
            "CM": 4,
            "TD": 26,
            "TP": 0,
            "EFFECTIF": 64,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "sup((EP + ET)/2 ; ET)",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Sorina Ionica"
                ],
                "INTERVENANTS": [
                    "Rui Shibasaki",
                    "Guillaume Béduneau"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "REFRW05",
            "TITRE": "FRAMEWORK",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Développement par composant, patterns (MVC, Observer, ...), injection de dépendances",
                "Etude du framework Laravel ou Symfony",
                "Utiliser l'approche de développement par composant et l'architecture MVC",
                "Construire un site Web en exploitant les mécanismes des frameworks Web (routing, templates, ...)"
            ],
            "PREREQUIS": [
                "REPOB04",
                "REPRW04"
            ],
            "CM": 4,
            "TD": 0,
            "TP": 26,
            "EFFECTIF": 65,
            "GROUPES_CM": 1,
            "GROUPES_TD": 0,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Yoann Dieudonné"
                ],
                "INTERVENANTS": [
                    "Stéphane Desvismes"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "REMFA05",
            "TITRE": "METHODES FORMELLES D'AIDE A LA DETECTION D'ERREUR",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Dans ce module seront étudier des méthodes permettant de démontrer : la terminaison d’un programme, la validité du résultat calculé par un programme, l’efficacité en temps et en espace d’un programme",
                "Pour mener à bien ces investigations nous nous appuierons sur : la logique des propositions, la logique des prédicats, la notion d’invariant, les propriétés intrinsèquement liées à la sémantique des instructions des programmes",
                "Prouver la terminaison d'un algorithme",
                "Prouver la correction d'un algorithme"
            ],
            "PREREQUIS": [
                "RESDF03"
            ],
            "CM": 12,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 27,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Alain Cournier"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "REMAF05",
            "TITRE": "MATHEMATIQUES FINANCIERES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_4",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_5"
                }
            ],
            "CONTENU": [
                "Le calcul financier en intérêt simple.",
                "L'intérêt composé et la capitalisation mixte",
                "Les emprunts indivis",
                "Les obligations",
                "Les taux effectifs",
                "Les bases de l'évaluation des investissements"
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 26,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Pierre Del Castillo"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "RESIF05",
            "TITRE": "SYSTEME D'INFORMATIONS FINANCIERES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_4",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_5"
                }
            ],
            "CONTENU": [
                "Retraitement du bilan",
                "Analyse de l’entreprise à partir des SIG",
                "Tableaux des  flux de trésorerie",
                "Interprétation des résultats"
            ],
            "PREREQUIS": [
                "RESIC04"
            ],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 26,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "écrit de 2h",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Pascal Pomart"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "REANGI5",
            "TITRE": "ANGLAIS S5",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 70,
            "GROUPES_CM": 0,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Dominique Morel"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "REPIX05",
            "TITRE": "PIX",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 2,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 70,
            "GROUPES_CM": 1,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Quentin Leclet"
                ],
                "INTERVENANTS": [
                    "Céline Joiron"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "REPPI05",
            "TITRE": "PPI PROJET PROFESSIONNEL A L'INSERTION",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "CT",
                    "CHOIX": [
                        2,
                        [
                            "REPPI05",
                            "REPPM05",
                            "REPPE05"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 45,
            "GROUPES_CM": 0,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "REPPM05",
            "TITRE": "PPM2E S5 PROJET PRO VERS METIERS DE L'ENSEIGNEMENT ET L'EDUC",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "CT",
                    "CHOIX": [
                        2,
                        [
                            "REPPI05",
                            "REPPM05",
                            "REPPE05"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "REPPE05",
            "TITRE": "PPM2E + EFME S5 ENSEIGNER LE FRANCAIS ET LES MATHS A L'ECOLE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "CT",
                    "CHOIX": [
                        2,
                        [
                            "REPPI05",
                            "REPPM05",
                            "REPPE05"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "RERES06",
            "TITRE": "RESEAU",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_3"
                }
            ],
            "CONTENU": [
                "Transmission de l’information : éléments de traitement du signal",
                "Transmission d’un signal sur un support : codage, numérisation d'un signal, formule de Shannon, les supports de communication",
                "Détection et correction des erreurs de transmission : taux d'erreurs, taux d'erreurs résiduelles, codes linéaires et cyclique",
                "Multiplexage et commutation",
                "Protocole du niveau Liaison (et sa simulation) : contrôle de flux, fenêtre de transmission, procédures de communication, LAP-B (HDLC)",
                "Réseaux locaux et protocoles d'accès",
                "Réseaux grandes distances et commutation : circuit virtuel, algorithmes de routage (OSPF(Dijstra), RIP(Bellman-Ford), inondation, « hot patatoes», congestion : mécanismes préventifs et réactifs",
                "Introduction à la couche transport",
                "Communication sous UNIX (sockets)",
                "Simulation de routeur CISCO, Simulateur NS2",
                "Situer les différents mécanismes réseaux dans les couches OSI",
                "Organiser le routage dans un réseau"
            ],
            "PREREQUIS": [
                "REPLC03",
                "REBDR04"
            ],
            "CM": 20,
            "TD": 22,
            "TP": 18,
            "EFFECTIF": 73,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Wafa Badreddine"
                ],
                "INTERVENANTS": [
                    "Gil Utard",
                    "Léo Robert",
                    "Konstandinos Aiwansedo"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "SARAI16",
            "TITRE": "REALISER UNE APPLICATION INFORMATIQUE COMPLETE",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": [
                        3,
                        3
                    ],
                    "BLOCS": [
                        "COMP_1",
                        "COMP_2"
                    ]
                }
            ],
            "CONTENU": [
                "Mise en œuvre d’une application informatique",
                "Analyse du problème",
                "Réflexion algorithmique",
                "Choix d’implantation, puis implantation",
                "Tests",
                "Documentation d’un codage",
                "Cahier des charges",
                "Rédaction d’un rapport",
                "Présentation orale du projet",
                "Définir un projet avec ses objectifs, ses acteurs et ses contraintes",
                "Planifier un projet",
                "Spécifier une application informatique selon les points de vue fonctionnel et structurel",
                "Rédiger un cahier des charges",
                "Mener un projet en accord avec un cahier des charges",
                "Faire le bilan d'un projet"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 30,
            "EFFECTIF": 68,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "non",
                "SESSION_2": "non"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Frédéric Fürst"
                ],
                "INTERVENANTS": [
                    "Christine Irastorza",
                    "Yu Li",
                    "Audrey Amblès"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "SACPC06",
            "TITRE": "CONCEVOIR UN PROTOCOLE DE COMMUNICATION CLIENT/SERVEUR",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": [
                        3,
                        3
                    ],
                    "BLOCS": [
                        "COMP_3",
                        "COMP_4"
                    ]
                }
            ],
            "CONTENU": [
                "Concevoir un protocole de communication entre un serveur et des clients"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 30,
            "EFFECTIF": 81,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "non",
                "SESSION_2": "non"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Gil Utard"
                ],
                "INTERVENANTS": [
                    "Pascal Vasseur"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "REINA06",
            "TITRE": "INTELLIGENCE ARTIFICIELLE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Résolution de problèmes : stratégies d'exploration non informées, stratégies d'exploration informées (heuristiques), exploration A*, algorithmes d'exploration locale (hill-climbing, recuit simulé), exploration en situation d'adversité́ (les jeux) : algorithme minimax, élagage alpha-bêta",
                "Apprentissage : apprentissage supervisé (réseaux de neurones), apprentissage non-supervisé.",
                "Utiliser des algorithmes heuristiques pour la résolution de problème",
                "Mettre en œuvre l'apprentissage par descente de gradient dans un réseau de neurones formels"
            ],
            "PREREQUIS": [
                "READG04"
            ],
            "CM": 8,
            "TD": 10,
            "TP": 12,
            "EFFECTIF": 55,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Christine Irastorza",
                    "Frédéric Fürst"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "RECOM06",
            "TITRE": "COMPILATION",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Analyse lexicale, Lex, analyse syntaxique, analyseur LL, analyseur LR, grammaire LR, SLR, présentation de Yacc, traduction dirigée par la syntaxe, environnement d’exécution, production du code intermédiaire, production du code, optimisation du code",
                "Réalisation d’un mini-compilateur à l’aide de Lex et Yacc",
                "Construire un analyseur lexical Lex",
                "Construire un analyseur syntaxique Yacc"
            ],
            "PREREQUIS": [
                "RELAF05",
                "REPLC03"
            ],
            "CM": 14,
            "TD": 16,
            "TP": 0,
            "EFFECTIF": 34,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CCI",
                "SECONDE_CHANCE": "non",
                "SESSION_2": "deux meilleures notes du CCI"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Vassilis Giakoumakis"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "REMQA06",
            "TITRE": "METHODES QUANTITATIVES ET AIDE A LA DECISION",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Objectif des méthodes quantitatives et décision (MQD)",
                "Les étapes d'un projet en MQD : problèmes d’ordonnancement et de planification de tâches dans un réseau informatique",
                "Modélisation par quantification (ordonnancement de tâches, production, gestion de stock)",
                "Résolution géométrique de l’ordonnancement et de la planification de tâches",
                "Différentes formes d'un modèle quantifié (forme générale, forme canonique d'un modèle, forme standard)",
                "Base, solution de base d'un modèle quantifié, optimalité",
                "Phase II primale du simplexe (démarrage de la méthode, résolution par points extrêmes)",
                "Equivalence de modèles quantifiés et interprétation géométrique",
                "Modéliser un problème de planification ou d'ordonnancement",
                "Mettre en œuvre l'algorithme du simplexe"
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 14,
            "TP": 4,
            "EFFECTIF": 56,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Mhand Hifi"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "REXML06",
            "TITRE": "XML",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "XML : definition , quelques exemples de langages XML , utilisation (sérialisation, export/import BD, communication entre serveur en REST ou SOAP, ...)",
                "Schéma XSD (grammaire écrite en XML), validation",
                "DOM (représentation du document XML en arbre) : création, manipulation, exemple le DOM HTML",
                "Langage XPath et applications (e.g., XQuery, XSLT )",
                "Marshaling (sérialisation des objets informatiques servant au transfert entre applications écrites dans des langages différents) : exemple JAXB",
                "Concurent : JSON comparaison.",
                "Extraire et manipuler des données d'un document structuré via XML",
                "Elaborer un modèle de structuration de données en XML"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 0,
            "TP": 20,
            "EFFECTIF": 72,
            "GROUPES_CM": 1,
            "GROUPES_TD": 0,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Yoann Dieudonné"
                ],
                "INTERVENANTS": [
                    "Aristotelis Giannakos",
                    "Rui Shibasaki"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "REICC06",
            "TITRE": "INITIATION A LA CRYPTOLOGIE ET AU CALCUL DISTRIBUE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "COMP_1"
                }
            ],
            "CONTENU": [
                "Cryptologie : bases mathématiques pour la sécurité de l’information, ordre de grandeur, fonctions à sens unique, arbres de Merkle, preuve de travail, compréhension et usage des Blockchains",
                "Systèmes distribués : découverte du vocabulaire, présentation du modèle à passage de message, présentation de quelques algorithmes simples, calcul de la complexité des algorithmes distribués, présentation des réseaux P2P et de la structure de données distribuée DHT (Distributed Hash Table)"
            ],
            "PREREQUIS": [
                "RESDF03"
            ],
            "CM": 8,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 47,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Alain Cournier",
                    "Gilles Dequen"
                ],
                "INTERVENANTS": [
                    "Stéphane Desvismes"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "RESIG06",
            "TITRE": "SYSTEME D'INFORMATION POUR LA GESTION",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_4",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "COMP_5"
                }
            ],
            "CONTENU": [
                "Présentation de la comptabilité de gestion (domaine, modélisation par les coûts)",
                "Approche stratégique",
                "Les coûts complets",
                "Les coûts instruments de simulation économique",
                "Les coûts dans un environnement international",
                "De la mesure à la maîtrise des coûts",
                "Principe de base de la gestion de production"
            ],
            "PREREQUIS": [
                "RESIF05"
            ],
            "CM": 16,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 27,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Emmanuel Ruzé"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "REANGI6",
            "TITRE": "ANGLAIS S6",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 14,
            "TP": 0,
            "EFFECTIF": 92,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Dominique Morel"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "SADBS06",
            "TITRE": "SAE DEFENDRE SON BILAN DE STAGE ET DE COMPETENCES",
            "TYPE": "STAGE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "CT",
                    "CHOIX": [
                        3,
                        [
                            "REPPM06",
                            "REPPE06",
                            "SADBS06",
                            "SADBP06",
                            "SADBE06"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Minimum 8 semaines, une soutenance et un mini-rapport"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 80,
            "GROUPES_CM": 0,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Frédéric Fürst"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "SADBP06",
            "TITRE": "SAE DEFENDRE SON BILAN DE PROJET TUTORE ET DE COMPETENCES",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "CT",
                    "CHOIX": [
                        3,
                        [
                            "REPPM06",
                            "REPPE06",
                            "SADBS06",
                            "SADBP06",
                            "SADBE06"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "REPPM06",
            "TITRE": "PPM2E S6 PROJET PRO VERS METIERS DE L'ENSEIGNEMENT ET L'EDUC",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "CT",
                    "CHOIX": [
                        3,
                        [
                            "REPPM06",
                            "REPPE06",
                            "SADBS06",
                            "SADBP06",
                            "SADBE06"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "REPPE06",
            "TITRE": "PPM2E + EFME S6 ENSEIGNER LE FRANCAIS ET LES MATHS A L'ECOLE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "CT",
                    "CHOIX": [
                        3,
                        [
                            "REPPM06",
                            "REPPE06",
                            "SADBS06",
                            "SADBP06",
                            "SADBE06"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "SADBE06",
            "TITRE": "SAE DEFENDRE SON BILAN D'ENGAGEMENT ET DE COMPETENCES",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "CT",
                    "CHOIX": [
                        3,
                        [
                            "REPPM06",
                            "REPPE06",
                            "SADBS06",
                            "SADBP06",
                            "SADBE06"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 1,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        }
    ]
})