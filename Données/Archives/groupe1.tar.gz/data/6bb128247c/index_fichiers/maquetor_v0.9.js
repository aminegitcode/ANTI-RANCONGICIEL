let _mouture='full' 
// classe representant un bloc de modules, correspondant a l'objet BLOC du format JSON Maquetor
class Bloc{

	// le parametre est un objet BLOC au format Maquetor
	constructor(json){
		Object.assign(this,json)
	}

	getID(){ return this.ID }
	
	getNom(){ return this.NOM }
	
	getDescription(){ return this.DESCRIPTION }

}// classe representant les informations generales sur une formation, correspondant a l'objet FORMATION du format JSON Maquetor
class Formation{

	// le parametre est un objet FORMATION au format Maquetor
	constructor(json){
		Object.assign(this,json)
		this.PARCOURS = this.PARCOURS.map((p) => new Parcours(p))
		this.BLOCS = this.BLOCS.map((b) => new Bloc(b))
	}

	getNom(){ return this.NOM }
	
	getEtablissement(){ return this.ETABLISSEMENT }
	
	getAnnees(){ return this.ANNEES }
	
	getLMD(){ return this.LMD }
	
	getNbSemestres(){ return this.NB_SEMESTRES }
	
	getM3C(){ return this.M3C }
	
	getResponsables(){ return this.RESPONSABLES }
	
	getPresentation(){ return this.PRESENTATION }
	
	// retourne les parcours de la formation
	getParcours(){ return this.PARCOURS }

	// retourne le parcours d'id donne
	getParcoursByID(idpar){
		for(let p of this.PARCOURS){
    		if(p.getID() == idpar) return p
  		}
		return null
	}

	// retourne la liste des parcours de l'annee a
	parcoursDeAnnee(a){ return this.PARCOURS.filter((e) => e.isAnnee(a)) }

	// retourne la position du parcours donne parmi les parcours
	getIndexParcours(par){
		let i = 0
  		for(let p of this.PARCOURS){
			if(par.getID() == p.getID()) return i
    		i++
  		}
  		return -1
	}

	// retourne la description des parcours dans une chaine
	parcoursToString(){
		let s = ''
		for(let i=0;i<this.PARCOURS.length;i++){
			s += '<br>&bull; <b>'+this.PARCOURS[i].getNom()+'</b> ('
			let ann = this.PARCOURS[i].getAnnees()
			for(let j=0;j<ann.length;j++){
				s += this.LMD+ann[j]
				if(j!=ann.length-1) s += ', '
				else s += ')'
    		}
			s += ' : '+this.PARCOURS[i].getDescription()
		}
  		return s
	}

	// retourne la liste des blocs
	getBlocs(){ return this.BLOCS }

	// retourne le bloc d'id donne
	getBlocByID(idbc){
		for(let bc of this.BLOCS){
    		if(bc.getID()==idbc) return bc
  		}
  		return null
	}

	// retourne la position du bloc donne parmi les blocs
	getIndexBloc(bloc){
		if(bloc!=null){
			let i = 0
  			for(let bc of this.BLOCS){
				if(bc.getID() == bloc.getID()) return i
    			i++
  			}
  		}
  		return -1
	}

	// renvoie le tableau des combinaisons de choix de parcours des etudiants au long du diplome
	// chaque combinaison est la liste des parcours suivis chaque annee (valeur null si pas de parcours dans cette annee)
	genereCheminsEtudiants(){
		let chemins = [[]]
		for(let a=1;a<=this.NB_SEMESTRES/2;a++){
    		let pa = []
			for(let p of this.parcoursDeAnnee(a)) pa.push(p)
			if(pa.length==0){
  				for(let c of chemins) c.push(null)
			}
			else{
				let newChem = []
  				for(let c of chemins){
		        	for(let p of pa){
		          		let clone = c.slice()
		          		clone.push(p)
		          		newChem.push(clone)
		        	}
		      	}
		      	chemins = newChem.slice()
		    }
		}
		return chemins
	}
	
}class Maquette{
	static maq = 0 // indice de la maquette courante
	static listMaq = []

	// la maquette d'indice index devient la maquette courante
	static set(index){
		if(index>=0 && index<Maquette.listMaq.length) Maquette.maq = index
	}

	// retourne la maquette courante
	static get(){ return Maquette.listMaq[Maquette.maq] }


	// le parametre est un objet au format Maquetor
	constructor(json){
		Object.assign(this,json)
		this.FORMATION = new Formation(this.FORMATION)
		this.MODULES = this.MODULES.map((m) => new Module(m))
		Maquette.listMaq.push(this)
	}

	getFormation(){ return this.FORMATION }

	getModules(){ return this.MODULES }

	getModuleByID(idm){
		for(let m of this.MODULES){
			if(m.ID==idm) return m
		}
		return null
	}

	// retourne les modules annuels de l'annee, du bloc et du parcours (y compris modules hors parcours)
	// si bloc==null, ou par==null, ne tient pas compte du bloc ou du parcours
	getModulesAnnuels(ann,bloc=null,par=null){
		let t = []
		for(let m of this.MODULES){
			if(m.getSemestres().length==2 && m.getAnnee()==ann && m.getECTS(bloc==null ? null : bloc.getID(),par==null ? null : par.getID())!=null) t.push(m)
		}
		return t
	}

	// retourne les modules semestriels du semestre, du bloc et du parcours
	// si bloc==null, ou par==null, ne tient pas compte du bloc ou du parcours
	getModulesSemestriels(sem,bloc=null,par=null){
		let t = []
		for(let m of this.MODULES){
			if(m.getSemestres().length==1 && m.getSemestres().includes(sem) && m.getECTS(bloc==null ? null : bloc.getID(),par==null ? null : par.getID())!=null) t.push(m)
		}
		return t
	}
	
	// retourne l'effectif max des modules du semestre
	getEffectifMaxSemestre(nsem){
  		let max = 0
		for(let m of this.MODULES){
			if(m.getSemestres().includes(nsem) && m.getEffectif()>max) max = m.getEffectif()
		}
  		return max
	}

	// renvoie true si au moins un module ayant lieu l'annee a appartient au bloc, partiellement ou pas
	// si idpar!=null, se restreint au parcours
	blocDansAnnee(a,idbloc,idpar=null){
		for(let m of Maquette.get().getModules()){
			if(m.getAnnee()==a && m.getBlocsID(idpar).includes(idbloc)) return true
  		}
  		return false
	}

	// retourne le nombre de modules dependants, directement ou pas de m
	nbModulesDependants(m){
		let dep = []
		for(let p of this.MODULES){
			if(p.PREREQUIS.includes(m.getID())) dep.push(p)
		}
		let n = 0
		for(let p of dep) n += this.nbModulesDependants(p)
		return n+dep.length
	}

}class Module{
	
	// le parametre est un objet MODULE au format Maquetor
	constructor(json){
		Object.assign(this,json)
		this.STATUT = this.STATUT.map((s) => new Statut(s))
	}

	getID(){ return this.ID }
	
	getTitre(){ return this.TITRE }
	
	getType(){ return this.TYPE }

	// retourne le tableau des numeros des semestres ou le module apparait (1 valeur pour un module semestriel, 2 pour un module annuel)
	getSemestres(){ return Array.isArray(this.SEMESTRE) ? this.SEMESTRE : [this.SEMESTRE] }

	// retourne l'annee ou a lieu le module (1, 2 voire 3)
	getAnnee(){ return Array.isArray(this.SEMESTRE) ? parseInt((this.SEMESTRE[0]+1)/2) : parseInt((this.SEMESTRE+1)/2) }

	// retourne les objectifs sous forme de tableau de chaines
	getObjectifs(){ return this.OBJECTIFS }
	
	// retourne le contenu sous forme de tableau de chaines
	getContenu(){ return this.CONTENU }

	// retourne le tableau des ID des modules requis par this
	getPrerequis(){ return this.PREREQUIS }

	// retourne le tableau des modules ayant this pour prerequis direct
	estPrerequis(){
		let r = []
  		for(let n of Maquette.get().getModules()){
    		if(n.PREREQUIS.includes(this.ID)) r.push(n)
  		}
  		return r
	}

	getCM(){ return this.CM }
	
	getTD(){ return this.TD }
	
	getTP(){ return this.TP }
	
	getGroupesCM(){ return this.GROUPES_CM }
	
	getGroupesTD(){ return this.GROUPES_TD }
	
	getGroupesTP(){ return this.GROUPES_TP }
	
	getEffectif(){ return this.EFFECTIF }
	
	getSession1(){ return this.M3C.SESSION_1 }
	
	getSecondeChance(){ return this.M3C.SECONDE_CHANCE }
	
	getSession2(){ return this.M3C.SESSION_2 }
	
	getResponsables(){ return this.ENSEIGNANTS.RESPONSABLES }
	
	getIntervenants(){ return this.ENSEIGNANTS.INTERVENANTS }

	// retourne le coefficient dans [0,1] de cout dans la formation, s'il existe, 1 sinon
	getCoutFormation(){ return this.hasOwnProperty('COUT') ? this.COUT : 1 }

	getCout(){ return this.CM*this.GROUPES_CM*1.5+this.TD*this.GROUPES_TD+this.TP*this.GROUPES_TP }

	getNotes(){ return this.hasOwnProperty('NOTES') ? this.NOTES : [] }

	getStyle(){ return this.hasOwnProperty('STYLE') ? this.STYLE : null }

	// affecte une position d'affichage au module
	setPosition(x,y){
		this.X = x
		this.Y = y
	}

	getX(){
		if(this.hasOwnProperty('X')) return this.X
  		else return 0
	}

	getY(){
		if(this.hasOwnProperty('Y')) return this.Y
  		else return 0
	}

	// renvoie l'index minimum des blocs du module
	// renvoie -1 s'il n'y a pas de bloc
	getMinBloc(){
		let idblocs = this.getBlocsID()
		let blocs = Maquette.get().getFormation().getBlocs()
	  	let min = -1
	  	for(let i=blocs.length-1;i>-1;i--){
	  		if(idblocs.includes(blocs[i].getID())) min = i
	  	}
		return min
	}

	// renvoie l'index minimum des parcours du module
	// renvoie -1 s'il n'y a pas de parcours
	getMinParcours(){
		let idpars = this.getParcoursID()
		let pars = Maquette.get().getFormation().getParcours()
	  	let min = -1
	  	for(let i=pars.length-1;i>-1;i--){
	  		if(idpars.includes(pars[i].getID())) min = i
	  	}
		return min
	}

	// retourne une valeur>0 si this>m, 0 si this=m et une valeur<0 si this<m
	// criteres : ordre des blocs (bloc min si plusieurs) puis modalite (obli/option) puis parcours
	compare(m){
		let diff = this.getMinBloc()-m.getMinBloc()
		if(diff==0){
			diff = this.getModalite()-m.getModalite()
	    	if(diff==0){
	    		return this.getMinParcours()-m.getMinParcours()
		    }
		    else return diff
		}
		else return diff
	}

	// retourne le tableau des ID des parcours ou le module apparait (en obligatoire, optionnel et/ou a choix), [] s'il est hors parcours
	getParcoursID(){
		let t = []
		for(let i=0;i<this.STATUT.length;i++){
			if(this.STATUT[i].hasOwnProperty('PARCOURS')) t.push(this.STATUT[i].PARCOURS)
		}
		return t
	}

	// retourne le tableau des ID des blocs ou le module apparait, partiellement ou pas
	// si idpar!=null, se restreint au parcours
	getBlocsID(idpar=null){
		let t = []
		for(let i=0;i<this.STATUT.length;i++){
			if(idpar==null || (idpar!=null && (!this.STATUT[i].hasOwnProperty('PARCOURS') || (this.STATUT[i].PARCOURS==idpar)))) this.STATUT[i].getBlocsID().forEach((bid) => { if(!t.includes(bid)) t.push(bid) })
		}
		return t
	}

	// retourne la modalite pour le parcours donne, parmi NONE, OBLIGATOIRE, OBLIGATOIRE_A_CHOIX, OPTIONNEL et OPTIONNEL_A_CHOIX
	// si idpar==null, retourne la modalite hors parcours ou la modalite des parcours s'ils ont tous la meme modalite
	getModalite(idpar=null){
    	let mod = Statut.NONE
    	for(let i=0;i<this.STATUT.length;i++){
      		let n = this.STATUT[i].getModalite()
      		if(!this.STATUT[i].hasOwnProperty('PARCOURS')) return n
      		else{
	      		if(idpar==null) mod = mod==Statut.NONE ? n : (mod!=n) ? -1 : n
    	  		else{
        			if(this.STATUT[i].PARCOURS==idpar) return n
      			}
      		}
    	}
    	return mod==-1 ? Statut.NONE : (this.getParcoursID().length==Maquette.get().getFormation().parcoursDeAnnee(this.getAnnee()).length) ? mod : Statut.NONE
  	}

  	// retourne le tableau de choix [ects,[choix...]] si le module est a choix dans le parcours ou hors parcours, renvoie null sinon
  	// si par==null retourne le tableau [ects,[choix...]] si le module est a choix hors parcours
  	getChoix(par=null){
  		for(let i=0;i<this.STATUT.length;i++){
  			if(this.STATUT[i].hasOwnProperty('CHOIX')){
	      		let t = this.STATUT[i].CHOIX
	      		if(!this.STATUT[i].hasOwnProperty('PARCOURS')) return t
    	  		else{
	    	  		if(par!=null && this.STATUT[i].PARCOURS==par.getID()) return t
      			}
    		}
  		}
  		return null
  	}

  	statutToHTML(){
  		let text = '<u>STATUT</u> : '
	    if(this.STATUT.length!=0){
	      if(this.STATUT.length==1 && !this.STATUT[0].hasOwnProperty('PARCOURS')){
	        if(this.STATUT[0].hasOwnProperty('CHOIX')) text += this.STATUT[0].MODALITE+' à choix ('+this.STATUT[0].CHOIX[0]+' ECTS parmi '+Statut.choixToString(this.STATUT[0].CHOIX[1])+')'
	        else text += this.STATUT[0].MODALITE
	        text += ', '+this.STATUT[0].ECTStoString()
	        return text
	      }
	      else{
	        let text = ''
	        for(let i=0;i<this.STATUT.length;i++){
	          let sp = this.STATUT[i]
	          if(sp.hasOwnProperty('PARCOURS')){
	            text += '<u>STATUT en '+Maquette.get().getFormation().getParcoursByID(sp.PARCOURS).getNom()+'</u> : '
	            if(sp.hasOwnProperty('CHOIX')) text += sp.MODALITE+' à choix ('+sp.CHOIX[0]+' ECTS parmi '+Statut.choixToString(sp.CHOIX[1])+')'
	            else text += sp.MODALITE
	            text += ', '+sp.ECTStoString()+'<br>'
	          }
	        }
	        if(text.length>3) text = text.substring(0,text.length-4) // enleve le dernier <br>
	        return text
	      }
	    }
	    return text
  	}

  	// retourne la moyenne des ECTS du statut sur les parcours, tous blocs confondus
	getECTS_moyens(){
		switch(this.STATUT.length){
      		case 0 : return 0
      		case 1 : return this.STATUT[0].getECTS()
      		default :
        		let r = 0
        		for(let i=0;i<this.STATUT.length;i++) r += this.STATUT[i].getECTS()
                return r/this.STATUT.length
    	}
  	}

  	// retourne la representation textuelle des ECTS du module
	ECTSToString(){
    	let t = []
    	for(let i=0;i<this.STATUT.length;i++){
      		let e = this.STATUT[i].getECTS()
      		if(!t.includes(e)) t.push(e)
    	}
    	return t.join(' / ')
  	}

	// retourne le nombre d'ECTS du module pour le bloc idbc dans le parcours idparc, null s'il n'y en a pas
	// si idpar==null, retourne les ECTS hors parcours
	getECTS(idbloc,idpar=null){
		for(let i=0;i<this.STATUT.length;i++){
			if(idpar==null){
				if(!this.STATUT[i].hasOwnProperty('PARCOURS')) return this.STATUT[i].getECTS(idbloc)
			}
			else{
				if(!this.STATUT[i].hasOwnProperty('PARCOURS') || (this.STATUT[i].hasOwnProperty('PARCOURS') && this.STATUT[i].PARCOURS==idpar)) return this.STATUT[i].getECTS(idbloc)
			}
		}
		return null
	}

	// retourne le nombre d'heures etudiant du module pour le bloc idbloc dans le parcours idpar, null s'il n'y en a pas
	// les heures sont comptees au prorata des ECTS affectes au bloc
	// si idpar==null, retourne les heures hors parcours
	getHeures(idbloc,idpar=null){
		for(let i=0;i<this.STATUT.length;i++){
			if(idpar==null){
				if(!this.STATUT[i].hasOwnProperty('PARCOURS')){
					let poids = this.STATUT[i].getECTS(idbloc)
					let total = this.STATUT[i].getECTS()
					let heures = this.CM+this.TD+this.TP
					return total==0 ? heures : poids*heures/total
				}
			}
			else{
				if(!this.STATUT[i].hasOwnProperty('PARCOURS') || (this.STATUT[i].hasOwnProperty('PARCOURS') && this.STATUT[i].PARCOURS==idpar)){
					let poids = this.STATUT[i].getECTS(idbloc)
					let total = this.STATUT[i].getECTS()
					let heures = this.CM+this.TD+this.TP
					return total==0 ? heures : poids*heures/total
				}
			}
		}
		return null
	}
}// classe representant un parcours de formation, correspondant a l'objet PARCOURS du format JSON Maquetor
class Parcours{

	// le parametre est un objet PARCOURS au format Maquetor
	constructor(json){
		Object.assign(this,json)
	}

	getID(){ return this.ID }
	
	getNom(){ return this.NOM }
	
	getDescription(){ return this.DESCRIPTION }
	
	// retourne le tableau des annees ou le parcours existe
	getAnnees(){ return this.ANNEES }
	
	// retourne true si le parcours existe pour l'annee a
	isAnnee(a){ return this.ANNEES.includes(a) }
	
}// classe representant un statut de module, correspondant a l'objet STATUT du format JSON Maquetor
class Statut{

  static NONE=4
  static OBLIGATOIRE=0
  static OBLIGATOIRE_A_CHOIX=1
  static OPTIONNEL=2
  static OPTIONNEL_A_CHOIX=3

  // le parametre est un objet de STATUT au format Maquetor
  constructor(json){
    Object.assign(this,json)
  }

  // retourne le nombre total d'ECTS du statut pour le bloc d'id donne, null s'il n'y en a pas
  // si idbloc==null, retourne le nombre total d'ECTS
  getECTS(idbloc=null){ 
    if(this.hasOwnProperty('ECTS')){
      if(idbloc==null) return Array.isArray(this.ECTS) ? this.ECTS.reduce((acc,val) => acc+val,0) : this.ECTS
      else{
        if(this.hasOwnProperty('BLOCS')){
          if(Array.isArray(this.BLOCS)){
            for(let i=0;i<this.BLOCS.length;i++){
              if(this.BLOCS[i]==idbloc) return this.ECTS[i]
            }
            return null
          }
          else return this.BLOCS==idbloc ? this.ECTS : null
        }
        else return null
      }
    }
    else return null
  }

  // retourne les blocs du statut
  getBlocsID(){
    if(this.hasOwnProperty('BLOCS')){
      if(Array.isArray(this.BLOCS)) return this.BLOCS
      else return [this.BLOCS]
    }
    else return []
  }

  // renvoie la modalite du statut parmi OBLIGATOIRE, OBLIGATOIRE_A_CHOIX, OPTIONNEL et OPTIONNEL_A_CHOIX
  getModalite(){
    if(this.MODALITE=='obligatoire') return this.hasOwnProperty('CHOIX') ? Statut.OBLIGATOIRE_A_CHOIX : Statut.OBLIGATOIRE
    else return this.hasOwnProperty('CHOIX') ? Statut.OPTIONNEL_A_CHOIX : Statut.OPTIONNEL
  }

  // retourne true si les deux tableaux de choix sont identiques
  static sameChoix(c1,c2){
    if(c1.length==c2.length){
      for(let v of c1){
        let r = false
        for(let w of c2){
          if(Array.isArray(v)){
            if(Array.isArray(w) && (v.length==w.length) && v.every((x) => w.includes(x))) r = true
          }
          else{
            if(!Array.isArray(w) && v==w) r = true
          }
        }
        if(!r) return false
      }
      return true
    }
    else return false
  }

  // retourne une chaine decrivant les choix du tableau de choix
  static choixToString(tabChoix){
    let t = ''
    for(let c of tabChoix){
      if(Array.isArray(c)){ // groupe d'UEs
          for(let i=0;i<c.length-1;i++) t += Maquette.get().getModuleByID(c[i]).TITRE+' + '
          t += Maquette.get().getModuleByID(c[c.length-1]).TITRE+', '
      }
      else t += Maquette.get().getModuleByID(c).TITRE+', ' // UE seule
    }
    return t.length>2 ? t.substr(0,t.length-2) : t
  }

  // retourne une chaine indiquant les ECTS du statut, avec le parcours eventuellement, et les blocs s'il y a lieu
  ECTStoString(){
    if(this.hasOwnProperty('ECTS')){
      let r = ''
      if(Array.isArray(this.ECTS)){
        for(let i=0;i<this.ECTS.length;i++) r += this.ECTS[i]+' ECTS en '+Maquette.get().getFormation().getBlocByID(this.BLOCS[i]).getNom()+' + '
        return r.substring(0,r.length-3)
      }
      else{
        if(this.hasOwnProperty('BLOCS')){
          let bb = Maquette.get().getFormation().getBlocByID(this.BLOCS)
          bb==null ? r +=this.ECTS + ' ECTS' : r += this.ECTS+' ECTS en '+bb.getNom()
        }
        return r
      }
    }
    else return '0'
  }

}
// classe de gestion des decoration de domaine
class Domaine{
	static dom = 0 // indice du domaine courant
	static listDom = []
	
	constructor(){}

	static add(objDom){ Domaine.listDom.push(objDom) }

	static set(nom){
		let c = -1
		for(let i=0;i<Domaine.listDom;i++){
			if(Domaine.listDom[i].getName()==nom) c= i
		}
		if(c!=-1) Domaine.dom = c
	}

	static getAll(){ return Domaine.listDom }

	// x,y=centre; h=hauteur
	static dessineMotif(svg,x,y,h){ Domaine.listDom[Domaine.dom].dessineMotif(svg,x,y,h) }

}// colorie la forme svg fournie avec des bandes des couleurs et ajoute le coloriage dans le svg
// cols : tableau de couleurs (au moins une couleur) 
// prop (optionnel) : tableau des proportions des couleurs exprimees en % (si prop n'est pas precise, les bandes colorees ont toutes la meme largeur)
// axe (optionnel) : 0=diagonale de [h,w] (par defaut), 1=horizontal
function coloriage(svg,forme,cols,prop,axe){
  let bb = forme.getBBox()
  let x = bb.x
  let y = bb.y
  let w = bb.width
  let h = bb.height
   // generation du clip pour borner le coloriage
  let c = document.createElementNS(svg.namespaceURI,'clipPath')
  c.setAttribute('id','rect_'+x+'_'+y)
  c.appendChild(forme.cloneNode())
  svg.appendChild(c)
  // generation du coloriage
  let angle = -1*Math.atan(h/w)
  let longueur = Math.sqrt(w*w+h*h)
  let largeur = 2*h*Math.cos(angle)/cols.length
  if(axe==1){
    angle = 0
    longueur = w
    largeur = h/cols.length
  }
  let yBase = y+h/2-largeur*cols.length/2
  let lar = largeur
  let g = document.createElementNS(svg.namespaceURI,'g')
  g.setAttribute('transform','rotate('+(angle*180/Math.PI)+' '+(x+w/2)+' '+(y+h/2)+')')
  for(let i=0;i<cols.length;i++){
    if(prop!==undefined) lar = prop[i]*cols.length*largeur/100
    let l = document.createElementNS(svg.namespaceURI,'line')
    l.setAttribute('x1',x+(w-longueur)/2)
    l.setAttribute('y1',yBase+lar/2)
    l.setAttribute('x2',x+(w+longueur)/2)
    l.setAttribute('y2',yBase+lar/2)
    l.setAttribute('stroke',cols[i])
    l.setAttribute('stroke-width',lar)
    g.appendChild(l)
    yBase = yBase+lar
  }
  let gClip = document.createElementNS(svg.namespaceURI,'g')
  gClip.setAttribute('clip-path','url(#rect_'+x+'_'+y+')')
  gClip.appendChild(g)
  svg.insertBefore(gClip,forme)
}

// genere, ajoute au svg et renvoie un arc liant les deux points et de rayon donne
function generateArc(svg,x1,y1,x2,y2,r,stroke){
  let arc = document.createElementNS(svg.namespaceURI,'path')
  arc.setAttribute('d','M '+x1+' '+y1+' A '+r+' '+r+' 0 0 1 '+x2+' '+y2)
  arc.style = 'fill:none;stroke:'+stroke
  svg.appendChild(arc)
  return arc
}

// genere, ajoute au svg et renvoie un disque de centre x,y, de rayon r, de couleur col avec l'appel de fonction clic en cas de clic (si pas de clic, ne pas utiliser ce parametre)
function generateCircle(svg,x,y,r,fill,stroke,clic){
  let circ = document.createElementNS(svg.namespaceURI,'circle')
  circ.setAttribute('cx',x)
  circ.setAttribute('cy',y)
  circ.setAttribute('r',r)
  circ.setAttribute('stroke',stroke)
  circ.setAttribute('fill',fill)
  if(clic!==undefined){
    circ.style.cursor = 'pointer'
    let link = document.createElementNS(svg.namespaceURI,'a')
    link.setAttribute('href','javascript:'+clic)
    link.appendChild(circ)
    svg.appendChild(link)
  }
  else svg.appendChild(circ)
  return circ
}

// genere, ajoute au svg un demidisque d'extremites donnees, situe 'a droite' du segment et de couleur col
function generateSemiCircle(svg,x1,y1,x2,y2,col){
  let arc = document.createElementNS(svg.namespaceURI,'path')
  let r = Math.sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1))/2
  arc.setAttribute('d','M '+x1+' '+y1+' A '+r+' '+r+' 0 0 1 '+x2+' '+y2)
  arc.style = 'fill:'+col
  svg.appendChild(arc)
  return arc
}

function generateLine(svg,x1,y1,x2,y2,color,width){
  let l = document.createElementNS(svg.namespaceURI,'line')
  l.setAttribute('x1',x1)
  l.setAttribute('y1',y1)
  l.setAttribute('x2',x2)
  l.setAttribute('y2',y2)
  l.setAttribute('style','stroke:'+color+';stroke-width:'+width)
  svg.appendChild(l)
  return l
}

// points est un tableau de [x,y]
function generatePolygon(svg,points,fill,stroke,width){
  let p = document.createElementNS(svg.namespaceURI,'polygon')
  let pts= ''
  for(let i=0;i<points.length;i++) pts += points[i][0]+','+points[i][1]+' '
  p.setAttribute('points',pts)
  p.setAttribute('style','fill:'+fill+';stroke:'+stroke+';stroke-width:'+width)
  svg.appendChild(p)
  return p
}

// stroke, fill et clic sont optionnels
function generateRect(svg,x,y,w,h,r,stroke,fill,clic){
  let rect = document.createElementNS(svg.namespaceURI,'rect')
  rect.setAttribute('x',x)
  rect.setAttribute('y',y)
  rect.setAttribute('width',w)
  rect.setAttribute('height',h)
  rect.setAttribute('rx',r)
  rect.setAttribute('ry',r)
  if(stroke!==undefined) rect.setAttribute('stroke',stroke)
  if(fill!==undefined) rect.setAttribute('fill',fill)
  if(clic!==undefined){
    rect.style.cursor = 'pointer'
    let link = document.createElementNS(svg.namespaceURI,'a')
    link.setAttribute('href','javascript:'+clic)
    link.appendChild(rect)
    svg.appendChild(link)
  }
  else svg.appendChild(rect)
  return rect
}

// genere et retourne un camembert de rayon r avec les couleurs du tableau cols et les valeurs du tableau vals
function camembert(svg,r,cols,vals){
  let gap = 2
  let cam = document.createElementNS("http://www.w3.org/2000/svg",'svg')
  cam.setAttribute('width',2*(r+gap))
  cam.setAttribute('height',2*(r+gap))
  let x = r+gap
  let y = r+gap
  if(cols.length==1){
    let c = document.createElementNS(svg.namespaceURI,'circle')
    c.setAttribute('cx',x)
    c.setAttribute('cy',y)
    c.setAttribute('r',r)
    c.setAttribute('fill',cols[0])
    cam.appendChild(c)
  }
  else{
    let a=x, b=gap, angle=-1*Math.PI/2
    let s = 0
    for(let v of vals) s = s+v
    for(let i=0;i<vals.length;i++){
      let p = document.createElementNS(svg.namespaceURI,'path')
      angle = angle+vals[i]*2*Math.PI/s
      let c=x+r*Math.cos(angle), d=y+r*Math.sin(angle)
      let flag = 0
      if(vals[i]>s/2) flag = 1
      p.setAttribute('d','M'+x+' '+y+' L'+a+' '+b+' A'+r+' '+r+' 0 '+flag+' 1 '+c+' '+d+' z')
      p.setAttribute('stroke',cols[i])
      p.setAttribute('fill',cols[i])
      cam.appendChild(p)
      a=c; b=d
    }
  }
  return cam
}

// genere et ajoute au svg le texte a la position donnee et avec la taille de police donnee et renvoie l'element svg genere (pour le cacher eventuellement)
// fontWeight est optionnel
function generateText(svg,x,y,fontSize,text,fontWeight){
  let t = document.createElementNS(svg.namespaceURI,'text')
  t.setAttribute('x',x)
  t.setAttribute('y',y)
  t.setAttribute('font-size',fontSize)
  if(fontWeight!==undefined) t.setAttribute('font-weight',fontWeight)
  t.innerHTML = text
  svg.appendChild(t)
  return t
}

// genere une ligne animee entre les deux points avec la couleur donnee, ajoute les elements sur le svg et retourne la liste des elements
function generateLigneDependance(svg,x1,y1,x2,y2,col){
  let r = []
  let l = document.createElementNS(svg.namespaceURI,'path')
  l.setAttribute('d','M'+x1+','+y1+'L'+x2+','+y2)
  l.setAttribute('fill','none')
  l.setAttribute('stroke-width',1+_wECTS*0.0725)
  l.setAttribute('stroke',col)
  l.setAttribute('stroke-dasharray',10)
  let a = document.createElementNS(svg.namespaceURI,'animate')
  a.setAttribute('dur','2s')
  a.setAttribute('repeatCount','indefinite')
  a.setAttribute('attributeName','stroke-dashoffset')
  a.setAttribute('values','100;0')
  l.appendChild(a)
  svg.appendChild(l)
  r.push(l)
  l =  document.createElementNS(svg.namespaceURI,'circle')
  l.setAttribute('cx',x1)
  l.setAttribute('cy',y1)
  l.setAttribute('r',1+_wECTS*0.109)
  l.setAttribute('stroke',col)
  l.setAttribute('fill',col)
  svg.appendChild(l)
  r.push(l)
  l =  document.createElementNS(svg.namespaceURI,'circle')
  l.setAttribute('cx',x2)
  l.setAttribute('cy',y2)
  l.setAttribute('r',1+_wECTS*0.109)
  l.setAttribute('stroke',col)
  l.setAttribute('fill',col)
  svg.appendChild(l)
  r.push(l)
  return r
}

function rigolo(){
 for(let e of _svg.getElementsByTagName('rect')){
    e.x.baseVal.value = e.x.baseVal.value + Math.floor(-15+Math.random()*30)
    e.y.baseVal.value = e.y.baseVal.value + Math.floor(-15+Math.random()*30)
  }
  for(let e of _svg.getElementsByTagName('path')){
    e.setAttribute('transform','translate('+(-15+Math.random()*30)+','+(-15+Math.random()*30)+')')
  }
  for(let e of _svg.getElementsByTagName('polygon')){
    e.setAttribute('transform','translate('+(-15+Math.random()*30)+','+(-15+Math.random()*30)+')')
  }
  for(let e of _svg.getElementsByTagName('ellipse')){
    e.setAttribute('transform','translate('+(-15+Math.random()*30)+','+(-15+Math.random()*30)+')')
  }
  for(let e of _svg.getElementsByTagName('circle')){
    e.setAttribute('transform','translate('+(-15+Math.random()*30)+','+(-15+Math.random()*30)+')')
  }
  for(let e of _svg.getElementsByTagName('line')){
    e.setAttribute('transform','translate('+(-15+Math.random()*30)+','+(-15+Math.random()*30)+')')
  }
}

// classe de gestion des jeux de couleur
class Style{
	static couleurs = 0 // indice du jeu de couleurs courant
	static forme = 1 // indice de la forme courante

	static listCoul = []
	static listForm = []

	static addForme(objForme){ Style.listForm.push(objForme) }
	static addCouleurs(objCouleurs){ Style.listCoul.push(objCouleurs) }

	static setForme(index){	if(index>=0 && index<Style.listForm.length) Style.forme = index	}
	static setCouleurs(index){ if(index>=0 && index<Style.listCoul.length) Style.couleurs = index }

	static getFormeList(){ return Style.listForm }
	static getCouleursList(){ return Style.listCoul }

	static getIndexForme(){ return Style.forme }
	static getIndexCouleurs(){ return Style.couleurs }

	// passe aux formes suivantes
	static nextForme(){ Style.forme = (Style.forme+1)%Style.listForm.length }

	// passe au jeu de couleurs suivant
	static nextCouleurs(){ Style.couleurs = (Style.couleurs+1)%Style.listCoul.length }

	static colorChoix(){ return Style.listCoul[Style.couleurs].colorChoix() }

	// couleurs d'un parcours, id : identifiant d'un parcours parmi la liste d'id
	static colorParcours(id,idList){ return Style.listCoul[Style.couleurs].colorParcours(id,idList) }

	// couleurs d'un bloc, id : identifiant d'un bloc parmi la liste d'id
	static colorBloc(id,idList){ return Style.listCoul[Style.couleurs].colorBloc(id,idList) }
	
	// couleur des lignes de dependance entre modules en fonction du nombre de dependances
	static colorDependance(n){ return Style.listCoul[Style.couleurs].colorDependance(n) }

	// dessine le module sur le svg en x,y avec les dimensions w,h
	// type : n'importe quel type y compris 'SAE' et 'STAGE'
	// obli : true si le module est obligatoire hors parcours, false sinon
	// aChoix : true si le module est a choix hors parcours, false sinon
	// cols : le tableau des couleurs de blocs du module
	// prop : proportions en % des couleurs du tableau cols, eventuellement [] pour repartition egale
	// decosPar (optionnel) : tableau des couleurs/modalite/choix des parcours du module, [] eventuellement
	static dessineModule(svg,x,y,w,h,type,obli,aChoix,cols,prop,decosPar){
		Style.listForm[Style.forme].dessineModule(svg,x,y,w,h,type,obli,aChoix,cols,prop,decosPar)
	}

}class Coins{
		
	static { Style.addForme(new Coins()) } // pour gestion centralisee des formes

	constructor(){
		this.hChoix = 1/8
	}

	getName(){ return 'Coins' }

	// dessine le module sur le svg en x,y avec les dimensions w,h
	// type : n'importe quel type y compris 'SAE' et 'STAGE'
	// mod : modalite hors parcours (voir les valeurs possibles dans Statut)
	// cols : le tableau des couleurs de blocs du module
	// prop : proportions en % des couleurs du tableau cols, eventuellement [] pour repartition egale
	// decosPar (optionnel) : tableau des couleurs/modalite des parcours du module, [] eventuellement
	dessineModule(svg,x,y,w,h,type,mod,cols,prop,decosPar){
		if(decosPar!==undefined){
			let rcoin = 8*h/getModule_height()
	  		let d = _wOffset*0.6
	  		let y1 = y+rcoin
			for(let deco of decosPar){
				generateRect(svg,x+w,y1,d/2,d,0,deco[0],deco[0])
				if(deco[1]==Statut.OBLIGATOIRE || deco[1]==Statut.OBLIGATOIRE_A_CHOIX) generateSemiCircle(svg,x+w+d/2,y1,x+w+d/2,y1+d,deco[0])
				if(deco[1]==Statut.OPTIONNEL || deco[1]==Statut.OPTIONNEL_A_CHOIX) generatePolygon(svg,[[x+w+d/2,y1],[x+w+d,y1+d/2],[x+w+d/2,y1+d]],deco[0],deco[0],1)
				let rchoix = d*0.4
				if(deco[1]==Statut.OBLIGATOIRE_A_CHOIX || deco[1]==Statut.OPTIONNEL_A_CHOIX) generatePolygon(svg,[[x+w,y1+d/2-rchoix],[x+w+1.3*rchoix,y1+d/2],[x+w,y1+d/2+rchoix]],Style.colorChoix(),Style.colorChoix(),1)
					//generateSemiCircle(svg,x+w,y1+d/2-rchoix,x+w,y1+d/2+rchoix,Style.colorChoix())
				y1 += d+2
			}
		}
		let shape = this.genereRectangleRond(svg,x,y,w,h,mod==Statut.OBLIGATOIRE,type)
		coloriage(svg,shape,cols,prop)
		if(mod==Statut.OBLIGATOIRE_A_CHOIX || mod==Statut.OPTIONNEL_A_CHOIX){
			let r = Math.max(5,Math.min(h/8,w/8))
			//generateSemiCircle(svg,x+w/2+r,y,x+w/2-r,y,Style.colorChoix())
			generatePolygon(svg,[[x+w/2-r,y],[x+w/2,y+r],[x+w/2+r,y]],Style.colorChoix(),Style.colorChoix(),1)
		}
	}

	// coins : false pour des coins entrants, true pour des coins sortants
	genereRectangleRond(svg,x,y,w,h,coins,type){
		let rect
	  	let r = Math.max(5,h/10)
	  	if(coins) rect = generateRect(svg,x,y,w,h,r)
		else{
			rect = document.createElementNS(svg.namespaceURI,'path')
		    rect.setAttribute('d','M '+(x+w-r)+' '+y+' A '+r+' '+r+' 0 0 0 '+(x+w)+' '+(y+r)+' L '+(x+w)+' '+(y+h-r)+' A '+r+' '+r+' 0 0 0 '+(x+w-r)+' '+(y+h)+' L '+(x+r)+' '+(y+h)+' A '+r+' '+r+' 0 0 0 '+x+' '+(y+h-r)+' L '+x+' '+(y+r)+' A '+r+' '+r+' 0 0 0 '+(x+r)+' '+y+' Z')
		    svg.append(rect)
		}
		if(type=='SAE' || type=='STAGE') rect.setAttribute('stroke','black')
	  	else rect.setAttribute('stroke','rgb(100,100,100)')
  		if(type=='SAE' || type=='STAGE') rect.setAttribute('stroke-width',1.8)
		else rect.setAttribute('stroke-width',1.2)
  		if(type=='STAGE') rect.setAttribute('stroke-dasharray','3,3')
  		rect.setAttribute('fill','none')
		return rect
	}

	genereDecoration(svg,x,y,w,h,cols){
	  let rcoin = 8*h/getModule_height()
	  let d = _wOffset*0.8 // (h-2*rcoin)/3
	  let y1=y+rcoin
	  for(let c of cols){
	    generateSemiCircle(svg,x+w,y1,x+w,y1+d,c)
	    y1 += d
	  }
	}

}class Volume{

	static { Style.addForme(new Volume()) } // pour gestion centralisee des formes

	constructor(){
		this.angle = 45
		this.ueDepth = 0.25
		this.biseau = 8
		this.colorStroke = 'rgb(150,150,150)'
		this.colorFill = 'rgb(242,242,242)' // pour la perspective
	}

	getName(){ return 'Volume' }

	// dessine le module sur le svg en x,y avec les dimensions w,h
	// type : n'importe quel type y compris 'SAE' et 'STAGE'
	// mod : modalite hors parcours (voir les valeurs possibles dans Statut)
	// cols : le tableau des couleurs de blocs du module
	// prop : proportions en % des couleurs du tableau cols, eventuellement [] pour repartition egale
	// decosPar (optionnel) : tableau des couleurs/modalite/choix des parcours du module, [] eventuellement
	dessineModule(svg,x,y,w,h,type,mod,cols,prop,decosPar){
		let obli = mod==Statut.OBLIGATOIRE
		if(decosPar!==undefined) this.generePerspective(svg,x,y,w,h,decosPar,!obli)
		else this.generePerspective(svg,x,y,w,h,[],!obli)
		// generation du rectangle
		let rect
		if(obli) rect = generateRect(svg,x,y,w,h,0)
		else{
			let bs = h/this.biseau
			rect = document.createElementNS(svg.namespaceURI,'path')
			rect.setAttribute('d','M '+(x+bs)+' '+y+' L '+(x+w-bs)+' '+y+' L '+(x+w)+' '+(y+bs)+' L '+(x+w)+' '+(y+h-bs)+' L '+(x+w-bs)+' '+(y+h)+' L '+(x+bs)+' '+(y+h)+' L '+x+' '+(y+h-bs)+' L '+x+' '+(y+bs)+' Z')
			svg.appendChild(rect)
		}
		if(type=='SAE' || type=='STAGE') rect.setAttribute('stroke','black')
		else rect.setAttribute('stroke','rgb(100,100,100)')
		if(type=='SAE' || type=='STAGE') rect.setAttribute('stroke-width',1.8)
		else rect.setAttribute('stroke-width',1.2)
		if(type=='STAGE') rect.setAttribute('stroke-dasharray','3,3')
		rect.setAttribute('fill','none')
		coloriage(svg,rect,cols,prop,0)
		if(mod==Statut.OBLIGATOIRE_A_CHOIX || mod==Statut.OPTIONNEL_A_CHOIX){
			let r = Math.max(5,Math.min(h/8,w/8))
			//generateSemiCircle(svg,x+w/2+r,y,x+w/2-r,y,Style.colorChoix())
			generatePolygon(svg,[[x+w/2-r,y],[x+w/2,y+r],[x+w/2+r,y]],Style.colorChoix(),Style.colorChoix(),1)
		}
	}

	// ajoute le dessus et le cote du rectangle (x,y,w,h) en perspective
	// x,y : coin bas gauche
	// d : profondeur 
	// colsDessus : tableau de couleurs/modalite/choix (si vide, on ne remplit pas)
	// coins_coupes : true si le rectangle a des coins coupes
	generePerspective(svg,x,y,w,h,colsDessus,coins_coupes){
	  let dx = Math.max(5,this.ueDepth*Math.min(getModule_height(),h))*Math.cos(this.angle*Math.PI/180)
	  let dy = Math.max(5,this.ueDepth*Math.min(getModule_height(),h))*Math.sin(this.angle*Math.PI/180)
	  // le dessus
	  let posx = coins_coupes ? x+h/this.biseau : x
	  let wbis = coins_coupes ? w-2*h/this.biseau : w
	  let dw = colsDessus.length==0 ? wbis : wbis/colsDessus.length
	  if(colsDessus.length==0) generatePolygon(svg,[[posx,y],[posx+dw,y],[posx+dw+dx,y-dy],[posx+dx,y-dy]],this.colorFill,this.colorStroke,1)
	  else{
	    for(let c in colsDessus){
	    	if(colsDessus[c][1]==Statut.OBLIGATOIRE || colsDessus[c][1]==Statut.OBLIGATOIRE_A_CHOIX) generatePolygon(svg,[[posx,y],[posx+dw,y],[posx+dw+dx,y-dy],[posx+dx,y-dy]],colsDessus[c][0],this.colorStroke,1)
	    	if(colsDessus[c][1]==Statut.OPTIONNEL || colsDessus[c][1]==Statut.OPTIONNEL_A_CHOIX){
	    		generatePolygon(svg,[[posx,y],[posx+dw,y],[posx+dx,y-dy]],colsDessus[c][0],this.colorStroke,1)
	    		generatePolygon(svg,[[posx+dw,y],[posx+dw+dx,y-dy],[posx+dx,y-dy]],this.colorFill,this.colorStroke,1)
	    	}
	    	if(colsDessus[c][1]==Statut.OBLIGATOIRE_A_CHOIX || colsDessus[c][1]==Statut.OPTIONNEL_A_CHOIX) generatePolygon(svg,[[posx,y],[posx+dw/2,y],[posx+dx/2,y-dy/2]],Style.colorChoix(),Style.colorChoix(),1)
	    		//generatePolygon(svg,[[posx,y],[posx+dw/1.75,y-dy/2],[posx+dw,y]],Style.colorChoix(),Style.colorChoix(),1)
	    		
	      	posx += dw
	    }
	  }
	  // le cote
	  let posy = coins_coupes ? y+h/this.biseau : y
	  let hbis = coins_coupes ? h-2*h/this.biseau : h
	  generatePolygon(svg,[[x+w,posy],[x+w,posy+hbis],[x+w+dx,posy+hbis-dy],[x+w+dx,posy-dy]],this.colorFill,this.colorStroke,1)
	  // zigouigoui
	  if(coins_coupes){
	    posx = x+w-h/this.biseau
	    generatePolygon(svg,[[posx,y],[posx+h/this.biseau,y+h/this.biseau],[posx+h/this.biseau+dx,y+h/this.biseau-dy],[posx+dx,y-dy]],this.colorFill,this.colorStroke,1)
	  }
	}

}// une classe representant un jeu de couleurs pour l'affichage des maquettes
// parcours: arc-enciel, blocs: couleurs LCER
class Lcer{

	static { Style.addCouleurs(new Lcer()) }

	constructor(){
		this.lcer = ['hsl(10,60%,84%)','hsl(55,70%,84%)','hsl(100,70%,84%)','hsl(215,60%,84%)','hsl(215,0%,84%)','hsl(182,10%,70%)','hsl(287,100%,86%)','hsl(170,100%,85%)']
		this.unknown = 'hsl(35,5%,94%)'
	}

	getName(){ return 'LCER' }

	// couleur pour indiquer qu'un module est a choix
	colorChoix(){
		return 'rgb(100,100,100)'
	}

	// couleurs du parcours d'indice donne parmi nb parcours
	colorParcours(index,nb){
		if(index>-1 && index<nb && nb!=0) return 'hsl('+parseInt(360*index/nb)+',75%,65%)'
		else return this.unknown
	}

	// couleurs du bloc d'indice donne parmi nb blocs
	colorBloc(index,nb){
		if(index>-1 && index<this.lcer.length) return this.lcer[index]
		else return this.unknown
	}

	// couleur des lignes de dependance entre modules, selon le nombre de dependances n
	colorDependance(n){
		return 'hsl(210,100%,'+(75-1.7*n)+'%)'
		//return 'rgb(0,98,196)
	}
	
}


// une classe representant un jeu de couleurs pour l'affichage des maquettes
// parcours: arc-enciel, competences: couleurs LCER, connaissances: des pastels 
class Pastels{

	static { Style.addCouleurs(new Pastels()) }

	constructor(){
		this.pastels = ['#7BD3EA','#A1EEBD','#F6F7C4','#F6D6D6','#FFB3C6','#FFB996','#ECE3CE','#D0BFFF','#AAD7D9','#FFC0BB','#FDFDBD','#98F5E1','#C0EFBB']
		//this.pastels = this.pastels.slice(0,6).reverse()
		//this.pastels = ['hsl(59,71%,89%)','hsl(206,70%,83%)','hsl(334,63%,88%)','hsl(213,42%,54%)','hsl(206,67%,76%)','hsl(83,20%,79%)','hsl(33,56%,78%)','hsl(8,64%,82%)','hsl(51,41%,93%)','hsl(354,49%,92%)','hsl(339,73%,85%)','hsl(52,58%,75%)','hsl(27,28%,75%)','hsl(275,13%,74%)','hsl(23,68%,70%)','hsl(175,62%,34%)','hsl(182,47%,73%)','hsl(10,19%,87%)']
		this.unknown = 'hsl(35,5%,94%)'
	}

	getName(){ return 'Pastels' }

	// couleur pour indiquer qu'un module est a choix
	colorChoix(){
		return 'rgb(100,100,100)'
	}

	// couleurs du parcours d'indice donne parmi nb parcours
	colorParcours(index,nb){
		if(index>-1 && index<nb && nb!=0) return 'hsl('+parseInt(300*index/nb)+',75%,65%)'
		else return this.unknown
	}

	// couleurs du bloc d'indice donne parmi nb blocs
	colorBloc(index,nb){
		if(index>-1 && index<this.pastels.length) return this.pastels[index]
		else return this.unknown
	}
	
	// couleur des lignes de dependance entre modules
	colorDependance(n){
		return 'hsl(210,100%,'+(75-1.7*n)+'%)'
		//return 'rgb(0,98,196)'
	}
}


class Chimie{
		
	static { Domaine.add(new Chimie()) } // pour la gestion centralisee des differents domaines
		
	constructor(){}

	getName(){ return 'Chimie' }

	// x,y=centre; h=hauteur
	dessineMotif(svg,x,y,h){
		// erlenmeyer
		let d = h/5, f = h/7
		let p = document.createElementNS(svg.namespaceURI,'path')
		p.setAttribute('stroke','black')
  		p.setAttribute('stroke-width',1)
  		p.setAttribute('fill','none')
  		p.setAttribute('d','M '+(x+d)+' '+(y-h/2)+' L '+(x+d)+' '+y+' L '+(x+h/2)+' '+(y+h/2-f)+' L '+(x+h/2-f)+' '+(y+h/2)+' L '+(x-h/2+f)+' '+(y+h/2)+' L '+(x-h/2)+' '+(y+h/2-f)+' L '+(x-d)+' '+y+' L '+(x-d)+' '+(y-h/2)+' Z')
  		svg.append(p)
  		// contenu
  		let cols = ['rgb(0,245,245)','rgb(180,235,135)','rgb(240,125,230)']
  		let color = cols[Math.floor(Math.random()*cols.length)]
  		let e = h/3
  		p = document.createElementNS(svg.namespaceURI,'path')
		p.setAttribute('stroke','black')
  		p.setAttribute('stroke-width',1)
  		p.setAttribute('fill',color)
  		p.setAttribute('d','M '+(x+d)+' '+(y-h/2+e)+' L '+(x+d)+' '+y+' L '+(x+h/2)+' '+(y+h/2-f)+' L '+(x+h/2-f)+' '+(y+h/2)+' L '+(x-h/2+f)+' '+(y+h/2)+' L '+(x-h/2)+' '+(y+h/2-f)+' L '+(x-d)+' '+y+' L '+(x-d)+' '+(y-h/2+e)+' Z')
  		svg.append(p)
  		// graduations
  		generateLine(svg,x-(d+h/2)/2+2,y+(1+h/2-f)/3,x-(d+h/2)/2+h/3,y+(1+h/2-f)/3,'black',1)
  		generateLine(svg,x-2*(d+h/2)/3+2,y+2*(1+h/2-f)/3,x-2*(d+h/2)/3+h/3,y+2*(1+h/2-f)/3,'black',1)
  		// bulles
  		let r = h/8
		generateCircle(svg,x+r/2,y-h/2-r-1,r,color,'none')
		generateCircle(svg,x+r/2+1.5*r,y-h/2-2.5*r,r/2,color,'none')
	}

}class Gestion{
		
	static { Domaine.add(new Gestion()) } // pour la gestion centralisee des differents domaines
		
	constructor(){}

	getName(){ return 'Gestion' }

	// x,y=centre; h=hauteur
	dessineMotif(svg,x,y,h){
		let p = 0.65
		generateRect(svg,x-h/2,y-h/2,h,h*p,0,'rgb(100,100,100)','rgb(240,240,240)')
		let w = (h-10)/4
		let colbar = 'rgb(255,100,60)'
		generateRect(svg,x-h/2+2,y-h/2+h*p*0.7,w,h*p*0.3-1,0,colbar,colbar)
		generateRect(svg,x-h/2+w+4,y-h/2+h*p*0.6,w,h*p*0.4-1,0,colbar,colbar)
		generateRect(svg,x-h/2+2*w+6,y-h/2+h*p*0.4,w,h*p*0.6-1,0,colbar,colbar)
		generateRect(svg,x-h/2+3*w+8,y-h/2+2,w,h*p-3,0,colbar,colbar)
		generateLine(svg,x-h/5,y-h/2+p*h,x-h/4,y+h/2,'black',1.5)
		generateLine(svg,x+h/5,y-h/2+p*h,x+h/4,y+h/2,'black',1.5)
		//generateLine(svg,x-h/4.5,y+p*h/2,x+h/4.5,y+p*h/2,'black',1.5)


	}

}class Informatique{

	static { Domaine.add(new Informatique()) } // pour la gestion centralisee des differents domaines
		
	constructor(){}

	getName(){ return 'Informatique' }

	// x,y=centre; h=hauteur
	dessineMotif(svg,x,y,h){
		// pacman
		let dir = 1 // vers la droite
		let angle = Math.PI/6
		let p = document.createElementNS(svg.namespaceURI,'path')
		p.setAttribute('d','M '+x+' '+y+' L '+(x+dir*Math.cos(angle)*h/2)+' '+(y-Math.sin(angle)*h/2)+' A '+(h/2)+' '+(h/2)+' 0 1 0 '+(x+dir*Math.cos(angle)*h/2)+' '+(y+Math.sin(angle)*h/2)+' Z')
		p.setAttribute('style','fill:#FFFF00;stroke:black')
		svg.appendChild(p)
		// oeil
		generateCircle(svg,x+dir*h/10,y-h/3.5,h/12,'white','white')
		generateCircle(svg,x+dir*h/10,y-h/3.5,h/14,'black','none')
	}

}class Maths{
		
	static { Domaine.add(new Maths()) } // pour la gestion centralisee des differents domaines
		
	constructor(){}

	getName(){ return 'Mathématiques' }

	// x,y=centre; h=hauteur
	dessineMotif(svg,x,y,h){
		let text = '&#960;r&#178;'
		let fontSize = 1.1*h
		let ctx = document.createElement('canvas').getContext('2d')
		ctx.font = fontSize+'px Times,serif'
		generateRect(svg,x-h*0.75,y-h/2,1.5*h,h,0,'rgb(100,100,100)','rgb(240,240,240)')
		let t = document.createElementNS(svg.namespaceURI,'text')
		t.setAttribute('x',x-ctx.measureText(text).width/12)
		t.setAttribute('y',y+fontSize/3)
		t.setAttribute('font-size',fontSize)
		t.setAttribute('font-family','Times')
		//t.setAttribute('fill','red')
		t.innerHTML = text
		svg.appendChild(t)
	}

}class Physique{
		
	static { Domaine.add(new Physique()) } // pour la gestion centralisee des differents domaines
		
	constructor(){}

	getName(){ return 'Physique' }

	// x,y=centre; h=hauteur
	dessineMotif(svg,x,y,h){
		// atome
		let col = 'black'
		let rx = h/1.5, ry = h/4	
		generateCircle(svg,x,y,h/20,col,col)
		let ell1 = document.createElementNS(svg.namespaceURI,'ellipse')
		ell1.setAttribute('cx',x)
		ell1.setAttribute('cy',y)
		ell1.setAttribute('rx',rx)
		ell1.setAttribute('ry',ry)
		ell1.setAttribute('style','fill:none;stroke:'+col)
		svg.appendChild(ell1)
		let ell2 = document.createElementNS(svg.namespaceURI,'ellipse')
		ell2.setAttribute('cx',x)
		ell2.setAttribute('cy',y)
		ell2.setAttribute('rx',rx)
		ell2.setAttribute('ry',ry)
		ell2.setAttribute('style','fill:none;stroke:'+col)
		ell2.setAttribute('transform','rotate(-60 '+x+' '+y+')')
		svg.appendChild(ell2)
		let ell3 = document.createElementNS(svg.namespaceURI,'ellipse')
		ell3.setAttribute('cx',x)
		ell3.setAttribute('cy',y)
		ell3.setAttribute('rx',rx)
		ell3.setAttribute('ry',ry)
		ell3.setAttribute('style','fill:none;stroke:'+col)
		ell3.setAttribute('transform','rotate(60 '+x+' '+y+')')
		svg.appendChild(ell3)
		// radioactif
		/*let col = 'black'
		generateCircle(svg,x,y,h/15,col,col)
		let a = h/4 //5.5
		let p1 = document.createElementNS(svg.namespaceURI,'path')
		p1.setAttribute('d','M '+(x-a/2)+' '+(y+a*Math.sqrt(3)/2)+' A '+(h/4)+' '+(h/4)+' 0 0 0 '+(x+a/2)+' '+(y+a*Math.sqrt(3)/2)+' L '+(x+h/4)+' '+(y+Math.sqrt(3)*h/4)+' A '+(h/2)+' '+(h/2)+' 0 0 1 '+(x-h/4)+' '+(y+Math.sqrt(3)*h/4)+' Z')
		p1.setAttribute('style','stroke:'+col+';fill:'+col)
		svg.appendChild(p1)
		let p2 = document.createElementNS(svg.namespaceURI,'path')
		p2.setAttribute('d','M '+(x+a)+' '+y+' A '+(h/4)+' '+(h/4)+' 0 0 0 '+(x+a/2)+' '+(y-a*Math.sqrt(3)/2)+' L '+(x+h/4)+' '+(y-Math.sqrt(3)*h/4)+' A '+(h/2)+' '+(h/2)+' 0 0 1 '+(x+h/2)+' '+y+' Z')
		p2.setAttribute('style','stroke:'+col+';fill:'+col)
		svg.appendChild(p2)
		let p3 = document.createElementNS(svg.namespaceURI,'path')
		p3.setAttribute('d','M '+(x-a)+' '+y+' A '+(h/4)+' '+(h/4)+' 0 0 1 '+(x-a/2)+' '+(y-a*Math.sqrt(3)/2)+' L '+(x-h/4)+' '+(y-Math.sqrt(3)*h/4)+' A '+(h/2)+' '+(h/2)+' 0 0 0 '+(x-h/2)+' '+y+' Z')
		p3.setAttribute('style','stroke:'+col+';fill:'+col)
		svg.appendChild(p3)*/
	}


}class SPI{
		
	static { Domaine.add(new SPI()) } // pour la gestion centralisee des differents domaines
        
    constructor(){}

    getName(){ return 'Sciences pour l\'ingénieur' }

	// x,y=centre; h=hauteur
	dessineMotif(svg,x,y,h){
        let fond = 'rgb(180,180,180)'
        let cols = ['rgb(173, 255, 247)','rgb(255,100,100)','rgb(255,245,100)']
        let yeux = cols[Math.floor(Math.random()*cols.length)]
        let bouche = 'rgb(125,125,125)'
        let t = h*0.8
        generateRect(svg,x-h/2,y+h/2-t,h,t,2,fond,fond)
        generateCircle(svg,x-h/5,y-h/20,h/10,yeux,yeux)
        generateCircle(svg,x+h/5,y-h/20,h/10,yeux,yeux)
        generateRect(svg,x-h/5,y+t/3,h/2.5,h/20,0,bouche,bouche)
        let d = 0
        generateLine(svg,x-d,y+h/2-t,x-d,y-h/2-1,'black',1)
        generateCircle(svg,x-d,y-h/2-1-h/10,h/10,'white','black')
        //generateLine(svg,x+d,y+h/2-t,x+d,y-h/2-1,'black',1)
        //generateCircle(svg,x+d,y-h/2-1-h/10,h/10,'white','black')
        generateSemiCircle(svg,x-h/2,y+h/2-t/4,x-h/2,y+h/2-3*t/4,bouche)
        generateSemiCircle(svg,x+h/2,y+h/2-3*t/4,x+h/2,y+h/2-t/4,bouche)

		// NAND
		/*h = h*0.8
        let nand = document.createElementNS(svg.namespaceURI,'path')
        nand.setAttribute('d','M '+(x-h/2)+' '+(y-h/2)+' L '+(x+h/8)+' '+(y-h/2)+' A '+(h/2)+' '+(h/2)+' 0 0 1 '+(x+h/8)+' '+(y+h/2)+' L '+(x-h/2)+' '+(y+h/2)+' Z')
        nand.setAttribute('style','fill:white;stroke:black')
        svg.appendChild(nand)
        let r = h/6
        let c = generateCircle(svg,x+5*h/8+r+1,y,r,'white','black')
        c.setAttribute('style','stroke-width:2px')
        let dx = h/2, dy = h/4
        generateLine(svg,x+5*h/8+2*r,y,x+5*h/8+2*r+dx,y,'black',1)
        generateLine(svg,x-h/2,y-dy,x-h/2-dx,y-dy,'black',1)
        generateLine(svg,x-h/2,y+dy,x-h/2-dx,y+dy,'black',1)*/
        // NOT
        /*x = x-Math.sqrt(2)*h/4
        let not = document.createElementNS(svg.namespaceURI,'path')
        not.setAttribute('d','M '+x+' '+(y-h/2)+' L '+(x+Math.sqrt(2)*h/2)+' '+y+' L '+x+' '+(y+h/2)+' Z')
        not.setAttribute('style','fill:rgb(240,240,240);stroke:black')
        svg.appendChild(not)
        let r = h/6
        let c = generateCircle(svg,x+Math.sqrt(2)*h/2+r,y,r,'rgb(240,240,240)','black')
        //c.setAttribute('style','stroke-width:2px')
        let dx = h/2.5, dy = h/4
        generateLine(svg,x+Math.sqrt(2)*h/2+2*r,y,x+Math.sqrt(2)*h/2+2*r+dx,y,'black',1)
        generateLine(svg,x,y-dy,x-dx,y-dy,'black',1)
        generateLine(svg,x,y+dy,x-dx,y+dy,'black',1)*/
	}

}class SVT{
		
	static { Domaine.add(new SVT()) } // pour la gestion centralisee des differents domaines
		
	constructor(){}

	getName(){ return 'Sciences de la vie et de la terre' }

	// x,y=centre; h=hauteur
	dessineMotif(svg,x,y,h){
		x = x-h/2
		y = y-h/2
		let feuille = document.createElementNS(svg.namespaceURI,'path')
		let a = h/4, b = h/12
		feuille.setAttribute('d','M '+(x+h)+' '+(y+h)+' Q '+(x+h+a)+' '+(y+b)+', '+(x+h-a)+' '+(y+b)+' Q '+(x+a)+' '+(y+b)+','+(x)+' '+(y-0.1*h)+' Q '+(x+1.5*b)+' '+(y+0.4*a)+','+(x+b)+' '+(y+h-a)+' Q '+(x+b)+' '+(y+h+a)+','+(x+h)+' '+(y+h)+' Z')
		feuille.setAttribute('stroke','rgb(180,180,180)')
  		feuille.setAttribute('fill','green')
  		svg.append(feuille)
		let nervCol = 'rgb(190,247,136)'
		let nerv1 = document.createElementNS(svg.namespaceURI,'path')
		nerv1.setAttribute('d','M '+(x+h)+' '+(y+h)+' A '+(2*h)+' '+(2*h)+' 0 0 1 '+(x+0.2*h)+' '+(y+0.2*h))
		nerv1.setAttribute('style','stroke:none;fill:'+nervCol)
		let nerv2 = document.createElementNS(svg.namespaceURI,'path')
		nerv2.setAttribute('d','M '+(x+4*h/5)+' '+(y+4*h/5)+' A '+(6*h)+' '+(2*h)+' 0 0 0 '+(x+2*h/3)+' '+(y+0.25*h))
		nerv2.setAttribute('style','stroke:none;fill:'+nervCol)
		let nerv3 = document.createElementNS(svg.namespaceURI,'path')
		nerv3.setAttribute('d','M '+(x+2*h/3)+' '+(y+2.2*h/3)+' A '+(1.5*h)+' '+(4*h)+' 0 0 1 '+(x+0.5*h/3)+' '+(y+0.6*h))
		nerv3.setAttribute('style','stroke:none;fill:'+nervCol)
		svg.appendChild(nerv1)
		svg.appendChild(nerv2)
		svg.appendChild(nerv3)

		// COCCINELLE
		/*generateCircle(svg,x+h/4,y,h/3,'black','black')
		generateLine(svg,x+h/4,y,x+3.5*h/4,y-h/4,'black',1)
		generateLine(svg,x+h/4,y,x+3.5*h/4,y+h/4,'black',1)
		generateCircle(svg,x+3.5*h/8,y+h/9,h/20,'white','white')
		generateCircle(svg,x+3.5*h/8,y-h/9,h/20,'white','white')
		let corps = document.createElementNS(svg.namespaceURI,'ellipse')
		corps.setAttribute('cx',x-h/4)
		corps.setAttribute('cy',y)
		corps.setAttribute('rx',4.5*h/8)
		corps.setAttribute('ry',h/2)
		corps.setAttribute('style','stroke:red;fill:red')
		svg.appendChild(corps)
		//generateLine(svg,x-4.5*h/8-h/4,y,x-h/4+4.5*h/8,y,'black',1)
		generateCircle(svg,x-h/1.8,y+h/5,h/12,'black','black')
		generateCircle(svg,x-h/4,y+h/3,h/12,'black','black')
		generateCircle(svg,x,y+h/5,h/12,'black','black')
		generateCircle(svg,x-h/10,y-h/6,h/12,'black','black')
		generateCircle(svg,x-h/2,y-h/7,h/12,'black','black')*/
		// ABEILLE
		// corps
		/*let w = h/2
		let b = 3*h/16
		generateLine(svg,x-w/2,y-b/2,x+w/2,y-b/2,'yellow',b)
		generateLine(svg,x-w/2,y+b/2,x+w/2,y+b/2,'black',b)		
		generatePolygon(svg,[[x-w/2,y+b],[x+w/2,y+b],[x+w/4,y+2*b],[x-w/4,y+2*b]],'yellow','black',1)
		generatePolygon(svg,[[x-w/4,y+2*b],[x+w/4,y+2*b],[x,y+3*b]],'black','black',1)
		// tete
		let r = h/6
		generateCircle(svg,x,y-h/4-r,r,'yellow','black')
		generateLine(svg,x-r/2,y-h/4-3*r/2,x-w/2,y-h/4-2.5*r,'black',1)
		generateLine(svg,x+r/2,y-h/4-3*r/2,x+w/2,y-h/4-2.5*r,'black',1)
		// ailes
		let d = 3*h/4
		let aile = document.createElementNS(svg.namespaceURI,'ellipse')
		aile.setAttribute('cx',x-d/3)
		aile.setAttribute('cy',y-h/4+d/2.5)
		aile.setAttribute('rx',d/2.2)
		aile.setAttribute('ry',d/5.5)
		aile.setAttribute('style','stroke:black;fill:white')
		aile.setAttribute('transform','rotate(-60 '+(x-d/3)+' '+(y-h/4+d/2.5)+')')
		svg.appendChild(aile)
		aile = document.createElementNS(svg.namespaceURI,'ellipse')
		aile.setAttribute('cx',x+d/3)
		aile.setAttribute('cy',y-h/4+d/2.5)
		aile.setAttribute('rx',d/2.2)
		aile.setAttribute('ry',d/5.5)
		aile.setAttribute('style','stroke:black;fill:white')
		aile.setAttribute('transform','rotate(60 '+(x+d/3)+' '+(y-h/4+d/2.5)+')')
		svg.appendChild(aile)*/
	}

}class Transverse{
		
	static { Domaine.add(new Transverse()) } // pour la gestion centralisee des differents domaines
		
	constructor(){}

	getName(){ return 'Transverse' }

	// x,y=centre; h=hauteur
	dessineMotif(svg,x,y,h){
		let col = 'rgb(235,235,235)'
		let w = h*1.2
		let dy = 0.7
		let r = document.createElementNS(svg.namespaceURI,'rect')
		r.setAttribute('x',x-w/2)
		r.setAttribute('y',y-h/2)
		r.setAttribute('width',w)
		r.setAttribute('height',h*dy)
		r.setAttribute('rx',4)
		r.setAttribute('ry',4)
		r.setAttribute('stroke','black')
  		r.setAttribute('stroke-width',1)
  		r.setAttribute('fill',col)
  		svg.appendChild(r)
  		let d = w/6
  		let p = document.createElementNS(svg.namespaceURI,'path')
		p.setAttribute('d','M '+(x-d)+' '+(y+(dy-0.5)*h)+' L '+(x+d)+' '+(y+h/2)+' L '+(x+d)+' '+(y+(dy-0.5)*h)+' Z')
		p.setAttribute('style','stroke:black;fill:'+col)
		svg.appendChild(p)
		generateLine(svg,x-d+1,y+(dy-0.5)*h,x+d,y+(dy-0.5)*h,col,2)
		generateCircle(svg,x-w/4,y+h*(dy-1)/2,0.5,'black','black')
		generateCircle(svg,x,y+h*(dy-1)/2,0.5,'black','black')
		generateCircle(svg,x+w/4,y+h*(dy-1)/2,0.5,'black','black')
	}

}// **** VARIABLES GLOBALES ****
let _fontSize = Math.max(10,parseInt(window.innerHeight/72))
let _wECTS = Math.max(24,window.innerHeight/30) // Math.max(24,window.innerHeight/28)
let _wOffset=_wECTS*0.9, _hOffset=_wOffset*1.0, _xInit=30, _yInit=30
let _lignesPrerequis = [] // tableau des elements SVG de prerequis a enlever si necessaire
let _parcoursAffiches = [] // tableau des parcours affiches
let _ects=true, _heures=false, _refs=false, _domaines=true // parametres d'affichage des modules
let _svg
//_mouture = 'light'

let sheet = document.createElement('style')
sheet.innerHTML = "body {font-family: Arial,sans-serif}"
sheet.innerHTML += ".alert {padding:20px;padding-top:0px;background-color:white;color:black;position:absolute;top:8%;left:10%;height:80%;width:80%;border:solid black 3px}"
sheet.innerHTML += ".closebtn {color:black;position:absolute;right:5px;top:0px;font-size:larger;cursor:pointer;}"
sheet.innerHTML += ".closebtn:hover {color:gray;cursor:pointer;}"
sheet.innerHTML += "td {padding: 5px;}"
sheet.innerHTML += "a {color: black;text-decoration: none;display: block;}"
sheet.innerHTML += ".bouton {float:right;margin-right:10px;font-size:"+(_fontSize*1.1)+"px;height:2em}"
sheet.innerHTML += ".menuitem {font-size:"+(_fontSize*1.1)+"px;width:10em;border:none;height:2em;margin:0px}"
sheet.innerHTML += ".menuitem:hover {background-color:white}"
sheet.innerHTML += ".menuli {list-style:none;margin:0px;padding:0px}"
document.body.appendChild(sheet)
let header = document.createElement('div')
document.body.appendChild(header)
header.id = 'header'
header.style = "background:rgb(0,98,196);color:white;width:98%;padding:4px;margin:0px;position:fixed;vertical-align:baseline"
header.innerHTML += '<select id="changeSource" onChange="changeSource()" style="height:2em"></select>'
header.innerHTML += '<input class="bouton" type="button" value="Aide" onclick="aide()">'
header.innerHTML += '<input class="bouton" type="button" value="Options d\'affichage" onclick="options()">'
header.innerHTML += '<input class="bouton" type="button" value="Calcul de résultat" onclick="calculette()">'
header.innerHTML += '<div style="float:right;margin-right:10px;z-index:99;background-color:gray"><button class="menuitem" onclick="showHideMenu(\'infoMenu\')">FORMATION</button><ul id="infoMenu" style="display:none;margin:0px;padding:0px;position:absolute;"></ul></div>'
if(typeof _mouture=='undefined' || _mouture=='full') header.innerHTML += '<div style="float:right;margin-right:10px;z-index:99;background-color:gray"><button class="menuitem" onclick="showHideMenu(\'apogeeMenu\')">Format APOGEE</button><ul id="apogeeMenu" style="display:none;margin:0px;padding:0px;position:absolute;"></ul></div>'
document.body.innerHTML += '<div id="alert" class="alert" style="display:none;position:fixed"><span class="closebtn" onclick="this.parentElement.style.display=\'none\';">&times;</span><p id="message" style="overflow-y:auto;height:100%;margin:0px;font-size:'+(_fontSize*1.5)+'px"></p></div><svg xmlns="http://www.w3.org/2000/svg" id="dessin" overflow="scroll" style="margin-top:28px"></svg>'
document.body.addEventListener("keydown",keyProcess)
document.body.addEventListener('click',clicBody,true)
//window.addEventListener('resize', function(){"use strict";window.location.reload();})
window.addEventListener('DOMContentLoaded',changeSource,false)
_svg = document.getElementById('dessin')

// montre (si value=true) ou cache (si value=false) le menu. Si value n'est pas precisee, inverse l'affichage
function showHideMenu(idmenu,value){
  let m = document.getElementById(idmenu)
  arguments.length>1 ? (value ? m.style.display='block' : m.style.display='none') : (m.style.display==='none' ? m.style.display='block' : m.style.display='none')
}

// ajoute une maquette, le JSON doit etre au format Maquetor
function addMaquette(json){
  let maq = new Maquette(json)
  let cs = document.getElementById('changeSource')
  let opt = document.createElement('option')
  opt.innerHTML = maq.getFormation().getNom()
  cs.appendChild(opt)
}

function changeSource(){
  if(document.getElementById('changeSource').selectedIndex != -1){
    Maquette.set(document.getElementById('changeSource').selectedIndex)
    let src = Maquette.get()
    //_formation = src.FORMATION
    _modules = src.MODULES
    init()
  }
}

function buildMenuFormation(){
  let im = document.getElementById('infoMenu')
  while(im.hasChildNodes()) im.removeChild(im.firstChild)
  im.innerHTML += '<li class="menuli"><button class="menuitem" onclick="showHideMenu(\'infoMenu\');presentationFormation()">Présentation</button></li><li class="menuli"><button class="menuitem" onclick="showHideMenu(\'infoMenu\');structureFormation()">Structure</button></li><li class="menuli"><button class="menuitem" onclick="showHideMenu(\'infoMenu\');m3c()">M3C</button></li><li class="menuli"><button class="menuitem" onclick="showHideMenu(\'infoMenu\');detailsBlocs()">Détails par bloc</button></li>'
  for(let a = 1;a<=Maquette.get().getFormation().getNbSemestres()/2;a++) im.innerHTML += '<li class="menuli"><button class="menuitem" onclick="showHideMenu(\'infoMenu\');clicAnnee('+a+')">Détails '+Maquette.get().getFormation().getLMD()+a+'</button></li>'
  if(typeof _mouture=='undefined' || _mouture=='full') im.innerHTML += '<li class="menuli"><button class="menuitem" onclick="showHideMenu(\'infoMenu\');couts()">Coûts</button></li>'
}

function init(){
  document.title = Maquette.get().getFormation().getNom()
  Maquette.get().getFormation().getBlocs().sort((a,b) => a.getNom().localeCompare(b.getNom()))
  _parcoursAffiches = []
  for(let p of Maquette.get().getFormation().getParcours()) _parcoursAffiches.push(p)
  _lignesPrerequis = []
  // modification du menu FORMATION
  buildMenuFormation()
  // modification du menu de formatage APOGEE
  let am = document.getElementById('apogeeMenu')
  if(am!=null){
    while(am.hasChildNodes()) am.removeChild(am.firstChild)
    for(let a=1;a<=Maquette.get().getFormation().getNbSemestres()/2;a++){
      am.innerHTML += '<li class="menuli"><button class="menuitem" onclick="showHideMenu(\'apogeeMenu\');apogee('+a+')">'+Maquette.get().getFormation().getLMD()+a+'</button></li>'
    }
  }
  repaint()
}

function repaint(){
  // remise a zero du svg
  let totalWidth = Math.max(window.innerWidth-10,maxWidth()+_wECTS+_fontSize*26)
  _svg.setAttribute('height',_yInit+6*(getModule_height()+_hOffset)+1*_hOffset) //window.innerHeight-_fontSize*8)
  _svg.setAttribute('width',totalWidth)
  while (_svg.firstChild) _svg.removeChild(_svg.firstChild)
  generateDessin(_svg,_parcoursAffiches,_ects,_refs,_heures)
}

// reset la fenetre d'alerte, ajoute le titre et retourne la zone d'affichage
function setAlertTitle(titre){
  showHideMenu('infoMenu',false)
  let m = document.getElementById('message')
  while(m.firstChild) m.removeChild(m.firstChild)
  m.innerHTML += '<div style="border:solid;border-radius:20px;padding:5px 0px 5px 0px;margin:15px 0px 20px 0px"><b><center>'+titre+'</center></b></div>'
  return m
}

// retourne le nombre n avec deux chiffres apres la virgule
function formatNumber(n){
    return parseInt(n*100)/100
}

// affiche les couts dans une fenetre
function couts(){
  let nbSem = Maquette.get().getFormation().getNbSemestres()
  let cells = new Array(nbSem+2)
  let rowCols = []
  for(let i=0;i<nbSem+2;i++) rowCols.push('white')
  rowCols[0] = 'rgb(240,240,240)'
  rowCols[nbSem+1] = 'rgb(248,248,248)'
  cells[0] = ['','heures CM','heures TD','heures TP','UCs<br>(1h CM = 1.5UC<br>1h TD = 1h TP = 1UC)','Inscrits (max<br>des effectifs<br>des modules<br>du semestre)','Heures/étudiant']
  for(let i=1;i<nbSem+1;i++){
    cells[i] = ['S'+i,0,0,0,0,0,0]
  }
  cells[nbSem+1] = ['TOTAL',0,0,0,0,0,0]
  for(let m of Maquette.get().getModules()){
    let ucsCM = m.getCoutFormation()*m.getCM()*m.getGroupesCM()*1.5
    let ucsTD = m.getCoutFormation()*m.getTD()*m.getGroupesTD()
    let ucsTP = m.getCoutFormation()*m.getTP()*m.getGroupesTP()
    let sems = m.getSemestres()
    for(let s of sems){
      cells[s][1] += ucsCM/sems.length
      cells[s][2] += ucsTD/sems.length
      cells[s][3] += ucsTP/sems.length
      cells[s][4] += (ucsCM+ucsTD+ucsTP)/sems.length
    }
    cells[nbSem+1][1] += ucsCM
    cells[nbSem+1][2] += ucsTD
    cells[nbSem+1][3] += ucsTP
    cells[nbSem+1][4] += ucsCM+ucsTD+ucsTP
  }
  let totalEff=0
  for(let i=1;i<=nbSem;i++){
    let eff = Maquette.get().getEffectifMaxSemestre(i)
    cells[i][5] = eff
    if(eff!=0) cells[i][6] = parseInt(100*(cells[i][1]+cells[i][2]+cells[i][3])/eff)/100
    else cells[i][6] = 0
    if(i%2==0) totalEff += Math.max(cells[i][5],cells[i-1][5])
  }
  let ucs = cells[nbSem+1][1]*1.5+cells[nbSem+1][2]+cells[nbSem+1][3]
  let total = cells[nbSem+1][1]+cells[nbSem+1][2]+cells[nbSem+1][3]
  cells[nbSem+1][4] = ucs+' soit '+(parseInt(100*ucs/192)/100)+' EC temps plein'
  cells[nbSem+1][5] = totalEff+' étudiants'
  cells[nbSem+1][6] = parseInt(100*total/totalEff)/100+' h/étudiant sur le diplôme'
  let m = setAlertTitle('Coût et statistiques du diplôme '+Maquette.get().getFormation().getNom())
  m.appendChild(buildTable(cells,rowCols))
  // calcul des etudiants par TD et TP
  let minTD=100,moyTD=0,maxTD=0
  let minTP=100,moyTP=0,maxTP=0
  let mMaxTD, mMinTD, mMaxTP, mMinTP, nTD = 0, nTP = 0
  for(let m of Maquette.get().getModules()){
    if(m.getGroupesTD()!=0){
      let h = m.getEffectif()/m.getGroupesTD()
      if(h<minTD){ minTD=h; mMinTD=m; }
      if(h>maxTD){ maxTD=h; mMaxTD=m; }
      moyTD = moyTD+h
      nTD++
    }
    if(m.getGroupesTP()!=0){
      let h = m.getEffectif()/m.getGroupesTP()
      if(h<minTP){ minTP=h; mMinTP=m; }
      if(h>maxTP){ maxTP=h; mMaxTP=m; }
      moyTP = moyTP+h
      nTP++
    }
  }
  if(mMaxTD!=null && mMinTD!=null){
    l = document.createElement('label')
    l.innerHTML = '<br><br><u>&Eacute;tudiants par groupe de TD</u> :<br>- min = '+parseInt(minTD*100)/100+' étudiants/TD en '+mMinTD.getTitre()+'<br>- max = '+parseInt(maxTD*100)/100+' étudiants/TD en '+mMaxTD.getTitre()+'<br>- moyenne = '+parseInt(moyTD*100/nTD)/100+' étudiants/TD'
    m.appendChild(l)
  }
  if(mMaxTP!=null && mMinTP!=null){
    l = document.createElement('label')
    l.innerHTML = '<br><br><u>&Eacute;tudiants par groupe de TP (hors stage)</u> :<br>- min = '+parseInt(minTP*100)/100+' étudiants/TP en '+mMinTP.getTitre()+'<br>- max = '+parseInt(maxTP*100)/100+' étudiants/TP en '+mMaxTP.getTitre()+'<br>- moyenne = '+parseInt(moyTP*100/nTP)/100+' étudiants/TP'
    m.appendChild(l)
  }
  document.getElementById('alert').style.display = 'block'
}

// affiche dans une fenetre les M3C dde la formation
function m3c(){
  let m = setAlertTitle(Maquette.get().getFormation().getNom()+' - '+Maquette.get().getFormation().getEtablissement()+' - '+Maquette.get().getFormation().getAnnees())
  let l = document.createElement('label')
  l.innerHTML = '<br><u>Modalités de Contrôle des Connaissances et des Compétences</u> : <br><br>'
  for(let n of Maquette.get().getFormation().getM3C()) l.innerHTML = l.innerHTML+'&bull; '+n+'<br>'
  m.appendChild(l)
  document.getElementById('alert').style.display = 'block'
}

// affiche dans une fenetre la structure de la formation
function structureFormation(){
  let m = setAlertTitle(Maquette.get().getFormation().getNom()+' - '+Maquette.get().getFormation().getEtablissement()+' - '+Maquette.get().getFormation().getAnnees())
  let l = document.createElement('label')
  l.innerHTML = '<br><u>Nombre de semestres</u> : '+Maquette.get().getFormation().getNbSemestres()+'<br><br><u>Parcours</u> : '
  l.innerHTML += Maquette.get().getFormation().parcoursToString()
  l.innerHTML += '<br><br><u>Blocs</u> :<br>'
  for(let bc of Maquette.get().getFormation().getBlocs()) l.innerHTML += '&bull; <b>'+bc.getNom()+'</b> : '+bc.getDescription()+'<br>'
  m.appendChild(l)
  document.getElementById('alert').style.display = 'block'
}

// affiche dans une fenetre la presentation de la formation
function presentationFormation(){
  let m = setAlertTitle(Maquette.get().getFormation().getNom()+' - '+Maquette.get().getFormation().getEtablissement()+' - '+Maquette.get().getFormation().getAnnees())
  let l = document.createElement('label')
  for(let p of Maquette.get().getFormation().getPresentation()) l.innerHTML += p+'<br>'
  l.innerHTML += '<br><u>Responsables</u> :<br>'
  for(let r of Maquette.get().getFormation().getResponsables()) l.innerHTML += '&bull; '+r+'<br>'
  m.appendChild(l)
  document.getElementById('alert').style.display = 'block'
}

// genere dans la balise d'id 'message' la description du contenu du module de reference donnee
function contenuModule(ref){
  let m = Maquette.get().getModuleByID(ref)
  if(m!=null){
    let titre = m.getTitre()
    if(m.getType()!='STAGE') titre = m.getType()+' '+m.getID()+' - '+titre
    let pop = setAlertTitle(titre)
    let table = document.createElement('table')
    table.border = '1'
    table.style.borderCollapse = 'collapse'
    table.style.marginLeft = 'auto'
    table.style.marginRight = 'auto'
    table.style.width = '100%'
    let tr = document.createElement('tr')
    tr.setAttribute('style','background-color:rgb(245,245,245)')
    let td = document.createElement('td')
    td.width = '50%'
    td.innerHTML = m.statutToHTML()
    tr.appendChild(td)
    td = document.createElement('td')
    td.innerHTML = '<u>HEURES</u> : '+m.getCM()+'h CM / '+m.getTD()+'h TD / '+m.getTP()+'h TP'
    if(typeof _mouture=='undefined' || _mouture=='full'){
      td.innerHTML += '&nbsp;&nbsp;&nbsp;&nbsp;(coût dans la formation : '+(m.getCoutFormation()*100)+'%, '+m.getCout()+'UCs)'
    }
    tr.appendChild(td)
    table.appendChild(tr)
    table.style.lineHeight = '25px'
    table.style.borderCollapse = 'separate'
    tr = document.createElement('tr')
    td = document.createElement('td')
    td.innerHTML = '<u>FLUX</u> : '+m.getEffectif()+' étudiants, '+m.getGroupesCM()+' groupe(s) de CM / '+m.getGroupesTD()+' groupe(s) de TD / '+m.getGroupesTP()+' groupe(s) de TP'
    tr.appendChild(td)
    td = document.createElement('td')
    text = '<u>PREREQUIS</u> : '
    for(let p of m.getPrerequis()) text += Maquette.get().getModuleByID(p).getTitre()+', '
    td.innerHTML = m.getPrerequis().length>0 ? text.substring(0,text.length-2) : text
    tr.appendChild(td)
    table.appendChild(tr)
    tr = document.createElement('tr')
    tr.setAttribute('style','background-color:rgb(245,245,245)')
    td = document.createElement('td')
    td.innerHTML = '<u>SESSION 1</u> : '+m.getSession1()+'<br><u>SECONDE CHANCE</u> : '+m.getSecondeChance()+'<br><u>SESSION 2</u> : '+m.getSession2()
    tr.appendChild(td)
    td = document.createElement('td')
    text = '<u>ENSEIGNANTS RESPONSABLES</u> : '
    for(let e of m.getResponsables()) text += e+', '
    if(m.getResponsables().length>0) text = text.substring(0,text.length-2)
    text += '<br><u>AUTRES ENSEIGNANTS</u> : '
    for(let e of m.getIntervenants()) text += e+', '
    if(m.getIntervenants().length>0) text = text.substring(0,text.length-2)
    td.innerHTML = text
    tr.appendChild(td)
    table.appendChild(tr)
    pop.appendChild(table)
    let l = document.createElement('label')
    l.style.fontStyle = 'italic'
    l.style.textShadow = 'hsl(60 85% 50%) 1px 0 15px'
    for(let n of m.getNotes()) l.innerHTML += '<br>&bull; '+n
    pop.appendChild(l)
    l = document.createElement('label')
    l.innerHTML = '<br><u>OBJECTIFS</u> :<br>'
    l.setAttribute('style','display:block;text-align:left')
    for(let c of m.getObjectifs()) l.innerHTML += '&bull; '+c+'<br>'
    pop.appendChild(l)
    l = document.createElement('label')
    l.innerHTML = '<br><u>CONTENU</u> :<br>'
    l.setAttribute('style','display:block;text-align:left')
    for(let c of m.getContenu()) l.innerHTML += '&bull; '+c+'<br>'
    pop.appendChild(l)
    document.getElementById('alert').style.display = 'block'
  }
}

// affiche les heures et ECTS etudiants par bloc de competences dans une fenetre
function detailsBlocs(){
  let nbSem = Maquette.get().getFormation().getNbSemestres()
  let chemins = Maquette.get().getFormation().genereCheminsEtudiants()
  let totalHeures = new Map()
  let totalECTS = new Map()
  let detailHeures = new Map()
  for(let c of chemins){
    totalHeures.set(c,0)
    totalECTS.set(c,0)
    detailHeures.set(c,[])
  }
  let m = setAlertTitle('Détail des heures étudiantes et des ECTS par combinaison de parcours et par bloc de compétences')
  let cells = []
  let rowCols = ['rgb(245,245,245)']
  let tab = ['']
  for(let c of chemins){
    let chem = ''
    for(let a=1;a<=nbSem/2;a++){
      if(c[a-1]!=null){
        chem += c[a-1].NOM
        chem = chem+', '
      }
    }
    chem = chem.substring(0,chem.length-2)
    tab.push(chem)
  }
  cells.push(tab)
  for(let bc of Maquette.get().getFormation().getBlocs()){
    rowCols.push(Style.colorBloc(Maquette.get().getFormation().getIndexBloc(bc),Maquette.get().getFormation().getBlocs().length))
    tab = [bc.getNom()]
    for(let c of chemins){
      let heures=0, ects=0
      for(let a=1;a<=Maquette.get().getFormation().getNbSemestres()/2;a++){
        for(let m of Maquette.get().getModules()){
          if(m.getAnnee()==a && m.getModalite(c[a-1]==null ? null : c[a-1].getID())==Statut.OBLIGATOIRE){
            ects += m.getECTS(bc.getID(),c[a-1]==null ? null : c[a-1].getID())
            heures += m.getHeures(bc.getID(),c[a-1]==null ? null : c[a-1].getID())
          }
        }
      }
      tab.push(formatNumber(heures)+' h, '+formatNumber(ects)+' ECTS')
      detailHeures.get(c).push(heures)
      totalHeures.set(c,totalHeures.get(c)+heures)
      totalECTS.set(c,totalECTS.get(c)+ects)
    }
    cells.push(tab)
  }
  tab = ['TOTAL']
  rowCols.push('white')
  let bidon = document.createElementNS("http://www.w3.org/2000/svg",'svg')
  bidon.setAttribute('height',1)
  let cams = [bidon]
  for(let c of chemins){
    tab.push(formatNumber(totalHeures.get(c))+' h, '+formatNumber(totalECTS.get(c))+' ECTS')
    cams.push(camembert(_svg,2*_wECTS,Array.from(Maquette.get().getFormation().getBlocs(),(bc) => Style.colorBloc(Maquette.get().getFormation().getIndexBloc(bc),Maquette.get().getFormation().getBlocs().length)),detailHeures.get(c)))
  }
  cells.push(tab)
  m.appendChild(buildTable(cells,rowCols,cams))
  let l = document.createElement('label')
  l.innerHTML = '<br>NB 1 : seuls les modules obligatoires sont pris en compte, y compris ceux des parcours<br>NB 2 : les heures d\'un enseignement portant sur plusieurs blocs de compétences sont prises en compte proportionnellement aux ECTS affectés aux blocs<br>NB 3 : les camemberts affichent la répartition en heures'
  m.appendChild(l)
  document.getElementById('alert').style.display = 'block'
}

// affiche les informations sur l'annee a dans une fenetre
function clicAnnee(a){
  let pars = Maquette.get().getFormation().parcoursDeAnnee(a)
  let cells = []
  let rowCols = []
  if(pars.length!=0){
    let head = ['']
    for(let p of pars) head.push(p.getNom())
    cells.push(head)
  }
  else{
    cells.push(['','pas de parcours'])
    pars = [null]
  }
  rowCols.push('rgb(245,245,245)')
  let ectsAnn = 0, heuresAnn = 0
  for(let sem=(2*a-1);sem<=2*a;sem++){
    let ectsObli=[], ectsChoix=[], heures=[], options=[]
    for(let par of pars){
      ectsObli.push(0)
      ectsChoix.push(0)
      heures.push(0)
      options.push(0)
    }
    let tabChoix = []
    for(let bc of Maquette.get().getFormation().getBlocs()){
      let tab = []
      tab.push(bc.getNom()+' du S'+sem)
      let i = 0
      for(let par of pars){
        let eo=0, he=0
        for(let m of Maquette.get().getModules()){
          if(m.getSemestres().includes(sem)){
            let mod = m.getModalite(par==null ? null : par.getID())
            let e = m.getECTS(bc.getID(),par==null ? null : par.getID())
            let h = m.getHeures(bc.getID(),par==null ? null : par.getID())
            if(mod==Statut.OBLIGATOIRE){
              eo += e==null ? 0 : e
              he += h==null ? 0 : h
            }
            if(mod==Statut.OBLIGATOIRE_A_CHOIX){
              let choix = m.getChoix(par)
              if(choix!=null && !tabChoix.some((x) => Statut.sameChoix(x,choix[1]))){
                ectsChoix[i] += choix[0]
                tabChoix.push(choix[1])
              }
            }
            if(mod==Statut.OPTIONNEL) options[i] += e
          }
        }
        ectsObli[i] += eo
        heures[i] += he
        i++
        tab.push(eo+' ECTS et '+formatNumber(he)+'h')
      }
      cells.push(tab)
      rowCols.push(Style.colorBloc(Maquette.get().getFormation().getIndexBloc(bc),Maquette.get().getFormation().getBlocs().length))
    }
    let t = ['Totaux S'+sem]
    for(let i=0;i<pars.length;i++) t.push(ectsObli[i]+' ECTS obligatoires'+(ectsChoix[i]!=0 ? '<br>'+ectsChoix[i]+' ECTS obligatoires à choix' : '')+((ectsObli[i]+ectsChoix[i])<30 ? '<br>'+(30-ectsObli[i]-ectsChoix[i])+' ECTS d\'options parmi '+options[i] : '')+'<br>'+formatNumber(heures[i])+' heures obligatoires')
    cells.push(t)
    rowCols.push('white')
  }
  let table = buildTable(cells,rowCols)
  let m = setAlertTitle('Année '+Maquette.get().getFormation().getLMD()+a)
  m.appendChild(table)
  l = document.createElement('label')
  l.innerHTML = '<br>NB 1 : seuls les modules obligatoires sont pris en compte, y compris ceux des parcours<br>NB 2 : les heures d\'un enseignement portant sur plusieurs blocs de compétences sont prises en compte proportionnellement aux ECTS affectés aux blocs'
  m.appendChild(l)
  document.getElementById('alert').style.display = 'block'
}

// ferme la sous-fenetre en cas d'appui sur ECHAP
function keyProcess(){
  if(event.key == 'Escape'){
    document.getElementById('alert').style.display = 'none'
    _lignesPrerequis = []
    repaint()
  }
  if(event.altKey){
    if(event.ctrlKey && event.code=='KeyD'){ // Ctrl+Alt+D pour afficher toutes les dependances
      console.log('test')
      if(_lignesPrerequis.length==0) afficheTousPrerequis()
      else{
        _lignesPrerequis.length = []
        repaint()
      }
    }
    if(event.code=='KeyS'){ // S pour basculer entre formes
      Style.nextForme()
      document.getElementById('alert').style.display = 'none'
      _lignesPrerequis = []
      repaint()
    }
    if(event.code=='KeyC'){ // C pour basculer entre jeux de couleurs
      Style.nextCouleurs()
      document.getElementById('alert').style.display = 'none'
      _lignesPrerequis = []
      repaint()
    }
    if(event.code=='KeyI'){ // D pour afficher ou non les symboles de domaine
      _domaines = !_domaines
      document.getElementById('alert').style.display = 'none'
      _lignesPrerequis = []
      repaint()
    }
  }
  if(event.key == 'F8') rigolo()
}

// ferme la sous-fenetre en cas de clic
function clicBody(){
  if(!document.getElementById('alert').contains(event.target) &&  document.getElementById('alert').style.display != 'none') document.getElementById('alert').style.display = 'none'
}

function semestreApogee(m){
  let sems = m.getSemestres()
  return sems.length==2 ? "Annuel" : sems[0]+"e Sem" 
}

// genere une fenetre contenant la presentation des modules au format APOGEE de l'annee donnee
function apogee(a){
  let m = setAlertTitle(Maquette.get().getFormation().getLMD()+a+' au Format APOGEE')
  let p = document.createElement('div')
  let cols = ['Libellé','Code','Nature','Période','ECTS','Nb IP','Volume','Charges Ens CM','Charges Ens TD','Charges Ens TP','Code liste','Observations']
  let table = document.createElement('table')
  table.border = '1'
  table.style.borderCollapse = 'collapse'
  table.style.margin = 'auto'
  addRow(table,cols,true,true)
  let parcours = Maquette.get().getFormation().parcoursDeAnnee(a)
  if(parcours=='') parcours=[null]
  for(let par of parcours){
    if(par==null) addRow(table,['-- '+Maquette.get().getFormation().getLMD()+a,'','PAR','Annuel',60,'','','','','','',''],true)
    else addRow(table,['-- '+par.NOM+' '+Maquette.get().getFormation().getLMD()+a,'','PAR','Annuel',60,'','','','','','',''],true)
    for(let bc of Maquette.get().getFormation().getBlocs()){
      let blocOK = par==null ? Maquette.get().blocDansAnnee(a,bc.getID()) : Maquette.get().blocDansAnnee(a,bc.getID(),par.getID())
      if(blocOK){
        addRow(table,['--- Competence '+bc.getNom()+' '+bc.getDescription()+' - niveau '+a,bc.getNom(),'COMPETENCE','Annuel','','','','','','','',''],true)
        // modules annuels
        let modules = par==null ? Maquette.get().getModulesAnnuels(a,bc) : Maquette.get().getModulesAnnuels(a,bc,par)
        let choix = []
        for(let m of modules){
          let c = m.getChoix(par)
          if(c!=null){
            if(!choix.includes(JSON.stringify(c))) choix.push(JSON.stringify(c))
          }
          else addRow(table,['----- '+m.getTitre(),m.getID(),m.getType(),semestreApogee(m),m.getECTS(bc.getID(),par==null ? null : par.getID()),m.getEffectif(),(m.getCM()+m.getTD()+m.getTP()),m.getCM(),m.getTD(),m.getTP(),'',''])
        }
        // ajout des ues a choix
        let i = 1, j = 1
        for(let c of choix){
          let tab = JSON.parse(c)
          addRow(table,['----- Choix ressource','choix '+i,'CHOIX','Annuel',tab[0],'','','','','','',''])
          for(let v of tab[1]){
            if(Array.isArray(v)){
              addRow(table,['------ Liste choix','liste '+j,'EC','Annuel',tab[0],'','','','','','',''])
              for(w of v){
                let m = Maquette.get().getModuleByID(w)
                addRow(table,['------- '+m.getTitre(),m.getID(),m.getType(),semestreApogee(m),m.getECTS(bc.getID(),par==null ? null : par.getID()),m.getEffectif(),(m.getCM()+m.getTD()+m.getTP()),m.getCM(),m.getTD(),m.getTP(),'',''])
              }
            }
            else{
              let m = Maquette.get().getModuleByID(v)
              addRow(table,['------ '+m.getTitre(),m.getID(),m.getType(),semestreApogee(m),m.getECTS(bc.getID(),par==null ? null : par.getID()),m.getEffectif(),(m.getCM()+m.getTD()+m.getTP()),m.getCM(),m.getTD(),m.getTP(),'',''])
            }
          }
          i++
        }
        // modules semestriels
        for(let sem = a*2-1;sem<a*2+1;sem++){
          modules = par==null ? Maquette.get().getModulesSemestriels(sem,bc) : Maquette.get().getModulesSemestriels(sem,bc,par)
          if(modules.length!=0){
            addRow(table,['---- UE Competence '+bc.getNom()+' Semestre '+sem,bc.getID(),'UE',sem+'e Sem','','','','','','','',''],true)
            choix = []
            for(let m of modules){
              let c = m.getChoix(par)
              if(c!=null){
                if(!choix.includes(JSON.stringify(c))) choix.push(JSON.stringify(c))
              }
              else addRow(table,['----- '+m.getTitre(),m.getID(),m.getType(),semestreApogee(m),m.getECTS(bc.getID(),par==null ? null : par.getID()),m.getEffectif(),(m.getCM()+m.getTD()+m.getTP()),m.getCM(),m.getTD(),m.getTP(),'',''])
            }
            // ajout des ues a choix
            let i = 1, j = 1
            for(let c of choix){
              let tab = JSON.parse(c)
              addRow(table,['----- Choix ressource','choix '+i,'CHOIX',sem+'e Sem',tab[0],'','','','','','',''])
              for(let v of tab[1]){
                if(Array.isArray(v)){
                  addRow(table,['------ Liste choix','liste '+j,'EC',sem+'e Sem',tab[0],'','','','','','',''])
                  for(w of v){
                    let m = Maquette.get().getModuleByID(w)
                    addRow(table,['------- '+m.getTitre(),m.getID(),m.getType(),semestreApogee(m),m.getECTS(bc.getID(),par.getID()),m.getEffectif(),(m.getCM()+m.getTD()+m.getTP()),m.getCM(),m.getTD(),m.getTP(),'',''])
                  }
                }
                else{
                  let m = Maquette.get().getModuleByID(v)
                  addRow(table,['------ '+m.getTitre(),m.getID(),m.getType(),semestreApogee(m),m.getECTS(bc.getID(),par.getID()),m.getEffectif(),(m.getCM()+m.getTD()+m.getTP()),m.getCM(),m.getTD(),m.getTP(),'',''])
                }
              }
              i++
            }
          }
        }
      }
    }
  }
  p.appendChild(table)
  m.appendChild(p)
  document.getElementById('alert').style.display = 'block'
}

// genere une fenetre avec les options d'affichage
function options(){
  let m = setAlertTitle('Options d\'affichage et légende des décorations de domaine')
  let p = document.createElement('div')
  createCheckbox(false,'affichage des ECTS','ects','',p,_ects)
  p.innerHTML += '<label style="margin-right:20px"></label>'
  createCheckbox(false,'affichage des volumes horaires','heures','',p,_heures)
  p.innerHTML += '<label style="margin-right:20px"></label>'
  createCheckbox(false,'affichage des références','refs','',p,_refs)
  p.innerHTML += '<label style="margin-right:20px"></label>'
  createCheckbox(false,'affichage des icônes de domaine (Alt+I)','domaines','',p,_domaines)
  p.innerHTML += '<br><br><u>Parcours affichés</u> : '
  for(let par of Maquette.get().getFormation().getParcours()){
    if(_parcoursAffiches.includes(par)) p.innerHTML += '<input type="checkbox" id="'+par.getID()+'" onclick="repaint()" checked><label style="margin-right:20px;">'+par.getNom()+'</label>'
    else p.innerHTML += '<input type="checkbox" id="'+par.getID()+'" onclick="repaint()"><label style="margin-right:20px;">'+par.getNom()+'</label>'
  }
  p.innerHTML += '<br><br>'
  m.appendChild(p)
  p = document.createElement('div')
  p.innerHTML += '<u>Formes disponibles (Alt+S pour basculer)</u> : '
  let fs = Style.getFormeList()
  for(let i=0;i<fs.length;i++){
    p.innerHTML += '<input type="checkbox" id="forme'+i+'" name="forme" onclick="setForme('+i+')" '+(Style.getIndexForme()==i ? 'checked' : '')+'><label style="margin-right:20px;"><i>'+fs[i].getName()+'</i></label>'
  }
  p.innerHTML += '<br><br><u>Jeux de couleurs disponibles (Alt+C pour basculer)</u> : '
  let fc = Style.getCouleursList()
  for(let i=0;i<fc.length;i++){
    p.innerHTML += '<input type="checkbox" id="couleurs'+i+'" name="couleurs" onclick="setCouleurs('+i+')" '+(Style.getIndexCouleurs()==i ? 'checked' : '')+'><label style="margin-right:20px;"><i>'+fc[i].getName()+'</i></label>'
  }
  m.appendChild(p)
  m.innerHTML += '<br><input type="button" value="VALIDER" style="display:block;margin:auto" onclick="setParameters()"><br><br>'
  document.getElementById('ects').checked = _ects
  document.getElementById('heures').checked = _heures
  document.getElementById('refs').checked = _refs
  document.getElementById('alert').style.display = 'block'
}

function setForme(num){
  for(let es of document.getElementsByName('forme')){
    if(es.id != 'forme'+num) es.checked = false
  }
}

function setCouleurs(num){
  for(let es of document.getElementsByName('couleurs')){
    if(es.id != 'couleurs'+num) es.checked = false
  }
}

function setParameters(){
  _ects = document.getElementById('ects').checked
  _heures = document.getElementById('heures').checked
  _refs = document.getElementById('refs').checked
  _domaines = document.getElementById('domaines').checked
  _parcoursAffiches = []
  for(let par of Maquette.get().getFormation().getParcours()){
    if(document.getElementById(par.getID()+'').checked) _parcoursAffiches.push(par)
  }
  for(let es of document.getElementsByName('forme')){
    if(es.checked) Style.setForme(parseInt(es.id.substr(es.id.length-1,1)))
  }
  for(let es of document.getElementsByName('couleurs')){
    if(es.checked) Style.setCouleurs(parseInt(es.id.substr(es.id.length-1,1)))
  }
  document.getElementById('alert').style.display = 'none'
  _lignesPrerequis = []
  repaint()
}

// affiche une aide dans une fenetre
function aide(){
  let m = setAlertTitle('Aide')
  let p = document.createElement('div')
  p.innerHTML += '<b>MAQUETOR v0.9.0 - Outil de gestion de maquette de diplôme</b><br><small>&copy; Département Informatique de la Faculté des Sciences de l\'Université de Picardie - Jules Verne, 2025</small><br><br>&bull; Chaque module est affiché par un rectangle coloré selon les blocs où le module apparait. Pour les modules ayant un ou des statuts différents selon les parcours, des décorations colorées indiquent ces statuts<br>&bull; Les modules sont affichés d\'abord par bloc puis par statut (obligatoires pour tous, optionnels pour tous, les modules de parcours)<br>&bull; Pour afficher les détails d\'un module, cliquez sur son titre<br>&bull; Pour afficher les dépendances passant par un module, cliquez sur son titre avec Ctrl appuyé (Echap pour effacer les lignes) ; la couleur des lignes pointillées sortant d\'un module est d\'autant plus foncée que ce module est prérequis, directement ou non, par plus de modules<br>&bull; Pour afficher toutes les dépendances entre modules, tapez Ctrl+Alt+D<br>&bull; Pour afficher les détails d\'une année, cliquez sur son libellé à gauche<br>&bull; Pour fermer les pop-ups cliquez sur la croix en haut à droite ou tapez Echap<br>&bull; Pour naviguer entre les formes disponibles, tapez Alt S<br>&bull; Pour naviguer entre les jeux de couleurs disponibles, tapez Alt C<br>&bull; Pour afficher ou non les icônes de domaine, tapez Alt I<br>'
  m.appendChild(p)
  m.innerHTML += '<br><hr style="width:60%;text-align:center"><br>'
  let decos = Domaine.getAll()
  let s = document.createElement('svg')
  s.setAttribute('xmlns','http://www.w3.org/2000/svg')
  s.setAttribute('width','100%')
  s.setAttribute('height',30*decos.length)
  p.appendChild(s)
  let dim = 20
  let x = 20, y = 20, n = 1
  for(let de of decos ){
    de.dessineMotif(s,x,y,dim*0.8)
    let ele = generateText(s,x+dim*1.5,y+_fontSize*0.5,_fontSize*1.5,de.getName())
    if(n%4==0){
      x += dim*1.5+_fontSize*20
      y = 20
    }
    else y += dim*1.5
    n++
  }
  m.appendChild(s)
  m.innerHTML += '<br>'
  document.getElementById('alert').style.display = 'block'
}
// retourne la largeur max du dessin des modules (hors legende)
function maxWidth(){
  let max = []
  for(let sem=1;sem<=Maquette.get().getFormation().getNbSemestres();sem++) max.push(_xInit)
  for(let m of Maquette.get().getModules()){
    for(let s of m.getSemestres()) max[s-1] += getModule_width(m)+_wOffset
  }
  return Math.max(...max)
}

function getModule_width(m){
  return 2*_wECTS+_wECTS*0.5*m.getECTS_moyens()/m.getSemestres().length
}

// si le module n'est pas fourni renvoie la hauteur d'un module semestriel
function getModule_height(m){
  let coef = 5
  if(m!==undefined){
    if(m.getSemestres().length==2) return 2*coef+_wECTS*6+_hOffset
    else return coef+_wECTS*3
  }
  else return coef+_wECTS*3
}

function getModuleLabelFont(m){
  if(m.getECTS_moyens()>2) return _fontSize
  else{
    return 7+1.8*m.getECTS_moyens()/m.getSemestres().length
  }
}

// dessine sur le svg le diagramme de la maquette, ne prend en compte que les parcours du tableau de parcours tabParcours
// ects,ref,heures = true pour afficher les ECTS,ref, heures sur les modules
function generateDessin(svg,tabParcours,ects,ref,heures){
  // numeros des annees
  let yAnnee = _yInit+(2*getModule_height()+_hOffset)/2+_fontSize/2
  for(let i=1;i<=Maquette.get().getFormation().getNbSemestres();i=i+2){
    let st = generateText(svg,5,yAnnee,_fontSize*1.3,Maquette.get().getFormation().getLMD()+parseInt(i/2 + 1),'bold')
    st.setAttribute('onclick','clicAnnee('+parseInt(i/2 + 1)+')')
    st.style.cursor = 'pointer'
    let pl = document.createElementNS(svg.namespaceURI,'polyline')
    let xLine = _fontSize+2;
    pl.setAttribute('points',xLine+","+(yAnnee-_fontSize/3-1-xLine)+" "+xLine+","+(yAnnee-_fontSize/3-1-xLine-2*_wECTS)+" "+(xLine+_wECTS/4)+","+(yAnnee-_fontSize/3-1-xLine-2*_wECTS))
    pl.setAttribute('fill','none')
    pl.setAttribute('stroke','black')
    svg.appendChild(pl)
    pl = document.createElementNS(svg.namespaceURI,'polyline')
    xLine = _fontSize+2
    pl.setAttribute('points',xLine+","+(yAnnee-_fontSize/3-1+xLine)+" "+xLine+","+(yAnnee-_fontSize/3-1+xLine+2*_wECTS)+" "+(xLine+_wECTS/4)+","+(yAnnee-_fontSize/3-1+xLine+2*_wECTS))
    pl.setAttribute('fill','none')
    pl.setAttribute('stroke','black')
    svg.appendChild(pl)
    yAnnee += 2*getModule_height()+2.5*_hOffset
    //if(i%2==0) yAnnee += _wECTS/4
  }
  // affichage des modules
  let x=_xInit, y=_yInit, xMax=0
  for(let ann=1;ann<=Maquette.get().getFormation().getNbSemestres()/2;ann++){
    // modules annuels
    let mTab = []
    if(tabParcours.length==0) mTab = Maquette.get().getModulesAnnuels(ann)
    else{
      for(let p of tabParcours) Maquette.get().getModulesAnnuels(ann,null,p).forEach((m) => { if(!mTab.includes(m)) mTab.push(m) })
    }
    mTab.sort((a,b) => a.compare(b))
    for(let m of mTab) x += afficheModule(svg,m,x,y,ects,ref,heures)+_wOffset
    // modules semestriels
    for(let sem=2*ann-1;sem<=2*ann;sem++){
      let xSem = x
      mTab = []
      if(tabParcours.length==0) mTab = Maquette.get().getModulesSemestriels(sem)
      else{
        for(let p of tabParcours) Maquette.get().getModulesSemestriels(sem,null,p).forEach((m) => { if(!mTab.includes(m)) mTab.push(m) })
      }
      mTab.sort((a,b) => a.compare(b))
      for(let m of mTab) xSem += afficheModule(svg,m,xSem,y,ects,ref,heures)+_wOffset
      y += getModule_height()+_hOffset
      xMax = Math.max(xMax,xSem)
    }
    x = _xInit
    y += _hOffset*0.5
  }
  // dessine la legende
  dessineLegende(svg,xMax+_wECTS,_yInit-_hOffset/2)
}

// dessine le module et retourne la largeur du rectangle dessine
function afficheModule(svg,m,x,y,ects,ref,heures){
  let h = getModule_height(m), w=getModule_width(m)
  let mod = m.getModalite()
  // couleurs des blocs
  let cols = []
  let prop = []
  let blocs = m.getBlocsID()
  for(let b of blocs){
    let bloc = Maquette.get().getFormation().getBlocByID(b)
    let c = Style.colorBloc(Maquette.get().getFormation().getIndexBloc(bloc),Maquette.get().getFormation().getBlocs().length)
    if(c == undefined) cols.push('rgb(255,255,255)')
    else cols.push(c)
    prop.push(100/blocs.length)
  }
  // affichage des parcours
  let decosPar = [] // tableau de [couleur, modalite 'obligatoire' ou 'optionnel', choix true ou false]
  if(mod==Statut.NONE){
    for(let par of Maquette.get().getFormation().getParcours()){
      let mod = m.getModalite(par.getID())
      if(mod!=Statut.NONE) decosPar.push([Style.colorParcours(Maquette.get().getFormation().getIndexParcours(par),Maquette.get().getFormation().getParcours().length),mod])
    }
  }
  m.setPosition(x,y) // stockage de la position pour affichage des lignes de dependance
  Style.dessineModule(svg,x,y,w,h,m.getType(),mod,cols,prop,decosPar)
  // dessin d'un eventuel motif de domaine
  /*let styles = ['Informatique','Maths','SPI','Chimie','Physique','SVT','Transverse']
  let motif = styles[Math.floor((Math.random()*styles.length))]*/
  if(_domaines){
    let motif = m.getStyle()
    if(motif!=null){
      try{
        motif = eval('new '+motif+'()')
        let dimBase = getModule_height()/5.5
        let dim = Math.min(dimBase,w*dimBase/h) // getModule_height()/5.5
        let pos = x+w/2 // position du motif x+dim/2+8
        motif.dessineMotif(svg,pos,y+h-dim/2-5,dim)
      }
      catch(error){}
    }
  }
  generateModuleLabel(svg,x+1,y+(m.getSemestres().length==2 ? h/4 : 0),m,ects,ref,heures)
  return w
}

// genere le label du module a la position donnee et l'ajoute sur le svg
function generateModuleLabel(svg,x,y,m,ects,refs,heures){
  let forobj = document.createElementNS(svg.namespaceURI,'foreignObject')
  forobj.setAttribute('x',x)
  forobj.setAttribute('y',y+9)
  forobj.setAttribute('width',getModule_width(m)-4)
  forobj.setAttribute('height',getModule_height(m)-6)
  let mText = document.createElementNS('http://www.w3.org/1999/xhtml','a')
  mText.setAttribute('style','font-size: '+getModuleLabelFont(m)+'px;text-align:center;')
  mText.innerHTML = '<b>'+m.getTitre()+'</b><br>'
  if(refs) mText.innerHTML += '<i>'+m.getID()+'</i><br>'
  if(heures) mText.innerHTML += m.getCM()+'h / '+m.getTD()+'h / '+m.getTP()+'h<br>'
  if(ects) mText.innerHTML += '('+m.ECTSToString()+' ECTS)'
  mText.setAttribute('onclick','if(event.ctrlKey) affichePrerequis(\''+m.getID()+'\'); else contenuModule(\''+m.getID()+'\')')
  mText.style.cursor = 'pointer'
  forobj.appendChild(mText)
  svg.appendChild(forobj)
}

function dessineLegende(svg,x,y){
  legendFontSize = _fontSize
  let prop = 0.7, yOffset = _wECTS*1.2
  // legende des types d'UE
  Style.dessineModule(svg,x,y,_wECTS*prop,_wECTS*prop,'',Statut.OBLIGATOIRE,['white'],[100])
  generateText(svg,x+_wECTS,y+legendFontSize+2,legendFontSize,'obligatoire')
  y += yOffset
  Style.dessineModule(svg,x,y,_wECTS*prop,_wECTS*prop,'',Statut.OPTIONNEL,['white'],[100])
  generateText(svg,x+_wECTS,y+legendFontSize+2,legendFontSize,'non obligatoire')
  y += yOffset
  Style.dessineModule(svg,x,y,_wECTS*prop,_wECTS*prop,'SAE',Statut.OBLIGATOIRE,['white'],[100])
  generateText(svg,x+_wECTS,y+legendFontSize+2,legendFontSize,'SAE')
  y += yOffset
  Style.dessineModule(svg,x,y,_wECTS*prop,_wECTS*prop,'STAGE',Statut.OBLIGATOIRE,['white'],[100])
  generateText(svg,x+_wECTS,y+legendFontSize+2,legendFontSize,'stage / alternance')
  y += yOffset
  generateCircle(svg,x+_wECTS/3,y+_wECTS/3,_wECTS/3,Style.colorChoix(),Style.colorChoix())
  generateText(svg,x+_wECTS,y+legendFontSize+2,legendFontSize,'à choix')
  y += yOffset
  // legende des blocs
  for (let bc of Maquette.get().getFormation().getBlocs()){
    let col = Style.colorBloc(Maquette.get().getFormation().getIndexBloc(bc),Maquette.get().getFormation().getBlocs().length)
    generateRect(svg,x,y,2*_wECTS/3,2*_wECTS/3,0,col,col)
    generateText(svg,x+_wECTS,y+legendFontSize+2,legendFontSize,'bloc '+bc.getNom())
    y += yOffset
  }
  // legende des parcours
  for (let par of Maquette.get().getFormation().getParcours()){
    let col = Style.colorParcours(Maquette.get().getFormation().getIndexParcours(par),Maquette.get().getFormation().getParcours().length)
    generateCircle(svg,x+_wECTS/3,y+_wECTS/3,_wECTS/3,col,col)
    generateText(svg,x+_wECTS,y+legendFontSize+2,legendFontSize,'parcours '+par.getNom())
    y += yOffset
  }
  y += yOffset
}

function effaceDependances(svg){
  for(let l of _lignesPrerequis) svg.removeChild(l)
  _lignesPrerequis = []
}

// genere les lignes indiquant les dependances pédagogiques en aval d'un module
function generateDependancesAval(svg,m){
  for(let nid of m.getPrerequis()){
    let n = Maquette.get().getModuleByID(nid)
    _lignesPrerequis = _lignesPrerequis.concat(generateLigneDependance(svg,n.getX()+getModule_width(n)/2,n.getY()+6,m.getX()+getModule_width(m)/2,m.getY()+6,Style.colorDependance(Maquette.get().nbModulesDependants(n))))
    generateDependancesAval(svg,n)
  }
}

// genere les lignes indiquant les dependances pédagogiques en amont d'un module
function generateDependancesAmont(svg,m){
  for(let n of m.estPrerequis()){
    _lignesPrerequis = _lignesPrerequis.concat(generateLigneDependance(svg,m.getX()+getModule_width(m)/2,m.getY()+6,n.getX()+getModule_width(n)/2,n.getY()+6,Style.colorDependance(Maquette.get().nbModulesDependants(m))))
    generateDependancesAmont(svg,n)
  }
}

// affiche les lignes de dependances du module d'id donne
function affichePrerequis(idm){
  effaceDependances(_svg)
  generateDependancesAval(_svg,Maquette.get().getModuleByID(idm))
  generateDependancesAmont(_svg,Maquette.get().getModuleByID(idm))
}

function afficheTousPrerequis(){
  effaceDependances(_svg)
  for(let m of Maquette.get().getModules()){
    generateDependancesAval(_svg,m)
  }
}function addRow(table,vals,bold,grise){
  let tr = document.createElement('tr')
  for(let r of vals){
    let td = document.createElement('td')
    if(arguments.length>2 && bold) td.setAttribute('style','font-weight:bold')
    if(arguments.length>3 && grise) td.setAttribute('style','font-weight:bold;background-color:lightgray')
    td.innerHTML = r
    tr.appendChild(td)
  }
  table.appendChild(tr)
}

// construit et retourne une table avec les valeurs du tableau a deux dimensions cells dans des lignes de couleurs rowCols
// premiere colonne et premiere ligne sont affiches en gras
// si cams est renseigne, ajoute dans les cases de la derniere ligne les camemberts du tableau cams
function buildTable(cells,rowCols,cams){
  let table = document.createElement('table')
  table.border = '1'
  table.style.borderCollapse = 'collapse'
  table.style.margin = 'auto'
  for(let i=0;i<cells.length;i++){
    let tr = document.createElement('tr')
    tr.setAttribute('style','background-color:'+rowCols[i])
    for(let j=0;j<cells[i].length;j++){
      let td = document.createElement('td')
      if(i==0 || j==0) td.setAttribute('style','text-align:center;font-weight:bold')
      else td.setAttribute('style','text-align:center')
      td.innerHTML = cells[i][j]
      if(i==cells.length-1 && arguments.length>2){
        td.innerHTML += '<br>'
        td.appendChild(cams[j])
      }
      tr.appendChild(td)
    }
    table.appendChild(tr)
  }
  return table
}

// ajoute sur l'element parent un label et une case a cocher. checked, value et action sont optionnels
function createCheckbox(labelFirst, label, id, nom, parent, checked, value, action){
  let l = '<label style="display:inline">'+label+'</label>'
  let i = '<input type="checkbox" id="'+id+'" name="'+nom+'"'
  if(arguments.length>5 && checked) i += ' checked'
  if(arguments.length>6) i += ' value="'+value+'"'
  if(arguments.length>7) i += ' onchange="'+action+'"'
  i += '>'
  if(labelFirst) parent.innerHTML += l+i
  else parent.innerHTML += i+l
}

// ajoute sur l'element parent un label et un champ texte. default et action sont optionnels, mettre labelSize a <=0 pour ne pas en tenir compte
function createInputText(label, id, nom, parent, labelSize, inputSize, defaut, action){
  let s = '<label style="display:inline-block;'
  if(labelSize>0) s+= 'width:'+labelSize+'px'
  s+= '">'+label+'</label><input type="text" id="'+id+'" name="'+nom+'" size="'+inputSize+'" style="margin-left:5px;margin-right:25px"'
  if(arguments.length>6) s += ' value="'+defaut+'"'
  if(arguments.length>7) s += ' oninput="'+action+'"'
  s += '>';
  parent.innerHTML += s
}

// ajoute sur l'element parent un label et un select. hSize, selected, multiple et optionLabels sont optionnels
// selected peut etre un tableau d'indices si multiple
function createSelect(labelFirst, label, id, nom, values, parent, labelSize, hSize, selected, multiple, optionLabels){
  let l = '<label style="display:inline-block;'
  if(labelSize>0) l+= 'width:'+labelSize+'px'
  l+= '">'+label+'</label>'
  let s = '<select id="'+id+'" name="'+nom+'" style="margin-left:5px;margin-right:25px"'
  if(arguments.length>7) s += ' size="'+hSize+'"'
  if(arguments.length>9 && multiple) s += ' multiple'
  s += '>'
  let i=0
  for(let v of values){
    s += '<option value="'+v+'"'
    if(selected===i || (Array.isArray(selected) && selected.includes(i))) s += ' selected'
    if(arguments.length>10) s += '>'+optionLabels[i]+'</option>'
    else s += '>'+v+'</option>'
    i++;
  }
  s += '</select>'
  if(labelFirst) parent.innerHTML += l+s
  else parent.innerHTML += s+l
}// genere une fenetre permettant de calculer sa note finale
function calculette(){
  let m = setAlertTitle('Calcul de résultat')
  let p = document.createElement('div')
  p.setAttribute('style','text-align:center')
  p.innerHTML += '<i>Les résultats des calculs sont donnés à titre indicatif et peuvent différer de ceux fournis par le système de gestion des notes</i><br><u>Valeurs à saisir</u> : DEF (pour défaillant), DISP (pour dispensé), note entre 0 et 20, ou rien si le module n\'est pas suivi<br>Les modules <u>soulignés</u> sont obligatoires dans le parcours<br><u>Résultats</u> : DEF (défaillant), ADM (admis), ADMC (admis compensé), AJ (ajourné), AJAC (ajourné autorisé à continuer)<br><br>'
  let sel = document.createElement('select')
  sel.setAttribute('id','sel_annee')
  sel.setAttribute('onchange','initCalculette()')
  for(let i=1;i<=Maquette.get().getFormation().getNbSemestres()/2;i++){
    let par = Maquette.get().getFormation().parcoursDeAnnee(i)
    if(par=="") sel.innerHTML += '<option value="'+i+'">'+Maquette.get().getFormation().getLMD()+i+'</option>'
    else{
      for(q of par) sel.innerHTML += '<option value="'+i+'#'+q.getID()+'">'+Maquette.get().getFormation().getLMD()+i+' '+q.getNom()+'</option>'
    }
  }
  p.appendChild(sel)
  p.innerHTML += '<br><br>'
  m.appendChild(p)
  p = document.createElement('div')
  p.setAttribute('id','table_notes')
  p.setAttribute('style','text-align:center;')
  m.appendChild(p)
  initCalculette()
  p = document.createElement('div')
  p.setAttribute('id','resultat')
  p.setAttribute('style','text-align:center;')
  m.appendChild(p)
  document.getElementById('alert').style.display = 'block'
}

// renvoie un formulaire pour les modules et le bloc bc
// idres = ID de la zone contenant le resultat
// par = parcours
function buildInput(modules,bc,idres,par){
  let col = Style.colorBloc(Maquette.get().getFormation().getIndexBloc(bc),Maquette.get().getFormation().getBlocs().length)
  let e = document.createElement('td')
  e.setAttribute('style','margin:0px;vertical-align:bottom;border:1px solid black;font-size:0.7em;background-color:'+col)
  for(let m of modules){
    let obli = par==null ? m.getModalite()==Statut.OBLIGATOIRE : m.getModalite(par.getID())==Statut.OBLIGATOIRE
    e.innerHTML += '<p style="display:flex;justify-content:space-between;margin:2px"><span style="text-align:left;margin-top:2px">'+(obli ? '<u>' : '')+' '+m.getTitre()+'</u> ('+m.getECTS(bc.getID(),par==null ? null : par.getID())+' ECTS) : </span><input type="text" id="'+bc.getID()+'##'+m.getID()+'" maxlength="6" size="4" value="'+(obli ? '10' : '')+'"/></p>'

  }
  e.innerHTML += '<p id="'+idres+'" style="float:right;margin:0px"></p>'
  return e
}

// genere un element qui affiche les resultats du tableau [res,points,ects a obtenir, ects DISP, ects valides]
// l'element genere remplace les enfants de l'element parent
function buildOutput(parent,tabres){
  while(parent.firstChild) parent.removeChild(parent.firstChild)
  if(tabres[0]!=' - '){
    let e = document.createElement('p')
    e.setAttribute('style','margin:2px')
    let n = document.createElement('p') // note ou ' - '
    n.setAttribute('style','width:45px;text-align:center;font-weight:bold;border:2px solid black;border-radius:5px;margin:0px;margin-left:auto;margin-right:0px')
    if(tabres[0]=='DEF' || tabres[0]==' - ') n.innerHTML = ' - '
    else{
      let note = formateNote(tabres[1]/tabres[2])
      if(isNaN(note)) n.innerHTML = ' - '
      else n.innerHTML = note
    }
    e.appendChild(n)
    // resultat (DEF, ADM, ADMC, AJ, AJAC) et ECTS valides
    let r = document.createElement('p')
    r.setAttribute('style','margin:0px;margin-top:2px;margin-right:0px')
    r.innerHTML = '<b>'+(tabres[0]==' - ' ? '' : tabres[0])+'</b>'+(tabres[0]==' - ' ? '' : ' ('+ tabres[4]+' ECTS validés)')
    e.appendChild(r)
    parent.appendChild(e)
  }
}

function initCalculette(){
  let pres = document.getElementById('resultat')
  if(pres!=null) pres.innerHTML = ''
  let divTable = document.getElementById('table_notes')
  while(divTable.firstChild) divTable.removeChild(divTable.firstChild)
  let sel = document.getElementById('sel_annee').value
  let annee = parseInt(sel[0])
  let par = Maquette.get().getFormation().getParcoursByID(sel.substring(2,sel.length)) // parcours de l'annee ou null si pas de parcours
  let t = document.createElement('table')
  t.setAttribute('id','tableau_notes')
  t.setAttribute('style','border-collapse:collapse;text-align:center;table-layout:fixed')
  let comp = document.createElement('tr')
  let e = document.createElement('td')
  e.setAttribute('style','text-align:left;border:3px solid black;font-size:0.7em')
  e.innerHTML = '<b>'+Maquette.get().getFormation().getLMD()+annee+(par==null ? '' : ' '+par.getNom())+'</b><p id="$%@" style="float:right;margin:0px"></p>'
  comp.appendChild(e)
  let exist_annuelles = false
  let annuelles = document.createElement('tr')
  e = document.createElement('td')
  e.setAttribute('style','text-align:left;border:1px solid black;font-size:0.7em')
  e.innerHTML = 'Modules annuels'+'<p id="@ann" style="float:right;margin:0px"></p>'
  annuelles.appendChild(e)
  let sem1 = document.createElement('tr')
  e = document.createElement('td')
  e.setAttribute('style','text-align:left;border:1px solid black;font-size:0.7em')
  e.innerHTML = 'S'+(annee*2-1)+'<p id="@sem1" style="float:right;margin:0px"></p>'
  sem1.appendChild(e)
  let sem2 = document.createElement('tr')
  e = document.createElement('td')
  e.setAttribute('style','text-align:left;border:1px solid black;font-size:0.7em')
  e.innerHTML = 'S'+(annee*2)+'<p id="@sem2" style="float:right;margin:0px"></p>'
  sem2.appendChild(e)
  for(let bc of Maquette.get().getFormation().getBlocs()){
    let col = Style.colorBloc(Maquette.get().getFormation().getIndexBloc(bc),Maquette.get().getFormation().getBlocs().length)
    let m_ann = Maquette.get().getModulesAnnuels(annee,bc,par)
    if(m_ann.length!=0) exist_annuelles = true
    let m_sem1 = Maquette.get().getModulesSemestriels(annee*2-1,bc,par)
    let m_sem2 = Maquette.get().getModulesSemestriels(annee*2,bc,par)
    if(m_ann.length!=0 || m_sem1.length!=0 || m_sem2.length!=0){
      e = document.createElement('td')
      e.setAttribute('style','text-align:left;border:3px solid black;font-size:0.7em;background-color:'+col)
      e.innerHTML = '<b>'+bc.getNom()+'</b><p id="%'+bc.getID()+'" style="float:right;margin:0px"></p>'
      comp.appendChild(e)
      annuelles.appendChild(buildInput(m_ann,bc,bc.getID()+'$annuels',par))
      sem1.appendChild(buildInput(m_sem1,bc,bc.getID()+'$sem1',par))
      sem2.appendChild(buildInput(m_sem2,bc,bc.getID()+'$sem2',par))
    }
  } 
  t.appendChild(comp)
  if(exist_annuelles) t.appendChild(annuelles)
  t.appendChild(sem1)
  t.appendChild(sem2)
  divTable.appendChild(t)
  divTable.innerHTML += '<br><input type="button" onclick="calculResultat()" value="CALCUL">'
  calculResultat()
}

function formateNote(n){
  return Math.floor(n*1000)/1000
}

// renvoie le resultat, les notes doivent etre renseignees de facon correcte (pas trop d'option, le bon nombre de module a choix, etc)
// une note peut etre DEF, DISP ou un nombre dans [0,20]
function calculResultat(){
  let sel = document.getElementById('sel_annee').value
  let numAnnee = parseInt(sel[0])
  let par = Maquette.get().getFormation().getParcoursByID(sel.substring(2,sel.length))
  // pour chaque bloc, on ajoute toutes les notes*ECTS et on compte les ECTS
  let comp = [new Map(),new Map(),new Map(),new Map()] // {id_bloc:[resultat,points,ects a obtenir (pas DISP),ects acquis par DISP,ects valides]...} pour modules annuels, du premier semestre, du deuxieme, et sur l'annee
  for(let bc of Maquette.get().getFormation().getBlocs()){
    if((par==null && Maquette.get().blocDansAnnee(numAnnee,bc.getID())) || (par!=null && Maquette.get().blocDansAnnee(numAnnee,bc.getID(),par.getID()))){
      comp[0].set(bc.getID(),['',0,0,0,0])
      comp[1].set(bc.getID(),['',0,0,0,0])
      comp[2].set(bc.getID(),['',0,0,0,0])
      comp[3].set(bc.getID(),['',0,0,0,0])
    }
  }
  let ok = true
  let inputs = document.getElementsByTagName('input')
  let i = 0
  // recuperation des points et ects par competence pour modules annuels et de chaque semestre
  while(i<inputs.length && ok){
    if(inputs[i].id.includes('##')){
      let idsplit = inputs[i].id.split('##')
      let id_bloc = idsplit[0]
      let id_module = idsplit[1]
      let m = Maquette.get().getModuleByID(id_module)
      let obli = m.getModalite(par==null ? null : par.getID())==Statut.OBLIGATOIRE
      let note = inputs[i].value
      let sems = m.getSemestres()
      let indice = sems.length==2 ? 0 : (sems[0]%2==0 ? 2 : 1)
      let avant,poids
      switch(note){
        case 'DEF' :
          avant = comp[indice].get(id_bloc)
          poids = m.getECTS(id_bloc,par==null ? null : par.getID())
          if(obli) comp[indice].set(id_bloc,['DEF',avant[1],avant[2]+poids,avant[3],avant[4]])
          else comp[indice].set(id_bloc,[avant[0],avant[1],avant[2]+poids,avant[3],avant[4]])
          break
        case 'DISP' :
          avant = comp[indice].get(id_bloc)
          poids = m.getECTS(id_bloc,par==null ? null : par.getID())
          comp[indice].set(id_bloc,[avant[0],avant[1],avant[2],avant[3]+poids,avant[4]])
          break
        case '' :
          if(obli) ok = 'saisie obligatoire sur '+m.getTitre()
          break
        default :
          let val = parseFloat(note)
          if(Number.isNaN(val) || val<0 || val>20) ok = 'saisie incorrecte sur '+m.getTitre()
          else{
            avant = comp[indice].get(id_bloc)
            poids = m.getECTS(id_bloc,par==null ? null : par.getID())
            comp[indice].set(id_bloc,[avant[0],avant[1]+val*poids,avant[2]+poids,avant[3],val>=10 ? avant[4]+poids : avant[4]])
          }
      }
    }
    i++
  }
  if(ok!=true) alert(ok) // saisies incorrectes
  else{ // saisies correctes
    // resultats annuels
    let toutecomp8 = true // toutes les competences >=8
    let annee = ['',0,0,0,0]
    for(let idbc of comp[0].keys()){
      let ann = comp[0].get(idbc)
      let sem1 = comp[1].get(idbc)
      let sem2 = comp[2].get(idbc)
      let tout = comp[3].get(idbc)
      // calcul resultat par semestre
      if(sem1[0]!='DEF'){
        if(sem1[2]!=0){
          let val = sem1[1]/sem1[2]
          if(val>=10) sem1[0] = 'ADM'
          else sem1[0] = 'AJ'
        }
        else sem1[0] = ' - '
      }
      if(sem2[0]!='DEF'){
        if(sem2[2]!=0){
          let val = sem2[1]/sem2[2]
          if(val>=10) sem2[0] = 'ADM'
          else sem2[0] = 'AJ'
        }
        else sem2[0] = ' - '
      }
      if(ann[2]==0) ann[0]=' - '
      if(ann[0]=='DEF' || sem1[0]=='DEF' || sem2[0]=='DEF'){
        tout[0] = 'DEF'
        tout[4] = ann[4]+sem1[4]+sem2[4]
        toutecomp8 = false
        annee[0] = 'DEF'
        annee[4] += tout[4]
      }
      else{
        let n = ann[1]+sem1[1]+sem2[1]
        let p = ann[2]+sem1[2]+sem2[2]
        if(p!=0){
          if(n/p>=10){
            // compensations annuelles dans chaque competence
            if(ann[2]!=0 && ann[1]/ann[2]<10) ann[4] = ann[2]
            if(sem1[0]=='AJ'){
              sem1[0] = 'ADMC'
              sem1[4] = sem1[2]
            }
            if(sem2[0]=='AJ'){
              sem2[0] = 'ADMC'
              sem2[4] = sem2[2]
            }
            tout = ['ADM',n,p,ann[3]+sem1[3]+sem2[3],ann[4]+sem1[4]+sem2[4]]
          }
          else tout = ['AJ',n,p,ann[3]+sem1[3]+sem2[3],ann[4]+sem1[4]+sem2[4]]
          if(n/p<8) toutecomp8 = false
          annee[1] += n
          annee[2] += p
          annee[3] += tout[3]
          annee[4] += tout[4]
        }
      }
      comp[0].set(idbc,ann)
      comp[1].set(idbc,sem1)
      comp[2].set(idbc,sem2)
      comp[3].set(idbc,tout)
    }
    // resultat de l'annee
    if(annee[0]!='DEF' && annee[2]!=0){
      let final = annee[1]/annee[2]
      if(final<10){
        if(annee[4]>=45 && Maquette.get().getFormation().getLMD()=='L' && numAnnee<3) annee[0] = 'AJAC'
        else annee[0] = 'AJ'
      }
      else{
        if(toutecomp8){
          annee[0] = 'ADM'
          annee[4] = 0
          // compensations annuelles entre competences
          for(let idbc of comp[0].keys()){
            let ann = comp[0].get(idbc)
            let sem1 = comp[1].get(idbc)
            let sem2 = comp[2].get(idbc)
            let tout = comp[3].get(idbc)
            if(tout[0]=='AJ'){
              tout[0] = 'ADMC'
              if(ann[2]!=0 && ann[1]/ann[2]<10) ann[4] = ann[2]
              if(sem1[0]=='AJ'){
                sem1[0] = 'ADMC'
                sem1[4] = sem1[2]  
              }
              if(sem2[0]=='AJ'){
                sem2[0] = 'ADMC'
                sem2[4] = sem2[2]  
              }
              tout[4] = ann[4]+sem1[4]+sem2[4]
            }
            comp[0].set(idbc,ann)
            comp[1].set(idbc,sem1)
            comp[2].set(idbc,sem2)
            comp[3].set(idbc,tout)
            annee[4] += tout[4]
          }
        }
        else{
          annee[0] = 'AJ'
        }
      }
    }
    // affichage
    // input : ID bloc+'##'+ID module
    // resultats competence par semestre ou modules annuels : ID bloc+'$annuels' ou ID bloc+'$sem1' ou ID bloc+'$sem2'
    // resultat annuel competence : %ID bloc
    // resultat total semestre et modules annuels : @sem1 ou @sem2 ou @ann
    // resultat annee : $%@ 
    for(let idbc of comp[0].keys()){
      let pann = document.getElementById(idbc+'$annuels')
      if(pann!=null) buildOutput(document.getElementById(idbc+'$annuels'),comp[0].get(idbc))
      buildOutput(document.getElementById(idbc+'$sem1'),comp[1].get(idbc))
      buildOutput(document.getElementById(idbc+'$sem2'),comp[2].get(idbc))
      buildOutput(document.getElementById('%'+idbc),comp[3].get(idbc))
    }
    buildOutput(document.getElementById('$%@'),annee)
    // resultats par semestres
    for(let s=1;s<3;s++){
      let vals = ['',0,0,0,0]
      for(let idbc of comp[0].keys()){
        let sem = comp[s].get(idbc)
        vals[1] += sem[1]
        vals[2] += sem[2]
        vals[4] += sem[4]
      }
      buildOutput(document.getElementById('@sem'+s),vals)
    }
    // resultat des modules annuels
    let ele = document.getElementById('@ann')
    if(ele!=null){
      let vals = ['',0,0,0,0]
      for(let idbc of comp[0].keys()){
        let sem = comp[0].get(idbc)
        vals[1] += sem[1]
        vals[2] += sem[2]
        vals[4] += sem[4]
      }
      buildOutput(ele,vals)
    }
  }
}