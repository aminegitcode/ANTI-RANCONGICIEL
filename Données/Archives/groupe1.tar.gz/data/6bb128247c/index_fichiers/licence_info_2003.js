addMaquette({
    "FORMATION": {
        "NOM": "Licence Informatique 2003",
        "ETABLISSEMENT": "Université de Picardie - Jules Verne",
        "ANNEES": "2003/08",
        "NB_SEMESTRES": 6,
        "LMD": "L",
        "PARCOURS": [
            {
                "ID": "PAR_1",
                "NOM": "parcours INFO",
                "DESCRIPTION": "",
                "ANNEES": [
                    2,
                    3
                ]
            },
            {
                "ID": "PAR_2",
                "NOM": "parcours MIAGE",
                "DESCRIPTION": "Méthodes Informatiques Appliquées à la Gestion des Entreprises",
                "ANNEES": [
                    2,
                    3
                ]
            }
        ],
        "BLOCS": [],
        "RESPONSABLES": [],
        "M3C": [],
        "PRESENTATION": []
    },
    "MODULES": [
        {
            "SEMESTRE": "1",
            "ID": "UE1.1",
            "TITRE": "INTRODUCTION A L'INFORMATIQUE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Exemples informatifs permettant d'illustrer des domaines de l'informatique : sciences informatiques vs bureautique, histoire de l'informatique, analyse et résolution de problème, complexité et preuves de programmes, problèmes indécidables et non réalisables en temps raisonnable, langages de programmation (langages objets, langages fonctionnels, langages logiques...)",
                "Notion de problème (données, résultats) et d'algorithmes pour le résoudre, programmes, sous-programmes (paramètres), instructions, instructions conditionnelles, instructions répétitives (boucle avec ou sans compteur), indentation, variables, types (entier, réel, chaîne, booléen), expressions, affectations, éléments de logique, structure de données (tableau à une dimension).",
                "Connaissances d'utilisation de la machine (architecture, unité centrale, unité de commande, ALU, périphériques, écran, clavier, souris, disque dur...), connaissances de bases d'un système de fichiers (répertoires ou dossiers, fichiers, création, déplacement, copier-coller...) manipulations de bases de logiciels (éditeur ou traitement de texte, butineur Internet...)",
                "Programmation en langage JAVA (compilation, exécution, débogage)"
            ],
            "PREREQUIS": [],
            "CM": 18,
            "TD": 21,
            "TP": 11,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UE1.2",
            "TITRE": "MATHEMATIQUES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UE1.3",
            "TITRE": "PHYSIQUE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UE1.4",
            "TITRE": "CHIMIE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UE1.5",
            "TITRE": "BIOLOGIE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UE1.6",
            "TITRE": "ANGLAIS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UE2.1",
            "TITRE": "ANGLAIS / DROIT",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Anglais, droit de l'informatique"
            ],
            "PREREQUIS": [],
            "CM": 25,
            "TD": 25,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UE2.2",
            "TITRE": "ALGORITHMIQUE ET PROGRAMMATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "",
                    "CHOIX": [
                        15,
                        [
                            "UE2.2",
                            "UE2.3",
                            "UE2.4",
                            "UE2.5",
                            "UE2.6"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Quelques exemples d'algorithmes classiques : tris, manipulations de matrices, algorithmes sur les chaînes...",
                "Structure de données à accés direct (tableaux à une ou plusieurs dimensions) ou non (chaîne de caractères), enregistrements, structuration objets (rapprochement des données et des sous-programmes les manipulant), notion de référence, passages de paramètres par valeurs vs par références",
                "Programmation en langage JAVA : entre autres, mise en oeuvre d'un exemple sur trois ou quatre TPs, exemple de manipulation de fichiers"
            ],
            "PREREQUIS": [
                "UE1.1"
            ],
            "CM": 12,
            "TD": 21,
            "TP": 17,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UE2.3",
            "TITRE": "ANALYSE ET ETUDE DE CAS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "",
                    "CHOIX": [
                        15,
                        [
                            "UE2.2",
                            "UE2.3",
                            "UE2.4",
                            "UE2.5",
                            "UE2.6"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Présentation rapide du cycle de développement d'un logiciel : expressions des besoins, étude préliminaire, conception détaillée, implantation, intégration, essais, maintenance",
                "Études de modèles de données de la méthode Merise : Modèle Conceptuel des données, Modèle organisationnel des données",
                "La structuration d'un logiciel pour la programmation structurée : notion d'interface et d'implémentation, utilisation de procédures et de fonctions, commentaires",
                "L'analyse descendante : études de cas, analyse de problèmes récursifs",
                "La documentation : documentation utilisateur, documentation portant sur l'analyse, documentation d'installation du logiciel, documentation sur l'implémentation du logiciel"
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 35,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UE2.4",
            "TITRE": "THÉORIE DES LANGAGES FORMELS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "",
                    "CHOIX": [
                        15,
                        [
                            "UE2.2",
                            "UE2.3",
                            "UE2.4",
                            "UE2.5",
                            "UE2.6"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Notions de base (mots, langages, ... )",
                "Langages reconnaissables, automates finis : définition, représentations, expressions rationnelles, langage reconnu par un automate (algorithme de Mac Naughton et Yamada), propriétés de fermeture rationnelles, construction d'automates (algorithme de Glushkow), théorème de Kleene, déterminisme, propriétés de fermeture non rationnelles, minimalité, théorème de l'étoile",
                "Langages algébriques",
                "Automates à pile, langages reconnus",
                "Grammaires algébriques, langages engendrés",
                "Langages algébriques déterministes",
                "Ambiguté"
            ],
            "PREREQUIS": [],
            "CM": 21,
            "TD": 29,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UE2.5",
            "TITRE": "INFORMATIQUE THÉORIQUE I",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "",
                    "CHOIX": [
                        15,
                        [
                            "UE2.2",
                            "UE2.3",
                            "UE2.4",
                            "UE2.5",
                            "UE2.6"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Logique des propositions",
                "Logique des prédicats",
                "Raisonnements (par récurrence, par l'absurde, ...)",
                "Résolution d'équations de récurrence",
                "Ordre de grandeur des fonctions",
                "Applications à l'informatique",
                "Invariants",
                "Preuves de Programmes",
                "Complexité asymptotique"
            ],
            "PREREQUIS": [],
            "CM": 21,
            "TD": 29,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UE2.6",
            "TITRE": "ARCHITECTURE DES ORDINATEURS I / REPRÉSENTATION DE L'INFORMATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "",
                    "CHOIX": [
                        15,
                        [
                            "UE2.2",
                            "UE2.3",
                            "UE2.4",
                            "UE2.5",
                            "UE2.6"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Algèbre de Boole, loi de Morgan, théorème de Shannon",
                "Les portes logiques (NOT, AND, OR, XOR, NOR, NAND)",
                "Les circuits intégrés (du transistor à la porte NOR...)",
                "Quelques circuits de bases : circuits combinatoires (décodeurs, multiplexeur, additionneur,...), circuits séquentiels (bascules, registres, compteur,...)",
                "Exemple d'architecture d'un microprocesseur",
                "Exemple d'architecture d'une machine",
                "Rappel de Numération : les différentes bases utilisées en Informatique, algorithmes de conversion",
                "Représentation d'informations : les chiffres, caractères (code DCB, ISO6, EBCDIC, ASCII, UNICODE), les entiers, entiers signés, les fractionnaires en virgule fixe (signé ou non), les fractionnaires en virgule flottante",
                "Opérations sur les nombres (entiers et réels) : rappel des algorithmes opératoires, identification de la véracité des résultats"
            ],
            "PREREQUIS": [],
            "CM": 18,
            "TD": 32,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UE2.x",
            "TITRE": "DOMAINE S2",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Une UE à choisir parmi les UEs de sciences"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UE2.y",
            "TITRE": "LIBRE S2",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Une UE à choisir parmi les UEs de sciences ou autre"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UE3.7",
            "TITRE": "ANGLAIS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "anglais"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 25,
            "TP": 25,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UE3.8",
            "TITRE": "STRUCTURES LINÉAIRES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "",
                    "CHOIX": [
                        15,
                        [
                            "UE3.8",
                            "UE3.9",
                            "UE3.10",
                            "UE3.11",
                            "UE3.12"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Récursivité",
                "Preuve de programmes",
                "Structures de données linéaires (Liste, Pile, File)",
                "Algorithmique des structures linéaires (ex : Tris, Recherches...)",
                "Analyse en complexité et preuve de fonctionnement des objets étudiés"
            ],
            "PREREQUIS": [
                "UE2.2"
            ],
            "CM": 18,
            "TD": 24,
            "TP": 8,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UE3.9",
            "TITRE": "BASES DE DONNÉES I",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "",
                    "CHOIX": [
                        15,
                        [
                            "UE3.8",
                            "UE3.9",
                            "UE3.10",
                            "UE3.11",
                            "UE3.12"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Introduction aux SGBD : bref historique, objectifs, avantages et inconvénients des SGBD",
                "Bref rappel de la démarche de conception d'un SI du point de vue des données",
                "Conception du schéma de stockage des données d'un SI : le modèle Entité/Association (E/A) et son utilisation dans une démarche analytique",
                "Le modèle relationnel (relations et clés)",
                "Les règles de transformation du modèle E/A vers le modèle relationnel",
                "Introduction au langage SQL : ordres de création d'un schéma relationnel, de manipulations et de consultations simples des données (introduction aux jointures)"
            ],
            "PREREQUIS": [
                "UE2.3"
            ],
            "CM": 15,
            "TD": 18,
            "TP": 17,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UE3.10",
            "TITRE": "WEB I",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "",
                    "CHOIX": [
                        15,
                        [
                            "UE3.8",
                            "UE3.9",
                            "UE3.10",
                            "UE3.11",
                            "UE3.12"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Généralités sur Internet : interconnexion de réseaux, TCP/IP, adresse IP, nom de domaines, protocole, URL, le W3C (ping), moteurs de recherche, référencement de site",
                "Le protocole HTTP :  communication entre client et serveur, requête/réponse, code de réponse (requête HTTP via telnet, ou ethereal pour tracer l'échange)",
                "Le HTML : les tags, l'interprétation par les navigateurs (écriture de page), les éditeurs, validateurs de HTML",
                "Java-script : langage de script du Dom HTML, DHTML, page dynamique cote client (écriture de script)",
                "Le CSS : style et feuille de style  (écrire du CSS dans des pages HTML)",
                "Introduction à la génération dynamique de page web coté serveur : architecture d'une application Web dynamique avec base de donnée, PHP"
            ],
            "PREREQUIS": [],
            "CM": 18,
            "TD": 18,
            "TP": 14,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UE3.11",
            "TITRE": "PROGRAMMATION FONCTIONNELLE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "",
                    "CHOIX": [
                        15,
                        [
                            "UE3.8",
                            "UE3.9",
                            "UE3.10",
                            "UE3.11",
                            "UE3.12"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Fonctions, composition de fonctions, fonctions récursives",
                "Type, inférence de type",
                "Types construits : types récursifs, types paramétrés",
                "Filtrage, gardes",
                "Portée des expressions",
                "Structures de données : liste, arbres",
                "Gestion des exceptions",
                "Polymorphisme",
                "Entrées / Sorties",
                "Amplication en Caml"
            ],
            "PREREQUIS": [
                "UE2.2"
            ],
            "CM": 18,
            "TD": 18,
            "TP": 14,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UE3.12",
            "TITRE": "INFORMATIQUE THÉORIQUE II",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "",
                    "CHOIX": [
                        15,
                        [
                            "UE3.8",
                            "UE3.9",
                            "UE3.10",
                            "UE3.11",
                            "UE3.12"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Systèmes relationnels : relations d'ordre, relations d'équivalence, treillis, points fixes",
                "Structures Algébriques : groupes finis, algèbre modulaire, étude algébrique des treillis",
                "Méthode de récurence : fonctions génératrices, séries et polynômes formels, séries rationnelles, manipulations formelles, fonctions génératrices, applications"
            ],
            "PREREQUIS": [
                "UE2.5"
            ],
            "CM": 21,
            "TD": 29,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UE3.x",
            "TITRE": "DOMAINE S3",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Une UE à choisir parmi les UEs de sciences"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UE3.y",
            "TITRE": "LIBRE S3",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Une UE à choisir parmi les UEs de sciences ou autre"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UE4.13",
            "TITRE": "ANGLAIS / COMMUNICATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Anglais",
                "Communication : techniques d'entretient, rédaction d'un C.V., d'un rapport"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 50,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UE4.14",
            "TITRE": "LANGAGES DE PROGRAMMATION I",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Langage C : syntaxe de base, passage d'arguments, pointeurs, fichiers, pré-processing, allocation mémoire, make"
            ],
            "PREREQUIS": [
                "UE3.8"
            ],
            "CM": 12,
            "TD": 18,
            "TP": 20,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UE4.15",
            "TITRE": "SYSTÈMES D'EXPLOITATION DES ORDINATEURS I",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Introduction aux SE : principes, généralités",
                "Système de gestion de fichiers : organisation de l'espace disque, sécurité",
                "Processus : ordonnancement, inter-blocage, échange de messages",
                "Synchronisation des processus : sémaphore, exclusion mutuelle",
                "Illustration sous UNIX : shell, ext2fs/ext3fs, ..."
            ],
            "PREREQUIS": [],
            "CM": 18,
            "TD": 21,
            "TP": 11,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UE4.16",
            "TITRE": "ALGORITHMIQUE / STRUCTURES DE DONNÉES COMPLEXES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Études des arbres comme structure de données : ABR, arbres équilibrés, AVL, B-arbres",
                "Comparaison avec la technique de hachage",
                "Applications : codage de Hoffman, structures de dictionnaires",
                "Tas, utilisation pour la gestion d'ensemble, de partitions",
                "Analyse en complexité et preuve de fonctionnement des algorithmes présentés"
            ],
            "PREREQUIS": [
                "UE3.8"
            ],
            "CM": 18,
            "TD": 24,
            "TP": 8,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UE4.17",
            "TITRE": "MODÉLISATION OBJET",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Étude de UML",
                "Étude de cas",
                "Étude d'outils permettant de générer un squelette de programme à partir d'une modélisation objet : Rational Rose, Poseidon"
            ],
            "PREREQUIS": [
                "UE2.3"
            ],
            "CM": 12,
            "TD": 21,
            "TP": 17,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UE4.18",
            "TITRE": "BASES DE DONNÉES II",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [
                "UE3.9",
                "UE2.2"
            ],
            "CM": 15,
            "TD": 18,
            "TP": 17,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UE4.19",
            "TITRE": "WEB II",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [
                "UE3.10"
            ],
            "CM": 18,
            "TD": 18,
            "TP": 14,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UE4.x",
            "TITRE": "DOMAINE S4",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Une UE à choisir parmi les UEs de sciences"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UE4.y",
            "TITRE": "LIBRE S4",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Une UE à choisir parmi les UEs de sciences ou autre"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UE5.20",
            "TITRE": "ANGLAIS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Anglais"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 25,
            "TP": 25,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UE5.21",
            "TITRE": "PROGRAMMATION OBJET AVANCÉE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Programmation Objet : classe, objet, héritage, interface",
                "Design-Pattern",
                "Techniques associées : package, APIs, gestion des Exceptions, sérialisation (Application en langage JAVA)"
            ],
            "PREREQUIS": [
                "UE4.16",
                "UE4.17"
            ],
            "CM": 15,
            "TD": 24,
            "TP": 11,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UE5.22",
            "TITRE": "RÉSEAUX I",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Composants et topologies des réseaux",
                "Modes de transmission",
                "Modèle client-serveur",
                "Notions de protocole : description et exemples",
                "Serveur de nom de domaine",
                "Serveur de messagerie"
            ],
            "PREREQUIS": [
                "UE4.15"
            ],
            "CM": 21,
            "TD": 0,
            "TP": 29,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UE5.23",
            "TITRE": "BASES DE DONNÉES III",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Rappel du modèle OLTP (On Line Transactionnel Processing), de la notion d'infocentre et présentation du modèle OLAP (On Line Analytical Processing) : modélisation multi-dimensionnelle (MOLAP)",
                "Architecture et conception d'un entrepôt de données",
                "Notions sur les bases de données déductives et orientée-objet",
                "Administration d'un système de base de donnée (SGBD) : les différentes t,ches associées : installation, gestion des surfaces de stockages, gestion de la mémoire, gestion des utilisateurs, sécurité",
                "Paramétrage (tuning) du SGBD en fonction du type d'application (transactionnel, infocentre, entrepôt de données) et des objets (gestion des blocs et segments, choix d'indexation)"
            ],
            "PREREQUIS": [
                "UE4.18"
            ],
            "CM": 15,
            "TD": 12,
            "TP": 23,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UE5.24",
            "TITRE": "SYSTÈMES D'EXPLOITATION DES ORDINATEURS II",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Mémoire : segmentation, pagination, mémoire virtuelle",
                "Ressources : définition, classes de ressources",
                "Allocation de ressources déterminisme et inter-blocage : conditions de Berstein, algorithmes du banquier",
                "Système multi-threadés",
                "Installation et configuration d'un (ou plusieurs) SE"
            ],
            "PREREQUIS": [
                "UE4.15"
            ],
            "CM": 18,
            "TD": 21,
            "TP": 11,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UE5.25",
            "TITRE": "ALGORITHMIQUE DES GRAPHES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Définitions de base : connexité et forte connexité, arbres et arborescences",
                "Parcours de graphes et algorithmes fondamentaux : parcours en largeur, en profondeur, LexBFS, composantes fortement connexes, blocs et points d'articulation, parcours euleriens et hamiltoniens, arbre recouvrant de poids minimal, algorithmes du plus court chemin",
                "Familles particulières des graphes, graphes de tournois, graphes sans circuits, graphes bipartis",
                "Graphes et Algorithmes d'optimisation",
                "Flot et couplage, coloriage, clique et stable maximum, ordonnancement optimal"
            ],
            "PREREQUIS": [
                "UE4.16"
            ],
            "CM": 18,
            "TD": 24,
            "TP": 8,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UE5.26",
            "TITRE": "ARCHITECTURE DES ORDINATEURS II / LANGAGE D'ASSEMBLAGE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Compléments d'architecture : les bus du Microprocesseur, la mémoire vue du Microprocesseur, les registres du Microprocesseur",
                "Le Langage d'assemblage : les modes d'adressage, écriture d'une ligne de programme, présentation du jeu d'instructions, écriture de programmes (exécution conditionnée, simulation de boucles, sous-programme, notion de variable, appels systèmes",
                "Réalisation d'un petit projet"
            ],
            "PREREQUIS": [
                "UE2.6"
            ],
            "CM": 12,
            "TD": 18,
            "TP": 20,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UE5.x",
            "TITRE": "DOMAINE S5",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Une UE à choisir parmi les UEs de sciences"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UE5.y",
            "TITRE": "LIBRE S5",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Une UE à choisir parmi les UEs de sciences ou autre"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UE6.27",
            "TITRE": "ANGLAIS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Anglais"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 25,
            "TP": 25,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UE6.28",
            "TITRE": "LANGAGE DE PROGRAMMATION II",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Programmation logique : présentation de la logique du premier ordre, résolution, clauses de Horn et système d'inférence pour clause de Horn, unification, ordre d'évulsion et coupures, logique du premier ordre avec contraintes",
                "Programmation ADA : exception, paquetages, genericite, taches et synchronisation"
            ],
            "PREREQUIS": [
                "UE4.16"
            ],
            "CM": 21,
            "TD": 21,
            "TP": 8,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UE6.29",
            "TITRE": "COMPLÉMENT DE JAVA",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Interface utilisateur graphique : composant (fenêtre, panel, bouton, ...), geometry manager, programmation événementielle",
                "Utilisation d'un IDE (JBuilder ...)",
                "Programmation Parallèle thread, synchronisation, exclusion mutuelle, ..."
            ],
            "PREREQUIS": [
                "UE5.21"
            ],
            "CM": 18,
            "TD": 21,
            "TP": 11,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UE6.30",
            "TITRE": "INFORMATIQUE THÉORIQUE III",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Principe fondamentaux du dénombrement",
                "Ensembles énumérables, ensembles non énumérables",
                "Théorèmes de base sur les probabilités (événements incompatibles et probabilités totales, événements indépendants et probabilités composées, probabilités conditionnelles et théorème de Bayes); pratique sur des exemples",
                "Arithmétique p-adique",
                "Arithmétique sur Z/nZ",
                "Transformée de Fourier sur les entiers",
                "Distances"
            ],
            "PREREQUIS": [
                "UE3.12"
            ],
            "CM": 21,
            "TD": 29,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UE6.31",
            "TITRE": "RÉSEAUX II",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Architecture des réseaux : modèles en couches, l'architecture OSI",
                "La couche physique: bande passante, rapidité de modulation, filtrage et bruits, numérisation, codage",
                "La couche liaison de données: protocoles de communication, découpage en trames, contrôle de flux, contrôle d'erreurs",
                "La couche réseau : protocoles de connexion, découpage en paquets, routage, multiplexage, segmentation, détection/correction des erreurs",
                "La couche transport : transport de bout en bout, qualité de service, transparence, adressage",
                "La couche session : gestion du dialogue, synchroniser et gérer les activités",
                "La couche présentation : accès aux primitives de service session, structures de données complexes, gestion des structures de données, conversions des données internes et externes",
                "La couche application : applications en mode connecté, applications en mode sans connexion",
                "Normalisation"
            ],
            "PREREQUIS": [
                "UE5.22"
            ],
            "CM": 21,
            "TD": 29,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UE6.32",
            "TITRE": "INTELLIGENCE ARTIFICIELLE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Résolution de problèmes : problèmes avec changement d'état (algorithmes backtrack, A*), problèmes décomposables (algorithme AO*), jeux de stratégie ( algorithmes minmax , SSS*)",
                "Représentation des connaissances : représentation logique, représentation par réseaux (réseaux sémantiques, graphes conceptuels)"
            ],
            "PREREQUIS": [
                "UE3.12",
                "UE4.16",
                "UE5.25"
            ],
            "CM": 18,
            "TD": 24,
            "TP": 8,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UE6.33",
            "TITRE": "RECHERCHE OPÉRATIONNELLE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Problématique et outils fondamentaux de la recherche opérationnelle",
                "Présentation des algorithmes/méthodes génériques : méthodes exactes et méthodes approchées",
                "Notion de programme linéaire et modélisation",
                "Algorithmes de programmation linéaire : étude d'un cas, l'algorithme primal du simplexe, initialisation et finitude de l'algorithme du simplexe",
                "Programmation dynamique discrète : étude du problème de la gestion de stock, étude du problème de l'allocation de ressources",
                "Résolution approchée : difficulté de résolution de certains problèmes, utilisation des algorithmes gloutons, notions d'utilisation des algorithmes par exploration locale"
            ],
            "PREREQUIS": [
                "UE3.8"
            ],
            "CM": 18,
            "TD": 24,
            "TP": 8,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UE6.x",
            "TITRE": "DOMAINE S6",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Une UE à choisir parmi les UEs de sciences"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UE6.y",
            "TITRE": "LIBRE S6",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Une UE à choisir parmi les UEs de sciences ou autre"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UE6.34",
            "TITRE": "STAGE",
            "TYPE": "STAGE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Stage d'au moins 4 semaines"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        }
    ]
})