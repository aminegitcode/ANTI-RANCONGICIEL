addMaquette({
    "VERSION": {
        "MAQUETOR": "v0.8.1",
        "DATE": "2023-11-30 19:22:39.754415"
    },
    "FORMATION": {
        "NOM": "Licence Informatique 2012",
        "ETABLISSEMENT": "Université de Picardie - Jules Verne",
        "ANNEES": "2012/17",
        "NB_SEMESTRES": 6,
        "LMD": "L",
        "PARCOURS": [
            {
                "ID": "PAR_1",
                "NOM": "parcours INFO",
                "DESCRIPTION": "",
                "ANNEES": [
                    2,
                    3
                ]
            },
            {
                "ID": "PAR_2",
                "NOM": "parcours MIAGE",
                "DESCRIPTION": "Méthodes Informatiques Appliquées à la Gestion des Entreprises",
                "ANNEES": [
                    2,
                    3
                ]
            },
            {
                "ID": "PAR_3",
                "NOM": "parcours BIOLOGIE/SANTE",
                "DESCRIPTION": "",
                "ANNEES": [
                    2,
                    3
                ]
            }
        ],
        "BLOCS": [],
        "RESPONSABLES": [],
        "M3C": [],
        "PRESENTATION": []
    },
    "MODULES": [
        {
            "SEMESTRE": 1,
            "ID": "UEinfo1.1",
            "TITRE": "LANGUE S1",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Anglais"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UEinfo1.2",
            "TITRE": "C2I",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "C2i"
            ],
            "PREREQUIS": [],
            "CM": 14,
            "TD": 16,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UEinfo1.3",
            "TITRE": "MTU",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Méthodologie du travail universitaire"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UEinfo1.4",
            "TITRE": "EEO",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Expression écrite et orale"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UEinfo1.5",
            "TITRE": "OUTILS MATHEMATIQUES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Fonctions usuelles (logarithme, exponentielles, fonctions puissances, fonctions trigonométriques). Limites et comportement asymptotique, croissances comparées",
                "Suites numériques (monotonie, arithmétique, géométrique, somme des premiers termes)",
                "Continuité, dérivabilité d’une fonction numérique. Tangente, convexité, inflexion. Calcul pratique des dérivées partielles (deux ou trois variables, pas de continuité des fonctions de plusieurs variables), utilisation pour les extrema de fonctions de deux variables",
                "Compléments sur les calculs de primitives et leur application au calcul d’intégrales : Intégration par partie, changement de variables, fractions rationnelles (cas simples)",
                "Equations différentielles linéaires du premier ordre, méthode de la variation de la constante, équations différentielles linéaires du second ordre à coefficients constants. Image d’un intervalle [a,b] par une fonction continue réelle (admis). Egalité et inégalité des accroissements finis (pourra être admis)"
            ],
            "PREREQUIS": [],
            "CM": 18,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 8,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UEinfo1.6",
            "TITRE": "INTRODUCTION A L'INFORMATIQUE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Notion de problème (données, résultats) et d'algorithmes pour le résoudre, programmes, sous-programmes (paramètres), instructions, instructions conditionnelles, instructions répétitives (boucle avec ou sans compteur), indentation, variables, types (entier, réel, chaîne, booléen), expressions, affectations, éléments de logique, structure de données (tableau à une dimension)",
                "Etude d’un tri (tri par sélection)",
                "En TPs, Machines et logiciels : connaissances d'utilisation de la machine (architecture, unité centrale, unité de commande, ALU, périphériques, écran, clavier, souris, disque dur...), connaissances de bases d'un système de fichiers (répertoires ou dossiers, fichiers, création, déplacement, copier-coller...) manipulations de bases de logiciels (éditeur ou traitement de texte, navigateur Internet...)",
                "En TPs, Programmation en langage JAVA (compilation, exécution, débogage)"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 22,
            "TP": 8,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 8,
            "GROUPES_TP": 16,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UEinfo1.7",
            "TITRE": "SYSTEME D'EXPLOITATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Implication des OS : lien Hard/Soft, fonctionnalités des OS (Distinction User et Admin, Logs, Services, etc.)",
                "Terminologie autour des Systèmes d'Exploitation et des outils systèmes : différence entre interprétation et compilation, virus et sécurité Informatique",
                "Format de fichiers",
                "Norme POSIX",
                "Interfaçage : graphique (Fonctionnement de l'interface, Raccourcis et liens, Notions de programme et de tâche, etc.), console",
                "Présentation des différents Shell : commandes de bases, droits, notion de propriété, navigation, redirection",
                "Installation de Logiciel : licences, configuration de l'environnement, installation de Linux (séance de TP dédiée), tour d'horizon des logiciels libres"
            ],
            "PREREQUIS": [],
            "CM": 16,
            "TD": 0,
            "TP": 24,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 0,
            "GROUPES_TP": 8,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UEinfo1.8",
            "TITRE": "INTERNET ET PROGRAMMATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 4,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Généralités sur Internet : interconnexion de réseaux, TCP/IP, adresse IP, nom de domaines, protocole, URL, le W3C (ping), moteurs de recherche, référencement de site",
                "Communication client/serveur, les protocoles HTTP et HTTPS",
                "HTML : les tags, l'interprétation par les navigateurs (écriture de page), les éditeurs, validateurs de HTML, XHTML",
                "CSS : style et feuille de style  (écrire du CSS dans des pages HTML)"
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 28,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 8,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UEinfo1.9",
            "TITRE": "OUVERTURE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 4,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Option à choisir parmi les UE fondamentales de mathématiques, physique, chimie ou SVT"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.1",
            "TITRE": "LANGUE S2",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Anglais"
            ],
            "PREREQUIS": [
                "UEinfo1.1"
            ],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.2",
            "TITRE": "UE LIBRE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "A choisir parmi les UE Libres proposées par l'université"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.3",
            "TITRE": "PROJET PROFESSIONNEL ENCADRE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Elaboration par l'étudiant de son projet professionnel",
                "Rédaction de CV"
            ],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 14,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.4",
            "TITRE": "PROBABILITES ET STATISTIQUES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Vocabulaire de la statistique. Statistique descriptive à une et deux variables : représentations graphiques, paramètre de position et de dispersion. Droite de régression des moindres carrés",
                "Introduction au calcul des probabilités. Probabilité conditionnelle. Indépendance",
                "Notions de variables aléatoires réelles discrètes et à densité. Moments. Lois usuelles (dont Binomiale, Poisson, Normale). Approximation de la Binomiale par la Normale, théorème central-limite."
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.5",
            "TITRE": "ALGORITHMIQUE ET PROGRAMMATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Enregistrements, types énumérés",
                "Etude des tableaux : algorithmes de recherche, tri (rappel sélection, insertion, bulle)",
                "Tableaux multidimensionnels",
                "Tableaux associatifs",
                "Passage de paramètres (référence, valeur)",
                "Récursivité",
                "Notions de complexité (espace, temps)",
                "Fichiers",
                "Gestion des erreurs"
            ],
            "PREREQUIS": [
                "UEinfo1.6"
            ],
            "CM": 12,
            "TD": 18,
            "TP": 10,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 8,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.6",
            "TITRE": "ARCHITECTURE DES ORDINATEURS / REPRESENTATION DE L'INFORMATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Algèbre de Boole, loi de Morgan, théorème de Shannon",
                "Les portes logiques (NOT, AND, OR, XOR, NOR, NAND)",
                "Les circuits intégrés (du transistor à la porte NOR...)",
                "Quelques circuits de bases : circuits combinatoires (décodeurs, multiplexeur, additionneur,...), circuits séquentiels (bascules, registres, compteur,...)",
                "Architecture de Van Neumann : exemple d'architecture d'un microprocesseur, exemple d'architecture d'une machine",
                "Rappel de Numération : les différentes bases utilisées en Informatique, algorithmes de conversion",
                "Représentation d'informations : les chiffres, caractères (code DCB, ISO6, EBCDIC, ASCII, UNICODE), les entiers, entiers signés, les fractionnaires en virgule fixe (signé ou non), les fractionnaires en virgule flottante",
                "Opérations sur les nombres (entiers et réels) : rappel des algorithmes opératoires, identification de la véracité des résultats"
            ],
            "PREREQUIS": [],
            "CM": 16,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.7",
            "TITRE": "INITIATION AUX BASES DE DONNEES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Introduction aux Systèmes d'Information",
                "Présentation de la démarche de conception d'un SI au travers de la méthode MERISE",
                "Introduction et utilisation d'un Système de Gestion de Bases de Données",
                "Etude détaillée du  modèle Entité/Association (E/A) et du modèle relationnel",
                "Les règles de transformation du modèle E/A vers le modèle relationnel",
                "Introduction au langage SQL"
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 16,
            "TP": 12,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 8,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.8",
            "TITRE": "LOGIQUE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 4,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Logique propositionnelle : syntaxe, variables propositionnelles, connecteurs",
                "Théorie des modèles en logique propositionnelle : interprétation, validité, consistance, conséquence",
                "Théorie de la preuve en logique propositionnelle : système de preuve et déduction",
                "Complétude et décidabilité de la logique propositionnelle",
                "Logique des prédicats : syntaxe, prédicats, quantificateurs",
                "Théorie des modèles en logique des prédicats",
                "Théorie de la preuve en logique des prédicats",
                "Complétude et semi-décidabilité de la logique des prédicats",
                "Formes normales, formes clausales, résolution"
            ],
            "PREREQUIS": [],
            "CM": 14,
            "TD": 22,
            "TP": 4,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 8,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.9",
            "TITRE": "OUVERTURE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 4,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Option à choisir parmi les UE fondamentales de mathématiques, physique, chimie ou SVT"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo3.1",
            "TITRE": "LANGUE S3",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Anglais"
            ],
            "PREREQUIS": [
                "UEinfo2.1"
            ],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo3.2",
            "TITRE": "SYSTEME D'EXPLOITATION 2",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Configuration Shell : alias, droit par défaut, positionnement et implication des variables d'environnement, droits étendus, entrée et sortie standards",
                "Shell avancé et scripting : fonctions, structure de contrôle, paramétrage, approfondissement des commandes built-in",
                "Expressions régulières, illustration avec Sed, synthèse avec Perl, complément de l'interfaçage avec Tk",
                "Système de fichiers"
            ],
            "PREREQUIS": [
                "UEinfo1.7"
            ],
            "CM": 10,
            "TD": 12,
            "TP": 18,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 8,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo3.3",
            "TITRE": "STRUCTURES DE DONNEES FONDAMENTALES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Listes, Piles, Files, queues, table de hachage : spécification et implémentation",
                "Tri fusion, quicksort",
                "Calcul de complexité avancé",
                "Définitions (récursive) des arbres, des ABR",
                "Technique de tri par tas"
            ],
            "PREREQUIS": [
                "UEinfo2.5"
            ],
            "CM": 18,
            "TD": 24,
            "TP": 8,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 8,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo3.4",
            "TITRE": "BASES DE DONNEES RELATIONNELLES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Modèle E/A étendu",
                "Les règles de transformation du modèle E/A étendu vers le modèle relationnel",
                "Approfondissement du langage SQL : mise en œuvre de requêtes plus complexes à l’aide des fonctions agrégatives",
                "Optimisation algébrique et sous SQL des requêtes",
                "Présentation et justification de la classification des relations sous formes normales",
                "Algorithme de  décomposition des relations"
            ],
            "PREREQUIS": [
                "UEinfo2.7"
            ],
            "CM": 12,
            "TD": 18,
            "TP": 20,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 8,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo3.5",
            "TITRE": "PROGRAMMATION ET LANGAGE C",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Syntaxe : structures de contrôle, opérateurs et expressions",
                "Types, tableaux et pointeurs, passage de paramètres",
                "Gestion de la mémoire, programmation dynamique et algorithmes génériques",
                "Compilation séparée : pré-processeur, visibilité, édition de liens et atelier de compilation",
                "Librairie standard"
            ],
            "PREREQUIS": [
                "UEinfo2.5"
            ],
            "CM": 18,
            "TD": 22,
            "TP": 10,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 8,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo3.6",
            "TITRE": "ARCHITECTURE DES ORDINATEURS / LANGAGE D'ASSEMBLAGE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Compléments d'architecture: les bus du microprocesseur, la mémoire vue du microprocesseur, les registres du microprocesseur",
                "Langage d'assemblage : les modes d'adressage, écriture d'une ligne de programme, présentation du jeu d'instructions, écriture de programmes (exécution conditionnée, simulation de boucles, les sous-programmes, notion de variables, les appels systèmes)",
                "Réalisation d'un petit projet"
            ],
            "PREREQUIS": [
                "UEinfo2.6"
            ],
            "CM": 12,
            "TD": 18,
            "TP": 20,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 8,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo3.7",
            "TITRE": "PROGRAMMATION FONCTIONNELLE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Fonctions, fonctions récursives, composition de fonctions",
                "Type, inférence de type",
                "Types construits : types récursifs, types paramétrés",
                "Filtrage, gardes",
                "Portée des expressions",
                "Structures de données : exemple liste, arbres",
                "Gestion des exceptions",
                "Polymorphisme",
                "Applications en CAML"
            ],
            "PREREQUIS": [
                "UEinfo2.5"
            ],
            "CM": 18,
            "TD": 22,
            "TP": 10,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 8,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo3.8",
            "TITRE": "BASES DE GESTION, ORGANISATION DE L'ENTREPRISE ET FONCTION COMMERCIALE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Organisation et système d'information : environnement économique de l'entreprise, théorie des organisations, fonctionnement opérationnel des entreprise (programmation et stratégie), l'information dans l'organisation,aspects technologiques des Systèmes d'Information, les applications fonctionnelles, classification des Systèmes d'Information",
                "Systèmes interactifs classiques",
                "Systèmes de pilotage des organisations, tableau de bord, entrepôt de données",
                "Les outils de simulation, enquêtes, solveur, systèmes experts",
                "Système d'information commercial",
                "Système d'Information monétique",
                "Système d’Information e-Commerce"
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEphys3",
            "TITRE": "ELECTRONIQUE 1",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Réseaux linéaires, signaux sinusoïdaux, filtres, quadripôles, étude énergétique",
                "Diodes, transistors, amplificateur opérationnel, transistors à effet de champ, bruit parasite, immunisation"
            ],
            "PREREQUIS": [],
            "CM": 18,
            "TD": 20,
            "TP": 12,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 2,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEbio3.1",
            "TITRE": "BIOLOGIE DE LA CELLULE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Module du S1 SVT",
                "Constituants cellulaires, organisation du noyau, cycle cellulaire"
            ],
            "PREREQUIS": [],
            "CM": 18,
            "TD": 8,
            "TP": 14,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 2,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEbio3.2",
            "TITRE": "ORGANISATION DE L'ETRE HUMAIN ET DE SON ANATOMIE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Module du S1 SVT",
                "Anatomie, besoins vitaux"
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.1",
            "TITRE": "LANGUE S4",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Anglais"
            ],
            "PREREQUIS": [
                "UEinfo3.1"
            ],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.2",
            "TITRE": "UE LIBRE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "A choisir parmi les UE Libres proposées par l'université"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.3",
            "TITRE": "ALGORITHMIQUE DES GRAPHES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Définition de base et modélisation des problèmes à l’aide des graphes",
                "Différents implémentation d’un graphe et conséquences du point de vue de la complexité",
                "Parcours d’un graphe, composantes connexes, cycles",
                "Blocs et points d’articulation",
                "Composantes fortement connexes",
                "Graphes sans circuits,  problèmes d’ordonnancement, optimisation du code",
                "Couplage maximum et problèmes d’affectation des tâches",
                "Arbre couvrant de coût minimum,  réalisation d’un réseau connexe à coût minimum",
                "Algorithmes classiques de recherche du plus court chemin dans un graphe",
                "Introduction aux problèmes de flot"
            ],
            "PREREQUIS": [
                "UEinfo3.3"
            ],
            "CM": 20,
            "TD": 22,
            "TP": 8,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 8,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.4",
            "TITRE": "PROGRAMMATION OBJET 1",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Notion d'objet et de classe, méthodes, constructeurs",
                "Encapsulation, visibilité",
                "Héritage",
                "Polymorphisme",
                "Abstraction : méthodes abstraites, classes abstraites, interfaces",
                "Packages"
            ],
            "PREREQUIS": [
                "UEinfo3.3"
            ],
            "CM": 14,
            "TD": 20,
            "TP": 16,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 8,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.5",
            "TITRE": "RESEAU",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Transmission de l’information : éléments de traitement du signal, transmission d’un signal sur un support, le circuit des données, les supports de communication",
                "Détection et correction des erreurs",
                "Les multiplexeurs",
                "Protocole du niveau Liaison (et sa simulation) : contrôle de flux, fenêtre de transmission, LAP-B (DHLC) contrôle et technique d’accès au  support ( MAC), procédures de communication",
                "Réseaux grandes distances et commutation : commutation, circuit virtuel, datagramme, algorithmes de routage (Dijstra, Ford Fulkerson), inondation, « hot patatoes», contrôle de congestion : mécanismes préventifs et réactifs",
                "Communication sous UNIX (sockets)",
                "Simulation du routeur CISCO"
            ],
            "PREREQUIS": [
                "UEinfo3.5",
                "UEinfo3.2"
            ],
            "CM": 18,
            "TD": 18,
            "TP": 14,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 8,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.6",
            "TITRE": "PROGRAMMATION WEB",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Fonctionnement d’une architecture client/serveur de contenu Web : Protocole HTTP, langage PHP, traitement de formulaires, sessions, upload, interfaçage avec une base de données",
                "XML :   document, DTD, DOM, parsing SAX, localisation XPATH, transformation XSLT"
            ],
            "PREREQUIS": [
                "UEinfo3.3",
                "UEinfo3.4"
            ],
            "CM": 16,
            "TD": 18,
            "TP": 16,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.7",
            "TITRE": "ALGORITHMIQUE AVANCEE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Compléments sur les arbres : AVL, B-arbres (Arbres 2-3-4)",
                "Problèmes de flot",
                "Algorithmique du texte (dont code de Huffman, …)",
                "Preuves et complexités d’algorithmes"
            ],
            "PREREQUIS": [],
            "CM": 18,
            "TD": 22,
            "TP": 10,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.8",
            "TITRE": "SYSTEME D'INFORMATION COMPTABLE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Les opérations courantes et d’inventaire",
                "Approfondissement de certaines notions (le fait générateur, les événements postérieurs à la clôture, …)",
                "Comptabilisation des opérations d’affacturage",
                "Influence des transferts de charges sur le résultat et les SIG",
                "Création d’une société",
                "Variations de capital",
                "Catégories d’actions",
                "OBSA",
                "Obligations convertibles",
                "Affectations du résultat"
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEphys4",
            "TITRE": "SIGNAUX ET SYSTEMES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Transformée de Laplace – Transformée en Z (Propriétés, Théorèmes valeurs initiales et finales,..)",
                "Systèmes linéaires (Réponse indicielle, impulsionnelle, harmonique, opérations sur schéma bloc)",
                "Stabilité des systèmes linéaires",
                "Représentation des lieux de transfert (Lieux de Bode/Nyquist/Black)",
                "Performances des systèmes asservis",
                "Critère algébrique de stabilité (Routh)",
                "Critères géométriques : Plan de Nyquist, Plan de Black, Pan de Bode",
                "Précision, Rapidité, Marge de phase, Marge de gain",
                "Système de premier ordre/ deuxième ordre",
                "Analyse dans l’espace d’état (notion d’état, lien fonction de transfert-espace d’état, stabilité)"
            ],
            "PREREQUIS": [],
            "CM": 18,
            "TD": 20,
            "TP": 12,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 2,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEbio4.1",
            "TITRE": "GENETIQUE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "",
                    "CHOIX": [
                        [
                            1,
                            [
                                "UEbio4.1",
                                "UEbio4.2"
                            ]
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Module du S2 SVT",
                "Bases fondamentales en génétique"
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEbio4.2",
            "TITRE": "FONCTIONNEMENT DE LA CELLULE EUCARYOTE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "",
                    "CHOIX": [
                        [
                            1,
                            [
                                "UEbio4.1",
                                "UEbio4.2"
                            ]
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Module du S2 SVT",
                "Membrane plasmique, Dynamique du système endomembranaire, Mitochondries et péroxysomes, Relations des cellules avec leur environnement."
            ],
            "PREREQUIS": [],
            "CM": 24,
            "TD": 14,
            "TP": 12,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 2,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.1",
            "TITRE": "LANGUE S5",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Anglais"
            ],
            "PREREQUIS": [
                "UEinfo4.1"
            ],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.2",
            "TITRE": "SENSIBILISATION AU MONDE DU TRAVAIL",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Veille juridique, acteurs du monde du travail, les normes. Entretiens"
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.3",
            "TITRE": "THEORIE DES SYSTEMES D'EXPLOITATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Mémoire : segmentation, pagination, mémoire virtuelle",
                "Ressources : définition, classes de ressources",
                "Allocation de ressources déterminisme et inter-blocage : conditions de Berstein, algorithmes du banquier",
                "Système multi-threadés",
                "Installation et configuration d'un (ou plusieurs) SE"
            ],
            "PREREQUIS": [
                "UEinfo3.2"
            ],
            "CM": 18,
            "TD": 20,
            "TP": 12,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.4",
            "TITRE": "LANGAGES FORMELS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Notions de base (mots, langages, ...)",
                "Langages reconnaissables, automates finis",
                "Langages et expressions rationnelles (liens avec les outils de recherche utilisant des expressions régulières)",
                "Théorème de Kleene, algorithmes de passage d’un automate à une expression rationnelle et réciproquement Langage reconnu par un automate (algorithme de Mac Naughton et Yamada)",
                "Propriétés de fermeture rationnelles",
                "Déterminisme",
                "Propriétés de fermeture non rationnelles",
                "Minimalité",
                "Langages non reconnaissables, théorème de l'étoile",
                "Notions de grammaires et de langages algébriques"
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.5",
            "TITRE": "CALCUL SCIENTIFIQUE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Introduction au calcul matriciel (opérations élémentaires, règles de calcul)",
                "Permutation, déterminant, interprétation géométrique",
                "Résolution de systèmes d’équations linéaires, équation paramétrique, méthode de Gauss et propriétés",
                "Opérations sur les systèmes/matrices : méthode de Gauss-Jordan, équivalence par lignes, décomposition LU, caractérisation",
                "Produit matriciel  par blocs et illustration numérique",
                "Espaces vectoriels, sous-espaces vectoriels, exemples, espace vectoriel des matrices et polynômes",
                "Indépendance linéaire, bases et dimension, exemples"
            ],
            "PREREQUIS": [
                "UEinfo3.5"
            ],
            "CM": 20,
            "TD": 22,
            "TP": 8,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.6",
            "TITRE": "DE L'ARCHITECTURE A LA PROGRAMMATION DES BASES DE DONNEES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Intégrité des données : gestion des transactions, contrôle de la concurrence d'accès, reprise après panne",
                "Stockage des données : les disques, les fichiers et les différentes organisations",
                "Techniques d'indexation : Implantation des structures d'indexation, structures, arborescentes et hachages",
                "Normalisation",
                "Évaluation des requêtes, coût d'accès et de plan d'exécution, techniques d'optimisation"
            ],
            "PREREQUIS": [
                "UEinfo2.5",
                "UEinfo2.6",
                "UEinfo3.2"
            ],
            "CM": 16,
            "TD": 18,
            "TP": 16,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.7",
            "TITRE": "PROGRAMMATION OBJET 2",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Généricité en Java",
                "Programmation événementielle et interfaces graphiques",
                "Design Pattern : Observer--Observable, MVC",
                "Bean",
                "IDE",
                "Programmation dans des environnements multi-threads",
                "JNI : interface avec des applications écrites dans d'autres langages"
            ],
            "PREREQUIS": [
                "UEinfo4.4"
            ],
            "CM": 16,
            "TD": 18,
            "TP": 16,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.8",
            "TITRE": "METHODES FORMELLES D'AIDE A LA DETECTION D'ERREUR",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Dans ce module seront étudier des méthodes permettant de démontrer : la terminaison d’un programme, la validité du résultat calculé par un programme, l’efficacité en temps et en espace d’un programme",
                "Pour mener à bien ces investigations nous nous appuierons sur : la logique des propositions, la logique des prédicats, la notion d’invariant, les propriétés intrinsèquement liées à la sémantique des instructions des programmes"
            ],
            "PREREQUIS": [
                "UEinfo2.8"
            ],
            "CM": 26,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.10",
            "TITRE": "MATHEMATIQUES FINANCIERES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Le calcul financier en intérêt simple.",
                "L'intérêt composé et la capitalisation mixte",
                "Les emprunts indivis",
                "Les obligations",
                "Les taux effectifs",
                "Les bases de l'évaluation des investissements"
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.9",
            "TITRE": "SYSTEME D'INFORMATION FINANCIER",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Retraitement du bilan",
                "Analyse de l’entreprise à partir des SIG",
                "Tableaux des  flux de trésorerie",
                "Interprétation des résultats",
                "Marchés financiers"
            ],
            "PREREQUIS": [
                "UEinfo4.8"
            ],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEphys5",
            "TITRE": "AUTOMATIQUE CONTINUE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Représentation des systèmes linéaires continus",
                "Analyse temporelle et fréquentielle des systèmes du 1er et 2ème ordre",
                "Correcteurs à action continue (PID, avance et retard de phase)",
                "Analyse de la stabilité des systèmes asservis continus : critères algébriques, critères géométriques",
                "Précision des systèmes asservis linéaires continus",
                "Synthèse des correcteurs à action continue Méthodes de Ziegler et Nichols, critère de Naslin, prédicteur de Smith",
                "Lieu des racines et méthode de compensation",
                "Identification en boucle ouverte et en boucle fermée (Streijc, Broida ...)"
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 18,
            "TP": 12,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 2,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEbio5.1",
            "TITRE": "COMMUNICATION ET SIGNALISATION CELLULAIRE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Module du S3 SVT",
                "Voies de communication, récepteurs membranaires, échanges membranaires"
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 14,
            "TP": 12,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 1,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.1",
            "TITRE": "LANGUE S6",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Anglais"
            ],
            "PREREQUIS": [
                "UEinfo5.1"
            ],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.2",
            "TITRE": "UE LIBRE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "A choisir parmi les UE Libres proposées par l'université"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.3",
            "TITRE": "PROJET",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Analyse du problème",
                "Cahier des charges",
                "Réflexion algorithmique",
                "Choix d’implantation, puis implantation",
                "Tests",
                "Documentation d’un codage",
                "Rédaction d’un rapport",
                "Présentation orale du projet"
            ],
            "PREREQUIS": [],
            "CM": 2,
            "TD": 8,
            "TP": 40,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.4",
            "TITRE": "MODELISATION OBJET",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Introduction (historique de UML, faire le lien avec Merise)",
                "Systèmes",
                "Deux visions sur un système informatique (logiciel) : un système vu comme  un ensemble des fonctions, un système vu comme un ensemble d’objets en interaction",
                "Deux approches de développement : approche fonctionnelle, approche objet",
                "Cycle de vie du logiciel : spécification, analyse, conception, codage, test",
                "Approche objet soutenue par UML",
                "Aspect statique : le diagramme de cas d'utilisation, le diagramme d'objets, le diagramme de classes, le diagramme de déploiement",
                "Aspect dynamique : le diagramme de séquences, le diagramme de collaboration, et le diagramme d'états"
            ],
            "PREREQUIS": [
                "UEinfo4.4",
                "UEinfo5.6"
            ],
            "CM": 16,
            "TD": 18,
            "TP": 16,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.5",
            "TITRE": "INTELLIGENCE ARTIFICIELLE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Algorithmes classiques d'I. A. dans le domaine de la résolution de problèmes",
                "Problèmes avec changement d'état (algorithmes gradient, backtrack, A*)",
                "Problèmes décomposables (algorithme AO*)",
                "Jeux de stratégie (algorithmes minmax , SSS*, Scout)"
            ],
            "PREREQUIS": [
                "UEinfo4.3"
            ],
            "CM": 18,
            "TD": 24,
            "TP": 8,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.6",
            "TITRE": "PROGRAMMATION DES SYSTEMES D'INFORMATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Processus lourds : clonage, synchronisation et signaux système",
                "Descripteurs de flux : redirection des Entrées/Sorties, tube système et tube nommés",
                "Outils orientés système : gestion de projet sous UNIX, compilation arborescente, versionning",
                "Synchronisation"
            ],
            "PREREQUIS": [
                "UEinfo3.5",
                "UEinfo3.2"
            ],
            "CM": 12,
            "TD": 14,
            "TP": 24,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.7",
            "TITRE": "METHODES QUANTITAVES ET AIDE A LA DECISION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Problématique et outils fondamentaux des modèles quantitatifs et aide à la décision",
                "Présentation des algorithmes/méthodes génériques et les limites de ces derniers face à des modèles robustes",
                "Notions sur les modèles quantitatifs et interprétation géométrique et décision",
                "Algorithmes de résolution : étude d'un cas, l'algorithme primal du simplexe, initialisation et finitude de l'algorithme du simplexe, convergence, dualité, notion d’équivalence",
                "Programmation dynamique discrète : étude du problème de l'allocation de ressources, le cas du transport"
            ],
            "PREREQUIS": [
                "UEinfo5.5"
            ],
            "CM": 20,
            "TD": 24,
            "TP": 6,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.8",
            "TITRE": "COMPILATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Analyse lexicale, Lex, analyse syntaxique, analyseur LL, analyseur LR, grammaire LR, SLR, présentation de Yacc, traduction dirigée par la syntaxe, environnement d'exécution, production du code intermédiaire, production du code, optimisation du code",
                "Réalisation d'un mini-compilateur à l'aide de Lex et Yacc"
            ],
            "PREREQUIS": [
                "UEinfo3.5",
                "UEinfo5.4"
            ],
            "CM": 20,
            "TD": 24,
            "TP": 6,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.9",
            "TITRE": "SYSTEME D'INFORMATION POUR LA GESTION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Présentation de la comptabilité de gestion (domaine, modélisation par les coûts)",
                "Approche stratégique",
                "Les coûts complets",
                "Les coûts instruments de simulation économique",
                "Les coûts dans un environnement international",
                "De la mesure à la maîtrise des coûts",
                "Principe de base de la gestion de production",
                "Problématique de la gestion de production (objectifs, contraintes, choix technologiques, etc.)",
                "Outils spécifiques (codification, nomenclature, etc.)",
                "Planification de la production (MRP, Kanban, gestion des stocks, flux tendus, etc)"
            ],
            "PREREQUIS": [
                "UEinfo5.9"
            ],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.10",
            "TITRE": "STAGE EN ENTREPRISE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Stage d’au moins 8 semaines (avec comptes-rendus réguliers, rapport de stage, soutenance orale)"
            ],
            "PREREQUIS": [
                "UEinfo5.9"
            ],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEphys6.1",
            "TITRE": "MECANIQUE EN REFERENTIEL GALILEEN",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Composition de mouvements",
                "Dynamique du point matériel",
                "Lois de conservation",
                "Systèmes à deux corps",
                "Chocs et diffusion"
            ],
            "PREREQUIS": [],
            "CM": 22,
            "TD": 22,
            "TP": 6,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 2,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEphys6.2",
            "TITRE": "TRAITEMENT DU SIGNAL",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Introduction au TS (classification des signaux déterministes…)",
                "Filtrage des signaux ( analyse fréquentielle..)",
                "Transmission analogique du signal",
                "Introduction aux techniques de modulation",
                "Modulation linéaire: les modulations d'amplitude",
                "Modulation d'amplitude à porteuse supprimée (MAPS)",
                "Modulation d'amplitude à porteuse conservée (MAPC ou AM)",
                "Modulation d'amplitude à bande latérale unique (BLU)",
                "Modulation angulaire: modulation de fréquence",
                "Structure et performances des principaux démodulateurs",
                "Démodulateur synchrone",
                "Démodulateur d'enveloppe Démodulateur de fréquence"
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 18,
            "TP": 12,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 1,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEbio6",
            "TITRE": "NEUROANATOMIE FONCTIONNELLE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Module du S4 SVT",
                "Structures et organisation des circuits dans le système nerveux."
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 18,
            "TP": 12,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 1,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        }
    ]
})