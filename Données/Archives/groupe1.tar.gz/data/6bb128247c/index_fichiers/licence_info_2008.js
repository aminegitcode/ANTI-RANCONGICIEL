addMaquette({
    "FORMATION": {
        "NOM": "Licence Informatique 2008",
        "ETABLISSEMENT": "Université de Picardie - Jules Verne",
        "ANNEES": "2008/12",
        "NB_SEMESTRES": 6,
        "LMD": "L",
        "PARCOURS": [
            {
                "ID": "PAR_1",
                "NOM": "parcours INFO",
                "DESCRIPTION": "",
                "ANNEES": [
                    1,
                    2,
                    3
                ]
            },
            {
                "ID": "PAR_2",
                "NOM": "parcours MIAGE",
                "DESCRIPTION": "Méthodes Informatiques Appliquées à la Gestion des Entreprises",
                "ANNEES": [
                    1,
                    2,
                    3
                ]
            },
            {
                "ID": "PAR_3",
                "NOM": "parcours MATH",
                "DESCRIPTION": "",
                "ANNEES": [
                    1,
                    2,
                    3
                ]
            }
        ],
        "BLOCS": [],
        "RESPONSABLES": [],
        "M3C": [],
        "PRESENTATION": []
    },
    "MODULES": [
        {
            "SEMESTRE": 1,
            "ID": "UEinfo1.1",
            "TITRE": "LANGUE S1",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Anglais"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UEinfo1.2",
            "TITRE": "C2I",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "C2i"
            ],
            "PREREQUIS": [],
            "CM": 14,
            "TD": 16,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UE1.01",
            "TITRE": "MATHEMATIQUES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "",
                    "CHOIX": [
                        5,
                        [
                            "UE1.01",
                            "UE1.02",
                            "UE1.03",
                            "UE1.04",
                            "UE1.05",
                            "UE1.06"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 24,
            "TP": 4,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UE1.02",
            "TITRE": "INTRODUCTION A L'INFORMATIQUE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "",
                    "CHOIX": [
                        5,
                        [
                            "UE1.01",
                            "UE1.02",
                            "UE1.03",
                            "UE1.04",
                            "UE1.05",
                            "UE1.06"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Algorithmique : notion de problème (données, résultats) et d'algorithmes pour le résoudre, programmes, sous-programmes (paramètres), instructions, instructions conditionnelles, instructions répétitives (boucle avec ou sans compteur), indentation, variables, types (entier, réel, chaîne, booléen), expressions, affectations, éléments de logique, structure de données (tableau à une dimension)",
                "En cours, On s’attachera à donner des exemples informatifs permettant d'illustrer des domaines de l'informatique parmi : sciences informatiques vs bureautique, histoire de l'informatique, analyse et résolution de problème, complexité et preuves de programmes, problèmes indécidables et non réalisables en temps raisonnable, langages de programmation (langages objets, langages fonctionnels, langages logiques...)",
                "Architecture de l'ordinateur, systèmes d'exploitations, réseaux, modélisation et modèles, compilation, ...",
                "En TPs, Machines et logiciels : connaissances d'utilisation de la machine (architecture, unité centrale, unité de commande, ALU, périphériques, écran, clavier, souris, disque dur...), connaissances de bases d'un système de fichiers (répertoires ou dossiers, fichiers, création, déplacement, copier-coller...) manipulations de bases de logiciels (éditeur ou traitement de texte, navigateur Internet...)",
                "En TPs, Programmation en langage JAVA (compilation, exécution, débogage)"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 22,
            "TP": 8,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UE1.03",
            "TITRE": "PHYSIQUE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "",
                    "CHOIX": [
                        5,
                        [
                            "UE1.01",
                            "UE1.02",
                            "UE1.03",
                            "UE1.04",
                            "UE1.05",
                            "UE1.06"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 14,
            "TD": 20,
            "TP": 6,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UE1.04",
            "TITRE": "CHIMIE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "",
                    "CHOIX": [
                        5,
                        [
                            "UE1.01",
                            "UE1.02",
                            "UE1.03",
                            "UE1.04",
                            "UE1.05",
                            "UE1.06"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 18,
            "TD": 16,
            "TP": 6,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UE1.05",
            "TITRE": "BIOLOGIE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "",
                    "CHOIX": [
                        5,
                        [
                            "UE1.01",
                            "UE1.02",
                            "UE1.03",
                            "UE1.04",
                            "UE1.05",
                            "UE1.06"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 18,
            "TD": 16,
            "TP": 6,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UE1.06",
            "TITRE": "EEA",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "",
                    "CHOIX": [
                        5,
                        [
                            "UE1.01",
                            "UE1.02",
                            "UE1.03",
                            "UE1.04",
                            "UE1.05",
                            "UE1.06"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UEinfo1.8",
            "TITRE": "INTERNET ET PROGRAMMATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Généralités sur Internet : interconnexion de réseaux, TCP/IP, adresse IP, nom de domaines, protocole, URL, le W3C (ping), moteurs de recherche, référencement de site",
                "Communication client/serveur, les protocoles HTTP et HTTPS",
                "HTML : les tags, l'interprétation par les navigateurs (écriture de page), les éditeurs, validateurs de HTML, XHTML",
                "CSS : style et feuille de style  (écrire du CSS dans des pages HTML)"
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 28,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UEinfo1.9",
            "TITRE": "ENSEMBLES ET LOGIQUE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Introduction à la notion d’ensemble : définition par extension, par compréhension, opération ensemblistes, diagramme de Venn",
                "Initiation à la logique : notations, tables de vérité, implication, équivalence, propositions, prédicats, lien avec la mise en oeuvre d’expressions booléennes, lien avec les ensembles",
                "Présentation des raisonnements par l'absurde, par récurrence, ...",
                "Initiation à la résolution d'équations de récurrence, suites arithmétiques, géométriques, application à l’évaluation du coût en temps d’une instruction répétitive simple",
                "Les liens avec la mise en œuvre d’algorithme ou de programme seront présentées dès que possible : valeur d’expressions booléennes, conception de programme itératifs"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.1",
            "TITRE": "LANGUE S2",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Anglais"
            ],
            "PREREQUIS": [
                "UEinfo1.1"
            ],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.2",
            "TITRE": "UE LIBRE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "A choisir parmi les UE Libres proposées par l'université"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.5",
            "TITRE": "ALGORITHMIQUE ET PROGRAMMATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Structures de données à accès direct (tableaux à une ou plusieurs dimensions) ou non (chaîne de caractères)",
                "Implémentation des tableaux dans les langages de programmation : notion de référence, passages de paramètres par valeurs versus par références",
                "Algorithmes classiques : recherche (linéaire, dichotomique), tris (par insertion, sélection, rapide), manipulations de matrices, algorithmes sur les chaînes",
                "Introduction de la notion d’ordre de grandeur de fonctions, analyse en complexité",
                "Récursivité",
                "TPs en JAVA : vérification pratique des complexités, notions de benchmark"
            ],
            "PREREQUIS": [
                "UE1.02"
            ],
            "CM": 18,
            "TD": 22,
            "TP": 10,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.6",
            "TITRE": "ARCHITECTURE DES ORDINATEURS / REPRESENTATION DE L'INFORMATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Algèbre de Boole, loi de Morgan, théorème de Shannon",
                "Les portes logiques (NOT, AND, OR, XOR, NOR, NAND)",
                "Les circuits intégrés (du transistor à la porte NOR...)",
                "Quelques circuits de bases : circuits combinatoires (décodeurs, multiplexeur, additionneur,...), circuits séquentiels (bascules, registres, compteur,...)",
                "Architecture de Van Neumann : exemple d'architecture d'un microprocesseur, exemple d'architecture d'une machine",
                "Rappel de Numération : les différentes bases utilisées en Informatique, algorithmes de conversion",
                "Représentation d'informations : les chiffres, caractères (code DCB, ISO6, EBCDIC, ASCII, UNICODE), les entiers, entiers signés, les fractionnaires en virgule fixe (signé ou non), les fractionnaires en virgule flottante",
                "Opérations sur les nombres (entiers et réels) : rappel des algorithmes opératoires, identification de la véracité des résultats"
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.8",
            "TITRE": "OUTILS POUR L'INFORMATIQUE I",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Invariants pour conception et preuves de programmes",
                "Logique des propositions et des prédicats",
                "Raisonnements (par l'absurde, par récurrence, ...)",
                "Résolution d'équations de récurrence et de sommations simples",
                "Analyse en complexité des algorithmes",
                "Ordre de grandeur des fonctions"
            ],
            "PREREQUIS": [],
            "CM": 22,
            "TD": 28,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": "2",
            "ID": "UE2.3",
            "TITRE": "ANALYSE ET ETUDE DE CAS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Présentation rapide du cycle de développement d'un logiciel : expressions des besoins, étude préliminaire, conception détaillée, implantation, intégration, essais, maintenance",
                "Études de modèles de données de la méthode Merise : Modèle Conceptuel des données, Modèle organisationnel des données",
                "La structuration d'un logiciel pour la programmation structurée : notion d'interface et d'implémentation, utilisation de procédures et de fonctions, commentaires",
                "L'analyse descendante : études de cas, analyse de problèmes récursifs"
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 35,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.9",
            "TITRE": "LANGAGES FORMELS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Notions de base (mots, langages, ...)",
                "Langages reconnaissables, automates finis",
                "Langages et expressions rationnelles (liens avec les outils de recherche utilisant des expressions régulières)",
                "Théorème de Kleene, algorithmes de passage d’un automate à une expression rationnelle et réciproquement Langage reconnu par un automate (algorithme de Mac Naughton et Yamada)",
                "Propriétés de fermeture rationnelles",
                "Déterminisme",
                "Propriétés de fermeture non rationnelles",
                "Minimalité",
                "Langages non reconnaissables, théorème de l'étoile",
                "Notions de grammaires et de langages algébriques"
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": "2",
            "ID": "UE2.4",
            "TITRE": "SYSTEME D'INFORMATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Environnement économique de l’entreprise",
                "Théorie des organisations",
                "Fonctionnement opérationnel des entreprises (programmation et stratégie)",
                "L'information dans l’organisation",
                "Aspects technologiques des Systèmes d’Information",
                "Les applications fonctionnelles, classification des Systèmes d’Information"
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.10",
            "TITRE": "ANALYSE REELLE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 7,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 30,
            "TD": 47,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.11",
            "TITRE": "COURBES PARAMETREES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 20,
            "TP": 6,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo3.1",
            "TITRE": "LANGUE S3",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Anglais"
            ],
            "PREREQUIS": [
                "UEinfo2.1"
            ],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo3.2",
            "TITRE": "PROJET PROFESSIONNEL PERSONNALISE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Techniques de recherche d’emploi : techniques d'entretien, rédaction d'un C.V.",
                "Veille technologique : étude de la presse informatique, techniques d’exposés",
                "Définition d’un projet professionnel personnalisé"
            ],
            "PREREQUIS": [
                "UEinfo1.7"
            ],
            "CM": 8,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo3.3",
            "TITRE": "STRUCTURES DE DONNEES LINEAIRES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Programmation récursive",
                "Structures de données linéaires (Liste, Pile, File)",
                "Algorithmiques de ces structures (parcours, insertion, suppression, recherche, ...)",
                "Implémentations usuelles : à l’aide de tableaux, à l’aide de structure chaînées, notion de pointeur",
                "Comparaisons des implémentations (notamment du point de vue des complexités en temps et en espace)",
                "Analyse en complexité et preuve de fonctionnement des objets étudiés"
            ],
            "PREREQUIS": [
                "UEinfo2.5"
            ],
            "CM": 18,
            "TD": 24,
            "TP": 8,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo3.4",
            "TITRE": "INTRODUCTION AUX BASES DE DONNEES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Introduction aux SGBD : bref historique, objectifs, avantages et inconvénients des SGBD",
                "Bref rappel de la démarche de conception d'un SI du point de vue des données : le modèle Entité/Association (E/A) et son utilisation dans une démarche analytique",
                "Le modèle relationnel (relations et clés)",
                "Les règles de transformation du modèle E/A vers le modèle relationnel",
                "Introduction au langage SQL : ordres de création d'un schéma relationnel, de manipulations et de consultation des données à l’aide d’une ou plusieurs tables (jointure), mise en œuvre de requêtes plus complexes à l’aide des fonctions agrégatives"
            ],
            "PREREQUIS": [
                "UEinfo2.5"
            ],
            "CM": 16,
            "TD": 18,
            "TP": 16,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo3.5",
            "TITRE": "OUTILS POUR L'INFORMATIQUE II",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Groupes symétriques : représentation des entiers bornés, utilisation du modulo",
                "Relations : ordre, équivalence, … ; utilisation pour la portabilité des algorithmes de tris et pour les algorithmes d’«union-find »",
                "Preuves et complexités d’algorithmes récursifs : méthode de récurrence, fonctions génératrices, séries formelles et rationnelles"
            ],
            "PREREQUIS": [
                "UEinfo2.5",
                "UEinfo2.8"
            ],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo3.6",
            "TITRE": "ARCHITECTURE DES ORDINATEURS / LANGAGE D'ASSEMBLAGE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Compléments d'architecture: les bus du microprocesseur, la mémoire vue du microprocesseur, les registres du microprocesseur",
                "Langage d'assemblage : les modes d'adressage, écriture d'une ligne de programme, présentation du jeu d'instructions, écriture de programmes (exécution conditionnée, simulation de boucles, les sous-programmes, notion de variables, les appels systèmes)",
                "Réalisation d'un petit projet"
            ],
            "PREREQUIS": [
                "UEinfo2.6"
            ],
            "CM": 12,
            "TD": 18,
            "TP": 20,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo3.7",
            "TITRE": "PROGRAMMATION FONCTIONNELLE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Fonctions, fonctions récursives, composition de fonctions",
                "Type, inférence de type",
                "Types construits : types récursifs, types paramétrés",
                "Filtrage, gardes",
                "Portée des expressions",
                "Structures de données : exemple liste, arbres",
                "Gestion des exceptions",
                "Polymorphisme",
                "Applications en CAML"
            ],
            "PREREQUIS": [
                "UEinfo2.5"
            ],
            "CM": 18,
            "TD": 22,
            "TP": 10,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo3.8",
            "TITRE": "SYSTEME D'INFORMATION COMMERCIALE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Organisation et système d'information : environnement économique de l'entreprise, théorie des organisations, fonctionnement opérationnel des entreprise (programmation et stratégie), l'information dans l'organisation,aspects technologiques des Systèmes d'Information, les applications fonctionnelles, classification des Systèmes d'Information",
                "Systèmes interactifs classiques",
                "Systèmes de pilotage des organisations, tableau de bord, entrepôt de données",
                "Les outils de simulation, enquêtes, solveur, systèmes experts",
                "Système d'information commercial",
                "Système d'Information monétique",
                "Système d’Information e-Commerce"
            ],
            "PREREQUIS": [
                "UE2.4"
            ],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UE3.01",
            "TITRE": "STATISTIQUES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 32,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UE3.02",
            "TITRE": "TOPOLOGIE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 7,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 30,
            "TD": 47,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UE3.03",
            "TITRE": "ELEMENTS DE GEOMETRIE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.1",
            "TITRE": "LANGUE S4",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Anglais"
            ],
            "PREREQUIS": [
                "UEinfo3.1"
            ],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.2",
            "TITRE": "UE LIBRE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "A choisir parmi les UE Libres proposées par l'université"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.3",
            "TITRE": "STRUCTURES DE DONNEES ARBORESCENTES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Études des arbres comme structure de données : ABR, arbres équilibrés, AVL, B-arbres",
                "Comparaison avec la technique de hachage",
                "Applications : codage de Huffman, structures de dictionnaires",
                "Tas, utilisation pour la gestion d'ensemble, de partitions",
                "Analyse en complexité et preuve de fonctionnement des algorithmes présentés"
            ],
            "PREREQUIS": [
                "UEinfo3.3"
            ],
            "CM": 18,
            "TD": 24,
            "TP": 8,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.4",
            "TITRE": "PROGRAMMATION ET LANGAGE C",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Syntaxe : structures de contrôle, opérateurs et expressions",
                "Types, tableaux et pointeurs, passage de paramètres",
                "Gestion de la mémoire, programmation dynamique et algorithmes génériques",
                "Compilation séparée : pré-processeur, visibilité, édition de liens et atelier de compilation",
                "Librairie standard"
            ],
            "PREREQUIS": [
                "UEinfo3.3"
            ],
            "CM": 18,
            "TD": 22,
            "TP": 10,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.5",
            "TITRE": "SYSTEME D'EXPLOITATION I",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Principes et généralités",
                "Organisation de l'espace disque, systèmes de gestion de fichiers, droits d’accès",
                "Interface utilisateur",
                "Organisation de l'espace disque",
                "Processus : clonage, échange de messages, gestion des inter-blocages, synchronisation des processus",
                "Illustration sous UNIX : bash, programmation de processus en langage C"
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 18,
            "TP": 20,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.6",
            "TITRE": "MODELISATION ET PROGRAMMATION OBJET",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Analyse, conception et programmation objet",
                "Apprentissage des bases de JAVA : classe, Objet, Héritage, Interface, paquetages",
                "Utilisation d’UML"
            ],
            "PREREQUIS": [
                "UEinfo3.3"
            ],
            "CM": 14,
            "TD": 20,
            "TP": 16,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.7",
            "TITRE": "PROGRAMMATION WEB",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Fonctionnement d’une architecture client/serveur de contenu Web : Protocole HTTP, langage PHP, traitement de formulaires, sessions, upload, interfaçage avec une base de données",
                "XML : document, DTD, DOM, parsing SAX, localisation XPATH, transformation XSLT"
            ],
            "PREREQUIS": [
                "UEinfo3.3",
                "UEinfo3.4"
            ],
            "CM": 14,
            "TD": 18,
            "TP": 18,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.8",
            "TITRE": "GESTION DE STOCKS ET FILES D'ATTENTE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Présentation générale des problèmes de stocks (systèmes-stocks, fonction des stocks, politique de gestion des stocks)",
                "Modèles déterministes de la gestion des stocks (absence de rupture de stocks, ruptures de stocks avec demandes différées ou perdues, modèle avec rabais)",
                "Processus de Poisson, File d'attente de type M/M/1, formule de Little",
                "Introduction aux chaînes de Markov : processus de naissances et de mort, chaînes de Markov (M/M/1/C, M/M/k/C)"
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 24,
            "TP": 6,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.9",
            "TITRE": "SYSTEME D'INFORMATION COMPTABLE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Les opérations courantes et d’inventaire",
                "Approfondissement de certaines notions (le fait générateur, les événements postérieurs à la clôture, …)",
                "Comptabilisation des opérations d’affacturage",
                "Influence des transferts de charges sur le résultat et les SIG",
                "Création d’une société",
                "Variations de capital",
                "Catégories d’actions",
                "OBSA",
                "Obligations convertibles",
                "Affectations du résultat"
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UE4.01",
            "TITRE": "SUITES ET SERIES DE FONCTIONS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 7,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 30,
            "TD": 47,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UE4.02",
            "TITRE": "ENSEMBLES INFINIS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.1",
            "TITRE": "LANGUE S5",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Anglais"
            ],
            "PREREQUIS": [
                "UEinfo4.1"
            ],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.2",
            "TITRE": "UE LIBRE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "A choisir parmi les UE Libres proposées par l'université"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.3",
            "TITRE": "ALGORITHMIQUE DES GRAPHES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Définition de base et modélisation des problèmes à l’aide des graphes",
                "Différents implémentation d’un graphe et conséquences du point de vue de la complexité",
                "Parcours d’un graphe, composantes connexes, cycles",
                "Blocs et points d’articulation",
                "Composantes fortement connexes",
                "Graphes sans circuits,  problèmes d’ordonnancement, optimisation du code",
                "Couplage maximum et problèmes d’affectation des tâches",
                "Arbre couvrant de coût minimum,  réalisation d’un réseau connexe à coût minimum",
                "Algorithmes classiques de recherche du plus court chemin dans un graphe",
                "Introduction aux problèmes de flot"
            ],
            "PREREQUIS": [
                "UEinfo4.3"
            ],
            "CM": 20,
            "TD": 22,
            "TP": 8,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UE5.4",
            "TITRE": "SYSTÈMES D'EXPLOITATION II",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Mémoire : segmentation, pagination, mémoire virtuelle",
                "Ressources : définition, classes de ressources",
                "Allocation de ressources déterminisme et inter-blocage : conditions de Berstein, algorithmes du banquier",
                "Système multi-threadés",
                "Installation et configuration d'un (ou plusieurs) SE"
            ],
            "PREREQUIS": [
                "UEinfo4.5"
            ],
            "CM": 18,
            "TD": 20,
            "TP": 12,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.5",
            "TITRE": "CALCUL SCIENTIFIQUE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Introduction au calcul matriciel (opérations élémentaires, règles de calcul)",
                "Permutation, déterminant, interprétation géométrique",
                "Résolution de systèmes d’équations linéaires, équation paramétrique, méthode de Gauss et propriétés",
                "Opérations sur les systèmes/matrices : méthode de Gauss-Jordan, équivalence par lignes, décomposition LU, caractérisation",
                "Produit matriciel  par blocs et illustration numérique",
                "Espaces vectoriels, sous-espaces vectoriels, exemples, espace vectoriel des matrices et polynômes",
                "Indépendance linéaire, bases et dimension, exemples"
            ],
            "PREREQUIS": [
                "UEinfo4.4"
            ],
            "CM": 20,
            "TD": 22,
            "TP": 8,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.6",
            "TITRE": "ARCHITECTURE DES BASES DE DONNEES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Intégrité des données : gestion des transactions, contrôle de la concurrence d'accès, reprise après panne",
                "Stockage des données : les disques, les fichiers et les différentes organisations",
                "Techniques d'indexation : Implantation des structures d'indexation, structures, arborescentes et hachages",
                "Normalisation",
                "Évaluation des requêtes, coût d'accès et de plan d'exécution, techniques d'optimisation"
            ],
            "PREREQUIS": [
                "UEinfo3.4",
                "UEinfo3.3",
                "UEinfo4.3"
            ],
            "CM": 16,
            "TD": 18,
            "TP": 16,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.7",
            "TITRE": "PROGRAMMATION OBJET AVANCEE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Programmation événementielle",
                "Etude d’une API graphique",
                "Modèle Vue Contrôleur (design pattern)",
                "Thread, beans dans le cas d’une application graphique",
                "IDE"
            ],
            "PREREQUIS": [
                "UEinfo4.6"
            ],
            "CM": 16,
            "TD": 18,
            "TP": 16,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.8",
            "TITRE": "OUTILS DE DEVELOPPEMENT",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Expressions régulières",
                "Outils de bases GNU (grep, cut, sed, ...)",
                "Etude des traitements par lots",
                "Les langages Bourne shell et Perl",
                "Outils de gestion de projet",
                "Introduction à la problématique du développement multi-utilisateurs",
                "Software Versioning",
                "Gestion concurrente",
                "Illustration sous CVS et SubVersion (SVN)",
                "Interface utilisateur (ligne de commande et client graphique)",
                "Mise en place d'un projet SVN"
            ],
            "PREREQUIS": [
                "UEinfo4.4",
                "UEinfo4.5"
            ],
            "CM": 12,
            "TD": 12,
            "TP": 24,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.10",
            "TITRE": "MATHEMATIQUES FINANCIERES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Le calcul financier en intérêt simple.",
                "L'intérêt composé et la capitalisation mixte",
                "Les emprunts indivis",
                "Les obligations",
                "Les taux effectifs",
                "Les bases de l'évaluation des investissements"
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.9",
            "TITRE": "SYSTEME D'INFORMATION FINANCIER",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Retraitement du bilan",
                "Analyse de l’entreprise à partir des SIG",
                "Tableaux des  flux de trésorerie",
                "Interprétation des résultats",
                "Marchés financiers"
            ],
            "PREREQUIS": [
                "UEinfo4.8"
            ],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UE5.01",
            "TITRE": "EQUATIONS DIFFERENTIELLES ORDINAIRES I",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 32,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UE5.02",
            "TITRE": "FONCTIONS DE LA VARIABLE COMPLEXE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 32,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.1",
            "TITRE": "LANGUE S6",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Anglais"
            ],
            "PREREQUIS": [
                "UEinfo5.1"
            ],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.2",
            "TITRE": "CONNAISSANCE DE L'ENTREPRISE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Veille juridique, acteurs du monde du travail, les normes. Entretiens"
            ],
            "PREREQUIS": [],
            "CM": 7,
            "TD": 8,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.3",
            "TITRE": "PROJET",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Analyse du problème",
                "Cahier des charges",
                "Réflexion algorithmique",
                "Choix d’implantation, puis implantation",
                "Tests",
                "Documentation d’un codage",
                "Rédaction d’un rapport",
                "Présentation orale du projet"
            ],
            "PREREQUIS": [],
            "CM": 2,
            "TD": 8,
            "TP": 40,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.4",
            "TITRE": "RESEAU",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Transmission de l’information : éléments de traitement du signal, transmission d’un signal sur un support, le circuit des données, les supports de communication",
                "Détection et correction des erreurs",
                "Les multiplexeurs",
                "Protocole du niveau Liaison (et sa simulation) : contrôle de flux, fenêtre de transmission, LAP-B (DHLC) contrôle et technique d’accès au  support ( MAC), procédures de communication",
                "Réseaux grandes distances et commutation : commutation, circuit virtuel, datagramme, algorithmes de routage (Dijstra, Ford Fulkerson), inondation, « hot patatoes», contrôle de congestion : mécanismes préventifs et réactifs",
                "Communication sous UNIX (sockets)",
                "Simulation du routeur CISCO"
            ],
            "PREREQUIS": [
                "UEinfo4.4",
                "UEinfo4.5"
            ],
            "CM": 18,
            "TD": 18,
            "TP": 14,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.5",
            "TITRE": "OUTILS POUR L'INFORMATIQUE III",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Principes fondamentaux du dénombrement",
                "Ensembles énumérables, ensembles non énumérables",
                "Théorèmes de base sur les probabilités (événements incompatibles et probabilités totales, événements indépendants et probabilités composées, probabilités conditionnelles et théorème de Bayes); pratique sur des exemples",
                "Arithmétique p-adique : arithmétique sur Z/nZ, transformée de Fourier discrète sur les entiers, distances",
                "Chaque notion sera reliée et illustrée par des applications à la résolution de problèmes rencontrés en informatique : calcul de la borne inférieure de la complexité d’un algorithme, complexité en moyenne, terminaison d’algorithme"
            ],
            "PREREQUIS": [
                "UEinfo2.5"
            ],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.6",
            "TITRE": "INTELLIGENCE ARTIFICIELLE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Algorithmes classiques d'I. A. dans le domaine de la résolution de problèmes",
                "Problèmes avec changement d'état (algorithmes gradient, backtrack, A*)",
                "Problèmes décomposables (algorithme AO*)",
                "Jeux de stratégie (algorithmes minmax , SSS*, Scout)"
            ],
            "PREREQUIS": [
                "UEinfo4.3"
            ],
            "CM": 18,
            "TD": 24,
            "TP": 8,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.7",
            "TITRE": "PROGRAMMATION ET BASES DE DONNEES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Introduction à l'administration d'un SGBD",
                "Etude de langages de programmation intégrés : PL/SQL (Oracle) et TransacSQL (Sybase et Microsoft SQLServer)",
                "SQL3 et l'approche objet",
                "Interface de programmation : étude de JDBC et d'ODBC"
            ],
            "PREREQUIS": [
                "UEinfo5.6"
            ],
            "CM": 16,
            "TD": 18,
            "TP": 18,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.8",
            "TITRE": "METHODES QUANTITAVES ET DECISION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Problématique et outils fondamentaux des modèles quantitatifs et aide à la décision",
                "Présentation des algorithmes/méthodes génériques et les limites de ces derniers face à des modèles robustes",
                "Notions sur les modèles quantitatifs et interprétation géométrique et décision",
                "Algorithmes de résolution : étude d'un cas, l'algorithme primal du simplexe, initialisation et finitude de l'algorithme du simplexe, convergence, dualité, notion d’équivalence",
                "Programmation dynamique discrète : étude du problème de l'allocation de ressources, le cas du transport"
            ],
            "PREREQUIS": [
                "UEinfo5.5"
            ],
            "CM": 20,
            "TD": 24,
            "TP": 6,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.10",
            "TITRE": "SYSTEME D'INFORMATION POUR LA GESTION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Présentation de la comptabilité de gestion (domaine, modélisation par les coûts)",
                "Approche stratégique",
                "Les coûts complets",
                "Les coûts instruments de simulation économique",
                "Les coûts dans un environnement international",
                "De la mesure à la maîtrise des coûts",
                "Principe de base de la gestion de production",
                "Problématique de la gestion de production (objectifs, contraintes, choix technologiques, etc.)",
                "Outils spécifiques (codification, nomenclature, etc.)",
                "Planification de la production (MRP, Kanban, gestion des stocks, flux tendus, etc)"
            ],
            "PREREQUIS": [
                "UEinfo5.9"
            ],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.11",
            "TITRE": "STAGE EN ENTREPRISE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_1",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_2",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                },
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "optionnel",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [
                "Stage d’au moins 8 semaines (avec comptes-rendus réguliers, rapport de stage, soutenance orale)"
            ],
            "PREREQUIS": [
                "UEinfo5.9"
            ],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UE6.01",
            "TITRE": "PROBABILITES ELEMENTAIRES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 32,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UE6.02",
            "TITRE": "ANALYSE NUMERIQUE I",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "PAR_3",
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": ""
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 32,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        }
    ]
})