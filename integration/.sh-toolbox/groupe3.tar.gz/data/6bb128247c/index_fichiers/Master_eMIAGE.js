addMaquette({
    "FORMATION": {
        "NOM": "Master eMIAGE",
        "ETABLISSEMENT": "UNIVERSITE DE PICARDIE - JULES VERNE",
        "ANNEES": "2023/24",
        "NB_SEMESTRES": 4,
        "LMD": "M",
        "PARCOURS": [
            {
                "ID": "SIN",
                "NOM": "SIN",
                "DESCRIPTION": "Systèmes d'Information Nomades",
                "ANNEES": [
                    2
                ]
            }
        ],
        "BLOCS": [
            {
                "ID": "INFO",
                "NOM": "INFO",
                "DESCRIPTION": ""
            },
            {
                "ID": "ISI",
                "NOM": "ING SI",
                "DESCRIPTION": "ingénierie des systèmes d'information"
            },
            {
                "ID": "GEO",
                "NOM": "GEST ENTR",
                "DESCRIPTION": "gestion des entreprises"
            },
            {
                "ID": "TRANS",
                "NOM": "COMP TRANS",
                "DESCRIPTION": "transverses"
            },
            {
                "ID": "PRO",
                "NOM": "PROFESS",
                "DESCRIPTION": ""
            }
        ],
        "RESPONSABLES": [],
        "M3C": [],
        "PRESENTATION": []
    },
    "MODULES": [
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "ISI_05",
            "TITRE": "INGENIERIE DU LOGICIEL",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "ISI"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 21,
            "TP": 0,
            "EFFECTIF": 12,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "ISI_06",
            "TITRE": "INTEGRATION D'APPLICATIONS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "ISI"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 13,
            "TP": 0,
            "EFFECTIF": 16,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "ISI_07",
            "TITRE": "METHODES ORIENTEES OBJET D'ANALYSE ET DE CONCEPTION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "ISI"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 13,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Alexandre Bufffet"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "ISI_08",
            "TITRE": "PROJETS DE CONCEPTION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "ISI"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 16,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Alexandre Buffet"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "INFO_06",
            "TITRE": "BD AVANCEES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "INFO"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 19,
            "TP": 0,
            "EFFECTIF": 12,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Marc-Antoine Boryczka"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "INFO_11",
            "TITRE": "PROGRAMMATION ORIENTEE OBJET",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "INFO"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 19,
            "TP": 0,
            "EFFECTIF": 13,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "INFO_12",
            "TITRE": "PROGRAMMATION WEB",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "INFO"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 21,
            "TP": 0,
            "EFFECTIF": 11,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Nicolas Royackkers"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "INFO_13",
            "TITRE": "PROJET DE PROGRAMMATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "INFO"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 13,
            "TP": 0,
            "EFFECTIF": 14,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Nicolas Royackkers"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "INFO_14",
            "TITRE": "RESEAUX ET PROTOCOLES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "INFO"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 14,
            "TP": 0,
            "EFFECTIF": 12,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Alexandre Buffet"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "INFO_01",
            "TITRE": "ADMINISTRATION DES SE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "INFO",
                    "CHOIX": [
                        3,
                        [
                            "INFO_01",
                            "INFO_15",
                            "INFO_33"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "INFO_15",
            "TITRE": "UNIX AVANCE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "INFO",
                    "CHOIX": [
                        3,
                        [
                            "INFO_01",
                            "INFO_15",
                            "INFO_33"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 12,
            "TP": 0,
            "EFFECTIF": 2,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Jean-Pierre Aillet"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "INFO_33",
            "TITRE": "FRAMEWORKS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "INFO",
                    "CHOIX": [
                        3,
                        [
                            "INFO_01",
                            "INFO_15",
                            "INFO_33"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 23,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Nicolas Royackkers"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "GEO_03",
            "TITRE": "GESTION FINANCIERE ET CONTROLE DE GESTION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "GEO"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 14,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "GEO_04",
            "TITRE": "JEUX D'ENTREPRISE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "GEO"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 14,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "TRANS_01",
            "TITRE": "ANGLAIS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "TRANS"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 12,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "PRAG",
                "RESPONSABLES": [
                    "Stéphanie Portemer"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "TRANS_02",
            "TITRE": "COMMUNICATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "TRANS"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 14,
            "TP": 0,
            "EFFECTIF": 14,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Hélène Mariette"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "INFO_02",
            "TITRE": "ANALYSE ET DECISION EN ENTREPRISE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "TRANS",
                    "CHOIX": [
                        3,
                        [
                            "INFO_02",
                            "INFO_10"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "INFO_10",
            "TITRE": "PROCESSUS STOCHASTIQUES ET SIMULATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "TRANS",
                    "CHOIX": [
                        3,
                        [
                            "INFO_02",
                            "INFO_10"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 17,
            "TP": 0,
            "EFFECTIF": 2,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "PRO_01",
            "TITRE": "PROJET PROFESSIONNEL",
            "TYPE": "STAGE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 12,
                    "BLOCS": "PRO"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 16,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Nicolas Royackkers"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "ISI_14",
            "TITRE": "CONDUITE DE PROJET AGILE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "SIN",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "ISI"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 56,
            "TP": 0,
            "EFFECTIF": 41,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Hélène Mariette"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "ISI_17",
            "TITRE": "MANAGEMENT DE LA SECURITE DES SI",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "SIN",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "ISI"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 62,
            "TP": 0,
            "EFFECTIF": 36,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "ISI_10",
            "TITRE": "CONCEPTION DE JEUX VIDEOS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "SIN",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "ISI",
                    "CHOIX": [
                        3,
                        [
                            "ISI_10",
                            "ISI_13"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Guillaume Hibon"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "ISI_13",
            "TITRE": "GEOMATIQUE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "SIN",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "ISI",
                    "CHOIX": [
                        3,
                        [
                            "ISI_10",
                            "ISI_13"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "INFO_04",
            "TITRE": "ARCHITECTURE DES SYSTEMES D'INFORMATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "SIN",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "INFO"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 71,
            "TP": 0,
            "EFFECTIF": 46,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "INFO_05",
            "TITRE": "ARCHITECTURE DES SI MOBILES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "SIN",
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "INFO"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 62,
            "TP": 0,
            "EFFECTIF": 45,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "INFO_31",
            "TITRE": "WEB DESIGN",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "SIN",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "INFO"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 63,
            "TP": 0,
            "EFFECTIF": 42,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Nicolas Royackkers"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "INFO_23",
            "TITRE": "INTELLIGENCE ARTIFICIELLE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "SIN",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "INFO",
                    "CHOIX": [
                        3,
                        [
                            "INFO_23",
                            "INFO_24",
                            "INFO_30"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 42,
            "TP": 0,
            "EFFECTIF": 2,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Marc-Antoine Boryczka"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "INFO_24",
            "TITRE": "INFRASTRUCTURE DES RESEAUX",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "SIN",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "INFO",
                    "CHOIX": [
                        3,
                        [
                            "INFO_23",
                            "INFO_24",
                            "INFO_30"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 46,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Laurent Josse"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "INFO_30",
            "TITRE": "TECHNOLOGIES DES RESEAUX",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "SIN",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "INFO",
                    "CHOIX": [
                        3,
                        [
                            "INFO_23",
                            "INFO_24",
                            "INFO_30"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 57,
            "TP": 0,
            "EFFECTIF": 2,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Alexandre Buffet"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "GEO_07",
            "TITRE": "ECOMMERCE ET TECHNOLOGIES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "SIN",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "GEO"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 61,
            "TP": 0,
            "EFFECTIF": 19,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "GEO_08",
            "TITRE": "STRATEGIE D'ENTREPRISE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "SIN",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "GEO"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 48,
            "TP": 0,
            "EFFECTIF": 22,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "TRANS_07",
            "TITRE": "ANALYSE ET FOUILLE DE DONNEES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "SIN",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "TRANS",
                    "CHOIX": [
                        3,
                        [
                            "TRANS_07",
                            "TRANS_09"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 48,
            "TP": 0,
            "EFFECTIF": 1,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "TRANS_09",
            "TITRE": "DATA SCIENCE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "SIN",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "TRANS",
                    "CHOIX": [
                        3,
                        [
                            "TRANS_07",
                            "TRANS_09"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "PRO_03",
            "TITRE": "ETUDE DE CAS THEMATIQUE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "SIN",
                    "MODALITE": "obligatoire",
                    "ECTS": 9,
                    "BLOCS": "PRO"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 25,
            "TP": 0,
            "EFFECTIF": 49,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "PRO_04",
            "TITRE": "PPROJET PROFESSIONNEL",
            "TYPE": "STAGE",
            "STATUT": [
                {
                    "PARCOURS": "SIN",
                    "MODALITE": "obligatoire",
                    "ECTS": 15,
                    "BLOCS": "PRO"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 53,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Nicolas Royackkers"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        }
    ]
})