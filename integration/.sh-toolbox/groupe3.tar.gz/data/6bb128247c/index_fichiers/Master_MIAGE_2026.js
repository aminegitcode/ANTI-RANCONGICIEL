addMaquette({
    "FORMATION": {
        "NOM": "Master MIAGE 2026",
        "ETABLISSEMENT": "Université de Picardie - Jules Verne",
        "ANNEES": "2026/27",
        "NB_SEMESTRES": 4,
        "LMD": "M",
        "PARCOURS": [
            {
                "ID": "OSIE",
                "NOM": "OSIE",
                "DESCRIPTION": "Organisation des Systèmes d'Information de l'Entreprise",
                "ANNEES": [
                    2
                ]
            },
            {
                "ID": "ITD",
                "NOM": "ITD",
                "DESCRIPTION": "Ingénierie de la Transformation Digitale",
                "ANNEES": [
                    2
                ]
            },
            {
                "ID": "IDD",
                "NOM": "IDD",
                "DESCRIPTION": "Ingénierie des Données de la Décision",
                "ANNEES": [
                    2
                ]
            }
        ],
        "BLOCS": [
            {
                "ID": "BC01",
                "NOM": "BC01",
                "DESCRIPTION": "Mettre en œuvre une communication spécialisée pour le transfert de connaissances"
            },
            {
                "ID": "BC02",
                "NOM": "BC02",
                "DESCRIPTION": "Contribuer à la transformation en contexte professionnel"
            },
            {
                "ID": "BC03",
                "NOM": "BC03",
                "DESCRIPTION": "Analyser la situation d'une organisation en vue d'adapter et gérer son système d'information"
            },
            {
                "ID": "BC04",
                "NOM": "BC04",
                "DESCRIPTION": "Conduire des projets d'ingénierie numérique"
            },
            {
                "ID": "BC05",
                "NOM": "BC05",
                "DESCRIPTION": "Concevoir, développer et tester des applications dans des environnements spécifiques"
            },
            {
                "ID": "BC06",
                "NOM": "BC06",
                "DESCRIPTION": "Évaluer ou optimiser un processus / produit / service en utilisant des modèles mathématiques"
            },
            {
                "ID": "BC07",
                "NOM": "BC07",
                "DESCRIPTION": "Mobiliser et produire des savoirs hautement spécialisés"
            },
            {
                "ID": "BC08",
                "NOM": "BC08",
                "DESCRIPTION": "Mobiliser des compétences et savoirs transversaux"
            }
        ],
        "RESPONSABLES": [
            "anne.lapujade@u-picardie.fr"
        ],
        "M3C": [],
        "PRESENTATION": []
    },
    "MODULES": [
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1M_ETUCA",
            "TITRE": "ETUDE DE CAS SI",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": [
                        3,
                        3,
                        5,
                        10
                    ],
                    "BLOCS": [
                        "BC01",
                        "BC02",
                        "BC04",
                        "BC05"
                    ]
                }
            ],
            "CONTENU": [
                "Analyse préliminaire - 3ECTS - 3h CM + 6h TD",
                "Prise de recul et autoévaluation - 3ECTS - 3h TD",
                "Analyse du besoin et planification - 2ECTS - 3h TD",
                "Pilotage (planification technique, suivi d'avancement et animation d'équipe) - 3ECTS - 3h TD",
                "Elaboration du cahier des charges - 2ECTS - 6h TD",
                "Conception d'une application SI - 1ECTS - 3h TD",
                "Utiliser des outils de développement - 1ECTS - 3h TD",
                "Environnement de développement - 2ECTS - 3h TD",
                "Développement collaboratif front-end - 2ECTS - 3h TD",
                "Développement collaboratif back-end - 2ECTS - 3h TD"
            ],
            "PREREQUIS": [],
            "CM": 3,
            "TD": 36,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1M_CONDU",
            "TITRE": "CONDUITE DE PROJET",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 7,
                    "BLOCS": "BC04"
                }
            ],
            "CONTENU": [
                "Définition des ressources - 2ECTS - 2h CM + 6h TD",
                "Définition des exigences - 2ECTS - 2h CM + 6h TD",
                "Pilotage d'un projet - 3ECTS - 2h CM + 6h TD"
            ],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1M_PROAP",
            "TITRE": "PROJET PROFESSIONNEL - APPRENTISSAGE",
            "TYPE": "STAGE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": [
                        3,
                        3,
                        0
                    ],
                    "BLOCS": [
                        "BC01",
                        "BC02",
                        "BC08"
                    ],
                    "CHOIX": [
                        6,
                        [
                            "M1M_PROAP",
                            "M1M_PROST"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Communication écrite - 1.5ECTS - 3h TD",
                "Communication orale - 1.5ECTS - 3h TD",
                "Bilan de compétences - 3ECTS - 3h TD"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 9,
            "TP": 0,
            "EFFECTIF": 50,
            "GROUPES_CM": 0,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1M_PROST",
            "TITRE": "PROJET PROFESSIONNEL - STAGE",
            "TYPE": "STAGE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": [
                        3,
                        3,
                        0
                    ],
                    "BLOCS": [
                        "BC01",
                        "BC02",
                        "BC08"
                    ],
                    "CHOIX": [
                        6,
                        [
                            "M1M_PROAP",
                            "M1M_PROST"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Communication écrite - 1.5ECTS - 3h TD",
                "Communication orale - 1.5ECTS - 3h TD",
                "Bilan de compétences - 3ECTS - 3h TD"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 9,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1M_ANG",
            "TITRE": "ANGLAIS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1.5,
                    "BLOCS": "BC01"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 0,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1M_COM",
            "TITRE": "COMMUNICATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1.5,
                    "BLOCS": "BC01"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 2,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1M_ECOP",
            "TITRE": "ECONOMIE POLITIQUE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC03"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 16,
            "TD": 8,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1M_ORGA",
            "TITRE": "THEORIE DES ORGANISATIONS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC03"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 16,
            "TD": 8,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1M_DROI",
            "TITRE": "DROIT DU TRAVAIL",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC03",
                    "CHOIX": [
                        2,
                        [
                            "M1M_DROI",
                            "M1M_PROD"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 45,
            "GROUPES_CM": 2,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1M_PROD",
            "TITRE": "GESTION DE PRODUCTION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC03",
                    "CHOIX": [
                        2,
                        [
                            "M1M_DROI",
                            "M1M_PROD"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 30,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1M_RECH",
            "TITRE": "DECOUVERTE DE LA RECHERCHE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [
                "Mobiliser des savoirs (niveau 1) - 2ECTS - 2h CM + 5h TD",
                "Analyser les savoirs (niveau 1) - 1ECTS - 2h CM + 5h TD",
                "Proposer de nouveaux savoirs (niveau 1) - 1ECTS - 1h CM + 4h TD"
            ],
            "PREREQUIS": [],
            "CM": 5,
            "TD": 14,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1M_MODFO",
            "TITRE": "MODELISATION FONCTIONNELLE D'UNE APPLICATION SI",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 3,
            "TD": 21,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1M_BD",
            "TITRE": "MODELISER, OPTIMISER ET REQUETER UNE BD SQL ET NoSQL",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 2,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1M_IHM",
            "TITRE": "MODELISER UNE IHM RESPECTANT LES NORMES ET STANDARDS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1M_SOLID",
            "TITRE": "BONNES PRATIQUES DE MODELISATION : SOLID, CLEAN CODE et DESIGN PATTERNS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 0,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1M_DEVCO",
            "TITRE": "INGENIERIE DU LOGICIEL - VERSIONING ET DEVELOPPEMENT COLLABORATIF",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 0,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1M_QUALI",
            "TITRE": "INGENIERIE DU LOGICIEL - QUALITE DU CODE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1M_FRONT",
            "TITRE": "APPLICATIONS WEB FRONT-END",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 0,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1M_BACK",
            "TITRE": "APPLICATIONS BACK-END EN ARCHITECTURE CLEAN ET LEURS APIS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 0,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1M_DECIS",
            "TITRE": "ANALYSE ET DECISION EN ENTREPRISE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC06"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 2,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_CAS1",
            "TITRE": "ETUDE DE CAS CLIENT REEL (OSIE)",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OSIE",
                    "MODALITE": "obligatoire",
                    "ECTS": [
                        2,
                        10,
                        2,
                        0
                    ],
                    "BLOCS": [
                        "BC02",
                        "BC04",
                        "BC07",
                        "BC08"
                    ]
                }
            ],
            "CONTENU": [
                "Prise de responsabilité - 2ECTS - 6h TD",
                "Conduite du changement - 2ECTS - 6h TD",
                "Pilotage du projet - 2ECTS - 6h TD",
                "Définition d'une méthode de conduite de projet - 2ECTS - 6h TD",
                "Mise en place d'une stratégie de test - 2ECTS - 6h TD",
                "Adaptabilité - 2ECTS - 6h TD",
                "Analyse de l'existant et propositions de solutions - 2ECTS - 6h TD"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 42,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_PROAP",
            "TITRE": "PROJET PROFESSIONNEL - APPRENTISSAGE",
            "TYPE": "STAGE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": [
                        7,
                        0
                    ],
                    "BLOCS": [
                        "BC02",
                        "BC08"
                    ],
                    "CHOIX": [
                        7,
                        [
                            "M2M_PROAP",
                            "M2M_PROST"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Conduite de projet - 2ECTS - 6h TD",
                "Bilan de compétences (niveau 2) - 1ECTS - 6h TD",
                "Ethique, déontologie et environnement - 2ECTS - 6h TD",
                "Handicap et accessibilité - 2ECTS - 6h TD"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 50,
            "GROUPES_CM": 0,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_PROST",
            "TITRE": "PROJET PROFESSIONNEL - STAGE",
            "TYPE": "STAGE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": [
                        7,
                        0
                    ],
                    "BLOCS": [
                        "BC02",
                        "BC08"
                    ],
                    "CHOIX": [
                        7,
                        [
                            "M2M_PROAP",
                            "M2M_PROST"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Conduite de projet - 2ECTS - 6h TD",
                "Bilan de compétences (niveau 2) - 1ECTS - 6h TD",
                "Ethique, déontologie et environnement - 2ECTS - 6h TD",
                "Handicap et accessibilité - 2ECTS - 6h TD"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_JEU",
            "TITRE": "JEU D'ENTREPRISE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "BC03"
                }
            ],
            "CONTENU": [
                "Analyser un cas - 2ECTS - 12h TD",
                "Outils de gestion - 2ECTS - 6h CM + 18h TD",
                "Proposer une stratégie - 2ECTS - 12h TD"
            ],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 42,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_COMP",
            "TITRE": "REALISER SON PORTEFEUILLE DE COMPETENCES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "BC02"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 3,
            "TD": 9,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 0,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_AUDIT",
            "TITRE": "AUDIT DES SI",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OSIE",
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "BC03"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_STRAT",
            "TITRE": "STRATEGIE D'ENTREPRISE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC03"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 16,
            "TD": 8,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_CHANG",
            "TITRE": "CONDUITE DU CHANGEMENT",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OSIE",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC04"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_AGIL",
            "TITRE": "CONDUITE DE PROJET AGILE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC04"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 3,
            "TD": 21,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_INGE",
            "TITRE": "INGENIERIE DU LOGICIEL - STRATEGIES DE TESTS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OSIE",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC04"
                },
                {
                    "PARCOURS": "ITD",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "BC04"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_GREEN",
            "TITRE": "NORMES DE QUALITE ET GREEN IT",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OSIE",
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "BC04"
                },
                {
                    "PARCOURS": "ITD",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC04"
                },
                {
                    "PARCOURS": "IDD",
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "BC04"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_WOFLO",
            "TITRE": "WORKFLOWS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OSIE",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_PERSO",
            "TITRE": "PROTECTION DES DONNEES PERSONNELLES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OSIE",
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [
                "Modélisation fonctionnelle - 2ECTS - 3h CM + 9h TD",
                "Modélisation technique - 2ECTS - 3h CM + 9h TD"
            ],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_ARCHI",
            "TITRE": "ARCHITECTURES EN COUCHES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OSIE",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC05"
                },
                {
                    "PARCOURS": "ITD",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 50,
            "GROUPES_CM": 0,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_PROGI",
            "TITRE": "PROGICIELS DE GESION INTEGRES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OSIE",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 3,
            "TD": 21,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_ECOM",
            "TITRE": "ECOMMERCE ET TECHNOLOGIES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OSIE",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 3,
            "TD": 21,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_RECH1",
            "TITRE": "DECOUVERTE DE LA RECHERCHE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "BC07"
                }
            ],
            "CONTENU": [
                "Mobiliser des savoirs (niveau 2) - 1ECTS - 2h CM + 5h TD",
                "Analyser les savoirs (niveau 2) - 1ECTS - 2h CM + 5hTD",
                "Proposer de nouveaux savoirs (niveau 2) - 1ECTS - 1h CM + 4h TD",
                "Contribuer à l'évolution des savoirs - 1ECTS - 1h CM + 4h TD"
            ],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_CAS2",
            "TITRE": "ETUDE DE CAS CLIENT REEL (ITD)",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ITD",
                    "MODALITE": "obligatoire",
                    "ECTS": [
                        2,
                        11,
                        2,
                        2,
                        0
                    ],
                    "BLOCS": [
                        "BC02",
                        "BC04",
                        "BC05",
                        "BC07",
                        "BC08"
                    ]
                }
            ],
            "CONTENU": [
                "Prise de responsabilité - 2ECTS - 6h TD",
                "Pilotage du projet - 4ECTS - 6h TD",
                "Définition d'une méthode de conduite de projet - 2ECTS - 6h TD",
                "Mise en place d'une stratégie de test - 1ECTS - 6h TD",
                "Adaptabilité - 4ECTS - 6h TD",
                "Mise en place d'outils de gestion du logiciel - 2ECTS - 6h TD",
                "Analyse de l'existant et propositions de solutions - 2ECTS - 6h TD"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 42,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_INGE2",
            "TITRE": "INGENIERIE DU LOGICIEL - OUTILS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ITD",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_SECU",
            "TITRE": "MANAGEMENT DE LA SECURITE DES SI",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ITD",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC04"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_MICRO",
            "TITRE": "ARCHITECTURES MICROSERVICES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ITD",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_DEVOP",
            "TITRE": "TECHNIQUES DE BASE DU DEVOPS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ITD",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_3DVR",
            "TITRE": "DEVELOPPER DES APPLICATIONS 3D ET VR",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ITD",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_FRONT",
            "TITRE": "DEVELOPPER DES APPLICATIONS MOBILES ET OU MULTI-PLATEFORMES FRONTEND",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ITD",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 12,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_BACK",
            "TITRE": "DEVELOPPER DES APPLICATIONS MOBILES ET OU MULTI-PLATEFORMES BACKEND",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ITD",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 12,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_IA",
            "TITRE": "INTEGRER DES API D'IA DANS UNE APPLICATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ITD",
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "BC05"
                },
                {
                    "PARCOURS": "IDD",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC05"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 50,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_CAS3",
            "TITRE": "ETUDE DE CAS CLIENT REEL (IDD)",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "IDD",
                    "MODALITE": "obligatoire",
                    "ECTS": [
                        2,
                        10,
                        2,
                        2,
                        0
                    ],
                    "BLOCS": [
                        "BC02",
                        "BC04",
                        "BC06",
                        "BC07",
                        "BC08"
                    ]
                }
            ],
            "CONTENU": [
                "Prise de responsabilité - 2ECTS - 6h TD",
                "Pilotage du projet - 4ECTS - 6h TD",
                "Définition d'une méthode de conduite de projet - 2ECTS - 6h TD",
                "Adaptabilité - 4ECTS - 6h TD",
                "Intégrer de l'aide à la décision dans une application - 2ECTS - 6h TD",
                "Analyse de l'existant et propositions de solutions - 2ECTS - 6h TD"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 42,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_GESTI",
            "TITRE": "CONTROLE DE GESTION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "IDD",
                    "MODALITE": "obligatoire",
                    "ECTS": 0,
                    "BLOCS": "BC03"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_INTER",
            "TITRE": "INTEROPERABILITE DE SI",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "IDD",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "BC03"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_BI",
            "TITRE": "OUTILS POUR LA BI",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "IDD",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "BC03"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_KM",
            "TITRE": "CAPITALISATION ET MANAGEMENT DES CONNAISSANCES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "IDD",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC03"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_BIOMI",
            "TITRE": "ALGORITHMES BIOMIMETIQUES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "IDD",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC06"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_DATA",
            "TITRE": "ANALYSE ET FOUILLE DE DONNEES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "IDD",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC06"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_STAT",
            "TITRE": "STATISTIQUES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "IDD",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC06"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2M_ML",
            "TITRE": "MACHINE LEARNING",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "IDD",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "BC06"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 25,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        }
    ]
})