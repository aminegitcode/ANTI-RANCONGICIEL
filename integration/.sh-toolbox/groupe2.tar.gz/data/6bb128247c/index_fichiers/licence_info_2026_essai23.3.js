addMaquette({
    "FORMATION": {
        "NOM": "Licence Informatique 2026",
        "ETABLISSEMENT": "Université de Picardie - Jules Verne",
        "ANNEES": "2026/27",
        "NB_SEMESTRES": 6,
        "LMD": "L",
        "PARCOURS": [
            {
                "ID": "INFO",
                "NOM": "INFORMATIQUE",
                "DESCRIPTION": "Informatique générale",
                "ANNEES": [
                    2,
                    3
                ]
            },
            {
                "ID": "MIAGE",
                "NOM": "MIAGE",
                "DESCRIPTION": "Méthodes Informatiques Appliquées à la Gestion des Entreprises",
                "ANNEES": [
                    2,
                    3
                ]
            }
        ],
        "M3C": [
            "Un module est validé si sa note est supérieure ou égale à 10 (le module ne peut être repassé)",
            "Un module est validé par compensation si sa note est inférieure à 10 mais que la moyenne semestrielle ou annuelle de son bloc de compétences est supérieure ou égale à 10 (le module ne peut être repassé)",
            "Un bloc de compétences est validé (au niveau d'un semestre ou d'une année) si la moyenne pondérée des modules du bloc est supérieure ou égale à 10",
            "Un bloc de compétences est validé par compensation sur l'année si sa moyenne est comprise entre 8 et 10 exclu mais que la moyenne pondérée des blocs sur l'année est supérieure ou égale à 10",
            "Une année est validée si tous les blocs de compétences de l'année le sont ou si la moyenne pondérée des blocs est supérieure ou égale à 10 avec au moins 8 dans chaque bloc",
            "Un étudiant est AJAC (ajourné autorisé à continuer) s'il n'a pas validé son année mais a validé au moins 45 ECTS",
            "La licence est obtenue quand les 3 années sont validées"
        ],
        "BLOCS": [
            {
                "NOM": "C1",
                "DESCRIPTION": "CONCEVOIR ET METTRE EN OEUVRE UN PROGRAMME",
                "ID": "C1"
            },
            {
                "NOM": "C2",
                "DESCRIPTION": "ORGANISER LES DONNEEES ET LES SYSTEMES",
                "ID": "C2"
            },
            {
                "NOM": "C3",
                "DESCRIPTION": "CONSTRUIRE SON PARCOURS DIFFERENCIE",
                "ID": "C3"
            },
            {
                "NOM": "CT",
                "DESCRIPTION": "TRANSVERSE",
                "ID": "CT"
            }
        ],
        "RESPONSABLES": [
            "Responsable L1 : sami.cherif@u-picardie.fr",
            "Responsable L2 : rui.shibasaki@u-picardie.fr",
            "Responsable L3 : leo.robert@u-picardie.fr",
            "Responsable de la licence : frederic.furst@u-picardie.fr"
        ],
        "PRESENTATION": [
            "La licence Informatique est une formation généraliste qui permet d’acquérir les connaissances et compétences communes à tous les métiers de l’informatique afin d’accéder aux différents masters. Les enseignements couvrent à la fois les aspects fondamentaux (algorithmique, logique, ...) et techniques (programmation, bases de données, Web, réseau, ...). Les étudiants acquièrent également des compétences transverses (anglais, communication) et développent leurs aptitudes professionnelles à travers la réalisation de nombreux projets et d’un stage. En 3e année, un large éventail d’options permet de commencer à se spécialiser en vue de l’orientation en master (par exemple systèmes d’information d’entreprise, intelligence artificielle, cybersécurité ou robotique).",
            "Une formation pour les passionnés de technologie souhaitant travailler et innover dans un secteur en pleine expansion !<br>",
            "Les enseignements se déroulent sur 6 semestres soit 3 ans :<br>&nbsp;&nbsp;• En L1, acquisition des compétences et connaissances de base des différentes branches de l’informatique (programmation, bases de données, systèmes, réseaux, Web), ainsi que des outils mathématiques indispensables.<br>&nbsp;&nbsp;• En L2, année de consolidation, avec un nombre réduit d’options.<br>&nbsp;&nbsp;• En L3, année de spécialisation grâce aux 2 parcours proposés :<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Informatique : davantage d’options sur les systèmes, les réseaux et la sécurité<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- MIAGE : davantage d’options sur le développement et l’informatique de gestion"
        ]
    },
    "MODULES": [
        {
            "SEMESTRE": 1,
            "ID": "L1_ALGO1",
            "TITRE": "ALGORITHMIQUE 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C1"
                }
            ],
            "OBJECTIFS": [
                "&Eacute;crire un algorithme simple répondant à un problème donné",
                "Implémenter un algorithme simple en langage C"
            ],
            "CONTENU": [
                "Notion de problème et d'algorithmes pour le résoudre",
                "Tableau, tableau à plusieurs dimensions",
                "Algorithmique des tableaux (parcours de tableau, recherche séquentielle, comptage, recherche du max, drapeau)",
                "Etude de tris quadratiques",
                "Variable, type de donnée, expressions",
                "Instruction, affectation, instruction conditionnelle, instruction répétitive",
                "Programme, sous-programme, fonction, passage de paramètres",
                "Programmation d'une carte Arduino en C",
                "Programmation sur mobile"
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 24,
            "TP": 20,
            "EFFECTIF": 250,
            "GROUPES_CM": 1,
            "GROUPES_TD": 10,
            "GROUPES_TP": 20,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Léo Robert"
                ],
                "INTERVENANTS": [
                    "Sami Cherif"
                ]
            },
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 1,
            "ID": "L1_REPRE",
            "TITRE": "REPRESENTATION DE L'INFORMATION",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C2"
                }
            ],
            "OBJECTIFS": [
                "Maitriser l'encodage numérique de l'information",
                "Identifier les limites des codages et de leurs opérations",
                "Utiliser des fichiers dans un programme"
            ],
            "CONTENU": [
                "Rappel de Numération : les différentes bases utilisées en Informatique, algorithmes de conversion",
                "Représentation d'informations : les chiffres, caractères, les entiers, entiers signés, les fractionnaires en virgule fixe (signé ou non), les fractionnaires en virgule flottante",
                "Opérations sur les nombres (entiers et réels) : rappel des algorithmes opératoires, identification de la véracité des résultats",
                "Encodage des caractères (ASCII, Unicode, ..)",
                "Codage des couleurs et des images",
                "Notion de compression de données",
                "Manipulation des fichiers et notion de flux",
                "Fichier texte, image"
            ],
            "PREREQUIS": [
                "L1_ALGO1"
            ],
            "CM": 8,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 250,
            "GROUPES_CM": 1,
            "GROUPES_TD": 7,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Pascal Vasseur"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "10h de TD sont sur machine à 25 étudiants/groupe"
            ],
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 1,
            "ID": "L1_SE1",
            "TITRE": "SYSTEME D'EXPLOITATION 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Terminologie / principes généraux",
                "Système de Fichiers",
                "Maîtrise du terminal (variables d’environnement, IO standard)",
                "Permissions, processus/jobs"
            ],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 14,
            "TP": 10,
            "EFFECTIF": 250,
            "GROUPES_CM": 1,
            "GROUPES_TD": 7,
            "GROUPES_TP": 14,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Gil Utard"
                ],
                "INTERVENANTS": [
                    "Stéphane Desvismes"
                ]
            },
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 1,
            "ID": "L1_MTC",
            "TITRE": "METHODES ET TECHNIQUES DE CALCUL",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Fonctions usuelles (logarithme, exponentielles, fonctions puissances, fonctions trigonométriques). Limites et comportement asymptotique, croissances comparées",
                "Suites numériques (monotonie, arithmétique, géométrique, somme des premiers termes)",
                "Continuité, dérivabilité d’une fonction numérique. Tangente, convexité, inflexion. Calcul pratique des dérivées partielles (deux ou trois variables, pas de continuité des fonctions de plusieurs variables), utilisation pour les extrema de fonctions de deux variables",
                "Compléments sur les calculs de primitives et leur application au calcul d’intégrales : Intégration par partie, changement de variables, fractions rationnelles (cas simples)",
                "&Eacute;quations différentielles linéaires du premier ordre, méthode de la variation de la constante, équations différentielles linéaires du second ordre à coefficients constants. Image d’un intervalle [a,b] par une fonction continue réelle (admis). Egalité et inégalité des accroissements finis (pourra être admis)"
            ],
            "PREREQUIS": [],
            "CM": 8,
            "TD": 16,
            "TP": 0,
            "EFFECTIF": 250,
            "GROUPES_CM": 1,
            "GROUPES_TD": 7,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "département Math",
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "NOTES": [
                "module assuré par le département de mathématiques et commun avec la mention SVT"
            ],
            "STYLE": "Maths"
        },
        {
            "SEMESTRE": 2,
            "ID": "L1_MATH1",
            "TITRE": "OUTILS MATH 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C3"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Dénombrabilité, récurrence",
                "Relations d'équivalence, d'ordre, treillis",
                "Matrices, représentation d’un vecteur et d’une application linéaire sous forme matricielle",
                "Calcul matriciel : somme, produit, transposée",
                "Sous-espaces supplémentaires",
                "Produit scalaire, orthogonalité",
                "Calculs de déterminant"
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 28,
            "TP": 0,
            "EFFECTIF": 250,
            "GROUPES_CM": 1,
            "GROUPES_TD": 7,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Léo Robert"
                ],
                "INTERVENANTS": []
            },
            "STYLE": "Maths"
        },
        {
            "SEMESTRE": 1,
            "ID": "L1_TRAN1",
            "TITRE": "TRANSVERSE S1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "CT"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Anglais, communication, outils numériques, formation professionnelle"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 250,
            "GROUPES_CM": 0,
            "GROUPES_TD": 7,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Transverse"
        },
        {
            "SEMESTRE": 1,
            "ID": "L1_SYSNU",
            "TITRE": "SYSTEMES NUMERIQUES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Logique combinatoire : Algèbre de Boole, composants combinatoires et exemples de circuits intégrés (portes, multiplexeurs, codeurs, …)",
                "Logique séquentielle : Bascules, registres, compteurs asynchrones et synchrones, ...",
                "Trois TD sur les 7 prévus se dérouleront sur machine avec le logiciel ISIS (de la suite Proteus)"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 14,
            "TP": 0,
            "EFFECTIF": 125,
            "GROUPES_CM": 1,
            "GROUPES_TD": 7,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "département EEA",
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "COUT": 0.0,
            "NOTES": [
                "Module de la licence SPI"
            ],
            "STYLE": "SPI"
        },
        {
            "SEMESTRE": 1,
            "ID": "L1_MATH0",
            "TITRE": "STRUCTURES FONDAMENTALES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C3"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Langage du calcul propositionnel (négation, connecteurs logiques, quantificateurs)",
                "Langage de la théorie naïve des ensembles (inclusion, intersection, réunion, complémentaire, produit, applications, injectivité, surjectivité, bijectivité, relations d'équivalence et d'ordre)",
                "Groupe des permutations (cardinalité, ordre d'un élément, transposition, cycle, parties génératrices, signature)",
                "Groupe des restes modulo n (structure, congruence, ordre d'un élément, groupe, sous-groupe)",
                "Anneau des entiers (division euclidienne, divisibilité, éléments irréductibles, décomposition en facteurs premiers, ppcm, pgcd et algorithme d'Euclide)",
                "Anneau des polynômes à coefficients réels ou complexes (racines et multiplicité, division euclidienne, divisibilité, décomposition en polynômes irréductibles, ppcm, pgcd et algorithme d'Euclide, théorème de Bézout)",
                "Anneau des restes modulo n (inversibilité, lemme chinois, exemples simples d'équations diophantiennes)",
                "Corps des nombres réels. Partie entière, densité des rationnels et irrationnels"
            ],
            "PREREQUIS": [],
            "CM": 18,
            "TD": 28,
            "TP": 0,
            "EFFECTIF": 125,
            "GROUPES_CM": 1,
            "GROUPES_TD": 7,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "département Math",
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "COUT": 0.0,
            "NOTES": [
                "module de la licence mathématiques"
            ],
            "STYLE": "Maths"
        },
        {
            "SEMESTRE": 2,
            "ID": "L1_ALGO2",
            "TITRE": "ALGORITHMIQUE 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Rappels des notions algorithmiques vues en S1 et retour sur les tableaux, introduction des tableaux multidimensionnels",
                "Algorithmes de recherche (séquentielle / dichotomique / par interpolation)",
                "Algorithmes de tris quadratiques (bulle / sélection / insertion)",
                "Types énumérés et enregistrements",
                "Pointeurs et retour sur les passages de paramètres des fonctions/procédures"
            ],
            "PREREQUIS": [
                "L1_ALGO1"
            ],
            "CM": 8,
            "TD": 12,
            "TP": 10,
            "EFFECTIF": 250,
            "GROUPES_CM": 1,
            "GROUPES_TD": 10,
            "GROUPES_TP": 20,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Sami Cherif",
                    "Stéphane Desvismes possible"
                ],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 2,
            "ID": "L1_LOGIC",
            "TITRE": "LOGIQUE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "OBJECTIFS": [
                "Savoir écrire une formule logique",
                "&Ecirc;tre capable de déterminer si un raisonnement est correct ou non",
                "Savoir modéliser un problème en utilisant un formalisme logique",
                "&Ecirc;tre capable d'écrire une preuve rigoureuse"
            ],
            "CONTENU": [
                "&Eacuteléments d'histoire et définitions de notions générales, liens avec l'informatique",
                "La logique propositionnelle : définition en tant que langage. Opérateurs logiques et formules. Tautologies. Fonctions booléennes et puissance expressive du langage de logique propositionnelle",
                "La logique du premier ordre : prédicats et fonctions, quantificateurs, occurrences de variables libres / liées. Définition en tant que langage. Interprétations, évaluations, modèles",
                "Les notions basiques de théories formelles : axiomes, règles de déduction, preuve, théorèmes",
                "Styles de preuve : directe, par l'absurde, induction (au travers d’exemples)"
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 250,
            "GROUPES_CM": 1,
            "GROUPES_TD": 10,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "partiel et examen, max(examen,(partiel+examen)/2)",
                "SECONDE_CHANCE": "examen",
                "SESSION_2": "seconde chance"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Stéphane Desvismes"
                ],
                "INTERVENANTS": [
                    "Sami Cherif",
                    "Léo Robert"
                ]
            },
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 2,
            "ID": "L1_BDR1",
            "TITRE": "BASES DE DONNEES RELATIONELLES 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "OBJECTIFS": [
                "Comprendre et ajuster un schéma relationnel existant, en maitrisant les concepts de relations, d’attributs, de clés primaires et étrangères, et appréhender les liens entre les données",
                "Rédiger et exécuter des requêtes SQL sur un SGBD relationnel, en définition de données, à partir d’un schéma relationnel donné",
                "Rédiger et exécuter des requêtes SQL sur un SGBD relationnel, en manipulations de données (mono-table et multi-table) à partir d’une base existante"
            ],
            "CONTENU": [
                "Introduction aux Systèmes d'Information",
                "Introduction et utilisation d'un Système de Gestion de Bases de Données",
                "Langage SQL (partie DML) et algèbre relationnelle"
            ],
            "PREREQUIS": [],
            "CM": 8,
            "TD": 10,
            "TP": 12,
            "EFFECTIF": 250,
            "GROUPES_CM": 1,
            "GROUPES_TD": 7,
            "GROUPES_TP": 14,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "Stéphane Desvismes"
                ]
            },
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 2,
            "ID": "L1_RES1",
            "TITRE": "RESEAU 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Modèles en couches (OSI, TCP/IP)",
                "Adressage IPv4 : adresses IP, masque, sous-réseaux",
                "Protocoles de base (ARP, ICMP, DHCP, HTTP…)",
                "Notions de client-serveur",
                "Équipements réseaux (switch, routeur)",
                "Réseaux LAN / WAN et topologies courantes"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 10,
            "TP": 10,
            "EFFECTIF": 250,
            "GROUPES_CM": 1,
            "GROUPES_TD": 7,
            "GROUPES_TP": 14,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Wafa Badreddine",
                    "Gil Utard"
                ],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 2,
            "ID": "L1_WEB1",
            "TITRE": "WEB 1",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "OBJECTIFS": [
                "Développer une interface Web côté client en HTML/CSS/JS",
                "Structurer une page Web de façon sémantique en dissociant contenu et forme",
                "Rendre une page Web dynamique en manipulant le DOM"
            ],
            "CONTENU": [
                "Généralités sur le Web : URL, HTTP(S), client/serveur, navigateur",
                "HTML et CSS",
                "Manipulation du DOM",
                "Programmation côté client en Javascript",
                "Programmation événementielle"
            ],
            "PREREQUIS": [
                "L1_ALGO1"
            ],
            "CM": 6,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 250,
            "GROUPES_CM": 1,
            "GROUPES_TD": 7,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "non",
                "SESSION_2": "non"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Frédéric Fürst"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "24h de TD sont sur machine à 25 étudiants/groupe"
            ],
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 2,
            "ID": "L1_PROBA",
            "TITRE": "PROBABILITES & STATISTIQUES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Vocabulaire de la statistique. Statistique descriptive à une et deux variables : représentations graphiques, paramètre de position et de dispersion. Droite de régression des moindres carrés",
                "Introduction au calcul des probabilités. Probabilité conditionnelle. Indépendance",
                "Notions de variables aléatoires réelles discrètes et à densité. Moments. Lois usuelles (dont Binomiale, Poisson, Normale). Approximation de la Binomiale par la Normale, théorème central-limite."
            ],
            "PREREQUIS": [],
            "CM": 8,
            "TD": 16,
            "TP": 0,
            "EFFECTIF": 250,
            "GROUPES_CM": 1,
            "GROUPES_TD": 7,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "département Math",
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "COUT": 0.0,
            "NOTES": [
                "module de la licence mathématiques"
            ],
            "STYLE": "Maths"
        },
        {
            "SEMESTRE": 2,
            "ID": "L1_TRAN2",
            "TITRE": "TRANSVERSE S2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [
                "Anglais, communication, outils numériques, formation professionnelle"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 250,
            "GROUPES_CM": 0,
            "GROUPES_TD": 7,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Transverse",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "L2_STLIN",
            "TITRE": "STRUCTURES LINEAIRES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Retour sur les algorithmes itératifs et introduction de la notion de récursivité",
                "Notions de piles, files, listes doublement chaînées",
                "Tables de hachage",
                "Introduction aux notions de correction, terminaison et de complexité algorithmique",
                "Retour sur les pointeurs et introduction des listes chaînées"
            ],
            "PREREQUIS": [
                "L1_ALGO2"
            ],
            "CM": 12,
            "TD": 28,
            "TP": 0,
            "EFFECTIF": 120,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Sami Cherif",
                    "Stéphane Desvismes possible",
                    "David Semé possible"
                ],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 3,
            "ID": "L2_PROGC",
            "TITRE": "PROGRAMMATION ET LANGAGE C",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C1"
                }
            ],
            "OBJECTIFS": [
                "Maîtriser les types de données simples et complexes et les fonctions permettant de les manipuler en C",
                "Utiliser les fonctions de la librairie standard",
                "Maîtriser les étapes de la compilation d'un programme, utiliser la compilation séparée",
                "Connaître le fonctionnement du stockage en mémoire des données, utiliser les pointeurs de façon efficace et appropriée",
                "Créer un code clair et modulaire"
            ],
            "CONTENU": [
                "Syntaxe : structures de contrôle, opérateurs et expressions",
                "Types, tableaux et pointeurs, passage de paramètres",
                "Gestion de la mémoire, programmation dynamique et algorithmes génériques",
                "Compilation séparée : pré-processeur, visibilité, édition de liens et atelier de compilation",
                "Librairie standard"
            ],
            "PREREQUIS": [
                "L1_ALGO2"
            ],
            "CM": 18,
            "TD": 10,
            "TP": 22,
            "EFFECTIF": 120,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Rui Shibasaki"
                ],
                "INTERVENANTS": [
                    "Sami Cherif",
                    "Stéphane Desvismes"
                ]
            },
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 3,
            "ID": "L2_BDR2",
            "TITRE": "BASES DE DONNEES RELATIONNELLES 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C2"
                }
            ],
            "OBJECTIFS": [
                "Être capable de  concevoir et mettre en œuvre un schéma relationnel, concevoir un modèle conceptuel des données",
                "Concevoir des requêtes agrégatives",
                "Concevoir des requêtes efficaces",
                "Rédiger et exécuter des requêtes SQL aggrégatives sur un SGBD relationnel, en manipulations de données (mono-table et multi-table) à partir d’une base existante",
                "Etre capable d’évaluer le niveau de redondance dans une base et être capable de le réduire"
            ],
            "CONTENU": [
                "Modèle E/A",
                "Les règles de transformation du modèle E/A étendu vers le modèle relationnel",
                "Approfondissement du langage SQL : mise en œuvre de requêtes plus complexes à l’aide des fonctions agrégatives",
                "Optimisation algébrique et sous SQL des requêtes",
                "Présentation et justification de la classification des relations sous formes normales",
                "Algorithme de  décomposition des relations"
            ],
            "PREREQUIS": [
                "L1_BDR1"
            ],
            "CM": 16,
            "TD": 20,
            "TP": 14,
            "EFFECTIF": 120,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "Stéphane Desvismes"
                ]
            },
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 3,
            "ID": "L2_SE2",
            "TITRE": "SYSTEME D'EXPLOITATION 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C2"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Scripts «avancés» : structures de contrôle, etc",
                "Expressions régulières : sed / grep / ...",
                "Introduction à la programmation système (syscalls POSIX)"
            ],
            "PREREQUIS": [
                "L1_SE1"
            ],
            "CM": 10,
            "TD": 14,
            "TP": 16,
            "EFFECTIF": 120,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Gaël Le Mahec"
                ],
                "INTERVENANTS": [
                    "Stéphane Desvismes"
                ]
            },
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 4,
            "ID": "L2_ASSEM",
            "TITRE": "ASSEMBLEUR",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "OBJECTIFS": [
                "Identifier les éléments fonctionnels d’un système numérique de traitement",
                "Comprendre et écrire des routines simples en langage machine"
            ],
            "CONTENU": [
                "Les bus du microprocesseur, la mémoire vue du microprocesseur, les registres du microprocesseur",
                "Le Langage d'assemblage : les modes d'adressage, écriture d'une ligne de programme, présentation du jeu d'instructions, écriture de programmes, exécution conditionnée, simulation de boucles, les sous-programmes, notion de variables, les appels systèmes",
                "Réalisation d'un projet"
            ],
            "PREREQUIS": [
                "L1_ALGO1"
            ],
            "CM": 6,
            "TD": 9,
            "TP": 15,
            "EFFECTIF": 120,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "sup(examen,(examen+projet)/2)",
                "SECONDE_CHANCE": "examen",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "David Semé"
                ],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 3,
            "ID": "L2_MATH2",
            "TITRE": "OUTILS MATH 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "INFO",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Systèmes d'équations linéaires, décomposition LU, factorisation QR",
                "&Eacute;quations non linéaires, méthode de point fixe",
                "Interpolation et approximation"
            ],
            "PREREQUIS": ["L1_MATH1"],
            "CM": 8,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 80,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Claire Delaplace"
                ],
                "INTERVENANTS": []
            },
            "STYLE": "Maths"
        },
        {
            "SEMESTRE": 3,
            "ID": "L2_GESTI",
            "TITRE": "BASES DE GESTION",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "MIAGE",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Logique entrepreneuriale et logique managériale",
                "Finalité de l’entreprise et performance",
                "Caractéristiques et choix d’une structure organisationnelle",
                "La démarche mercatique",
                "Le marché et ses composantes (offre, demande, environnement)",
                "Le plan d’actions commerciales (politique produit, politique prix, politique de communication, politique de  distribution)"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 40,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Gestion"
        },
        {
            "SEMESTRE": 3,
            "ID": "L2_TRAN3",
            "TITRE": "TRANSVERSE S3",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "CT"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Anglais, communication, outils numériques, formation professionnelle"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 120,
            "GROUPES_CM": 0,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Transverse"
        },
        {
            "SEMESTRE": 4,
            "ID": "L2_ARBRE",
            "TITRE": "ALGORITHMIQUE DES ARBRES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "OBJECTIFS": [
                "Savoir implémenter la structure d'arbre dans un programme",
                "Savoir implémenter les algorithmes de base sur les arbres et ABR",
                "Savoir choisir les types d'arbres et les algorithmes les plus adaptés pour un problème donné"
            ],
            "CONTENU": [
                "Parcours d'arbre",
                "Arbre binaire, ABR",
                "Arbres équilibrés, équilibrage",
                "B-arbre et application à la gestion des données",
                "Tri par tas",
                "Notion de preuve de programme, invariant",
                "Représentation des arbres",
                "Implémentation de différents algorithmes de manipulation d'arbres (parcours, ajout/suppression, ...)",
                "Réalisation d'un projet"
            ],
            "PREREQUIS": [
                "L2_STLIN"
            ],
            "CM": 8,
            "TD": 32,
            "TP": 0,
            "EFFECTIF": 120,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "(examen écrit de 2h+2*projet)/3",
                "SECONDE_CHANCE": "examen écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Frédéric Fürst"
                ],
                "INTERVENANTS": [
                    "Sami Cherif"
                ]
            },
            "NOTES": [
                "16h de TD sont sur machine"
            ],
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 4,
            "ID": "L2_LF1",
            "TITRE": "LANGAGES FORMELS 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "OBJECTIFS": [
                "Extraire des règles lexicales caractérisant un texte et concevoir une expression régulière le reconnaissant",
                "Proposer un automate efficace (facilement manipulable) pour représenter un langage",
                "Identifier les langages reconnaissables"
            ],
            "CONTENU": [
                "Notions de base (mots, langages, ...)",
                "Langages reconnaissables, automates finis",
                "Langages et expressions rationnelles (liens avec les outils de recherche utilisant des expressions régulières)",
                "Théorème de Kleene, algorithmes de passage d’un automate à une expression rationnelle et réciproquement",
                "Langage reconnu par un automate (algorithme de Mac Naughton et Yamada)",
                "Propriétés de fermeture rationnelles",
                "Déterminisme",
                "Propriétés de fermeture non rationnelles",
                "Minimalité",
                "Langages non reconnaissables, théorème de l'étoile"
            ],
            "PREREQUIS": [],
            "CM": 14,
            "TD": 16,
            "TP": 0,
            "EFFECTIF": 120,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Florence Levé"
                ],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 4,
            "ID": "L2_POO1",
            "TITRE": "PROGRAMMATION OBJET 1",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "OBJECTIFS": [
                "Concevoir et développer un programme suivant le paradigme objet",
                "Maitriser les différents mécanismes de la programmation objet en Java",
                "Exploiter ces mécanismes pour améliorer la qualité du logiciel produit: robustesse, extensibilité, réutilisabilité"
            ],
            "CONTENU": [
                "Notion d'objet et de classe, méthodes, constructeurs",
                "Diagramme de classes en UML",
                "Encapsulation, visibilité",
                "Héritage",
                "Polymorphisme",
                "Abstraction : méthodes abstraites, classes abstraites, interfaces",
                "Packages",
                "Exception"
            ],
            "PREREQUIS": [
                "L2_STLIN"
            ],
            "CM": 10,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 120,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "examen",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Catherine Barry"
                ],
                "INTERVENANTS": [
                    "Sami Cherif"
                ]
            },
            "NOTES": [
                "14h de TD sont sur machine"
            ],
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 4,
            "ID": "L2_WEB2",
            "TITRE": "WEB 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C2"
                }
            ],
            "OBJECTIFS": [
                "Concevoir une BDR",
                "Concevoir un site web dynamique, qui interagit avec une base de données",
                "Manipuler et conserver, côté serveur, des données provenant des utilisateurs d'un site web"
            ],
            "CONTENU": [
                "Fonctionnement d’une architecture client/serveur de contenu Web : Protocole HTTP, langage PHP, traitement de formulaires, sessions, upload",
                "Interfaçage avec une base de données",
                "Projet en Simfony",
                "Conception d'une BDR et accès via une interface Web",
                "Notion de test unitaire"
            ],
            "PREREQUIS": [
                "L1_WEB1",
                "L2_BDR2"
            ],
            "CM": 0,
            "TD": 0,
            "TP": 40,
            "EFFECTIF": 120,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "examen",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Yoann Dieudonné"
                ],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 4,
            "ID": "L2_RES2",
            "TITRE": "RESEAU 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Adressage avancé : IPv4 et IPv6",
                "Routage : statique et dynamique (RIP, OSPF, BGP)",
                "Protocoles de transport : TCP / UDP, sockets",
                "Services réseaux essentiels : DNS, DHCP, SMTP, POP3/IMAP"
            ],
            "PREREQUIS": [
                "L1_RES1"
            ],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 120,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Wafa Badreddine",
                    "Gil Utard"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "10h de TD sont sur machine"
            ],
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 3,
            "ID": "L2_PROGF",
            "TITRE": "PROGRAMMATION FONCTIONNELLE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "OBJECTIFS": [
                "Connaitre les bases de la programmation fonctionnelle",
                "&Eacute;crire des programmes dans un langage de programmation fonctionnelle"
            ],
            "CONTENU": [
                "Fonctions, fonctions récursives, composition de fonctions",
                "Type, inférence de type",
                "Types construits : types récursifs, types paramétrés",
                "Filtrage, gardes",
                "Portée des expressions",
                "Structures de données : exemple liste, arbres",
                "Gestion des exceptions",
                "Polymorphisme",
                "Applications en CAML ou Haskell"
            ],
            "PREREQUIS": [
                "L2_STLIN"
            ],
            "CM": 8,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 120,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Pascal Vasseur"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "10h de TD sont sur machine"
            ],
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 4,
            "ID": "L2_MATH3",
            "TITRE": "OUTILS MATH 3",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "INFO",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Notion de groupe : groupes de permutations, groupes sur les nombres (Z, Z/nZ)",
                "Anneau des entiers et des polynômes",
                "Arithmétique modulaire",
                "Application à la cryptologie"
            ],
            "PREREQUIS": ["L1_MATH0"],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 80,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Léo Robert",
                    "Claire Delaplace"
                ],
                "INTERVENANTS": []
            },
            "STYLE": "Maths"
        },
        {
            "SEMESTRE": 4,
            "ID": "L2_COMPT",
            "TITRE": "SYSTEME D'INFORMATION COMPTABLE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "MIAGE",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "L’activité économique et sa représentation comptable : comprendre les flux économiques, représenter les flux sous forme comptable, enregistrer les opérations courantes, comprendre le  fonctionnement des comptes",
                "Des comptes à la balance : organiser la comptabilité, codifier les informations, contrôler par la balance",
                "De la balance au bilan et au compte de résultat : comprendre le bilan et le résultat, de la balance au bilan et au résultat, lire le compte de résultat, lire le bilan",
                "L’inventaire et la variation des stocks",
                "L’amortissement des immobilisations : comprendre l’amortissement, enregistrer les amortissements, calculer un amortissement, l’amortissement et les documents de synthèse",
                "Les provisions : comprendre les provisions, calculer une provision pour dépréciation d’actif, enregistrer une provision pour dépréciation d’actif, inscrire une provision au bilan et au résultat"
            ],
            "PREREQUIS": [
                "L2_GESTI"
            ],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 40,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Gestion"
        },
        {
            "SEMESTRE": 4,
            "ID": "L2_TRAN4",
            "TITRE": "TRANSVERSE S4",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [
                "Anglais, communication, outils numériques, formation professionnelle"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 120,
            "GROUPES_CM": 0,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Transverse",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "L3_LF2",
            "TITRE": "LANGAGES FORMELS 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Langages non reconnaissables",
                "Notions de grammaires et de langages algébriques",
                "Analyse lexicale, analyse syntaxique, analyseur LL, analyseur LR, grammaire LR, SLR",
                "Production du code intermédiaire, production du code, optimisation du code",
                "Mini-projet (ex: développement d'un mini-compilateur avec Flex et Bison)"
            ],
            "PREREQUIS": [
                "L2_LF1"
            ],
            "CM": 8,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 90,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Florence Levé"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "10h de TD sont sur machine"
            ],
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 5,
            "ID": "L3_GRAPH",
            "TITRE": "ALGORITHMIQUE DES GRAPHES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "OBJECTIFS": [
                "Modéliser un problème sous forme de graphes, choisir le type de graphe le plus adapté",
                "Associer à chaque algorithme un problème et/ou un domaine d’application (p. e. points d’articulation et réseaux tolérants aux pannes etc.)",
                "Choisir et mettre en oeuvre l'algorithme de graphe le plus adapté à un problème donné, en tenant compte de son efficacité",
                "Implémenter un graphe de différentes façons (chainage, matrice) selon le traitement à effectuer"
            ],
            "CONTENU": [
                "Graphes",
                "Parcours d’un graphe, composantes connexes, cycles",
                "Algorithmes classiques de recherche du plus court chemin dans un graphe",
                "Arbre couvrant de coût minimum,  réalisation d’un réseau connexe à coût minimum",
                "Couplage maximum et problèmes d’affectation des tâches",
                "Implémentations des graphes"
            ],
            "PREREQUIS": [
                "L2_ARBRE"
            ],
            "CM": 18,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 90,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Alain Cournier"
                ],
                "INTERVENANTS": [
                    "Leo Robert"
                ]
            },
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 5,
            "ID": "L3_CONSI",
            "TITRE": "ANALYSE ET CONCEPTION DES SYSTEMES D'INFORMATION",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C2"
                }
            ],
            "OBJECTIFS": [
                "Analyser et identifier les besoins des utilisateurs",
                "Modéliser l'existant",
                "Identifier les fonctionalités d'un SI",
                "Réaliser une maquette fonctionnelle",
                "Choisir une architecture de SI adaptée à des besoins",
                "Concevoir le déploiement d'un SI sur une infrastructure",
                "Rédiger un cahier des charges",
                "Planifier un projet"
            ],
            "CONTENU": [],
            "PREREQUIS": [
                "L2_POO1"
            ],
            "CM": 10,
            "TD": 40,
            "TP": 0,
            "EFFECTIF": 90,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Catherine Barry",
                    "Anne Lapujade"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "TD sur machine"
            ],
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 5,
            "ID": "L3_BDS5",
            "TITRE": "DONNEES MASSIVES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "MIAGE",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                },
                {
                    "PARCOURS": "INFO",
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "OBJECTIFS": [
                "Extraire, manipuler et visualiser des données structurées ou semi-structurées",
                "Elaborer un modèle de document NoSQL"
            ],
            "CONTENU": [
                "Compréhension des paradigmes du Big Data",
                "Formats de données semi-structurés (XML, JSON, ...)",
                "Visualisation de données (temporelles, spatiales, graphes, ...)",
                "Utilisation de librairies dataviz (matplotlib, ...)"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 8,
            "TP": 12,
            "EFFECTIF": 60,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Florence Levé"
                ],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 6,
            "ID": "L3_ROBOT",
            "TITRE": "ROBOTIQUE, IMAGE ET REALITE VIRTUELLE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "C1",
                    "PARCOURS": "INFO"
                }
            ],
            "OBJECTIFS": [
                "Développer et mettre au point des programmes s'appuyant sur ROS2 et Docker",
                "Etalonner une caméra et modéliser des transformations géométriques rigides nécessaires à une application spécifique",
                "Programmer des robots (bras industriel/quadrupède mobile) : acquisition des données depuis les capteurs, déplacements, adaptation à l'environnement",
                "Planifier un projet"
            ],
            "CONTENU": [
                "Topologie d'un robot (articulations, locomotion) et technologies des capteurs (caméra, lidar, télémètre infrarouge)",
                "Calcul matriciel, coordonnées homogènes",
                "Construction d'une image (géométrie), homographie, calcul de pose, transformations géométriques rigides",
                "Utilisation de ROS2 (nodes, topics, actions), communication réseau au format Publish-subscribe et notion de système temps réel"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 20,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Pascal Vasseur",
                    "Jordan Caracotte"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "16h de TD sont sur machine"
            ],
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 5,
            "ID": "L3_CRYPT",
            "TITRE": "CRYPTOLOGIE ET SECURITE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "INFO",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                },
                {
                    "PARCOURS": "MIAGE",
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Cryptologie : bases mathématiques pour la sécurité de l’information, ordre de grandeur, fonctions à sens unique, arbres de Merkle, preuve de travail, compréhension et usage des Blockchains"
            ],
            "PREREQUIS": [
                "L2_ARBRE"
            ],
            "CM": 8,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Léo Robert",
                    "Claire Delaplace"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "8h de TD sont sur machine"
            ],
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 6,
            "ID": "L3_RECH",
            "TITRE": "INITIATION A LA RECHERCHE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "OBJECTIFS": [
                "Reconnaître un article scientifique, faire un état de l’art",
                "Identifier une problématique scientifique",
                "Concevoir une expérimentation simple, évaluer des résultats",
                "Rédiger un rapport scientifique (avec un outil de type latex)"
            ],
            "CONTENU": [
                "Fonctionnement et métiers de la recherche",
                "Types de publications scientifiques, structure d’un article",
                "Démarche scientifique",
                "Outils de la recherche scientifique"
            ],
            "PREREQUIS": [],
            "CM": 8,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 90,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Florence Levé"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "10h de TD sont sur machine"
            ],
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 5,
            "ID": "L3_POO2",
            "TITRE": "PROGRAMMATION OBJET 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "MIAGE",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                },
                {
                    "PARCOURS": "INFO",
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Approfondissement de la notion d'abstraction",
                "Bonnes pratiques en POO : principes SOLID, notion de pattern",
                "Programmation en C#"
            ],
            "PREREQUIS": ["L2_POO1"],
            "CM": 8,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 60,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Anne Lapujade"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "22h de TD sont sur machine"
            ],
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 5,
            "ID": "L3_ALGOAV",
            "TITRE": "ALGORITHMIQUE AVANCEE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "INFO",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                },
                {
                    "PARCOURS": "MIAGE",
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Algorithmes de tri efficaces : tri par tas, tri linéaire (dénombrement, radix), tri fusion, quicksort",
                "Recherche de motifs dans un texte : algorithme naïf, Rabin-Karp, Knuth-Morris-Pratt",
                "Géométrie algorithmique : calcul de l’enveloppe convexe, recherche des deux points les plus proches, triangulation de Delaunay, plus petit cercle englobant",
                "Notions transversales : complexité en moyenne vs dans le pire des cas, paradigme diviser pour régner, complexité en espace vs en temps, programmation dynamique, analyse amortie..."
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 75,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Claire Delaplace",
                    "Yoann Dieudonné"
                ],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 6,
            "ID": "L3_RESAV",
            "TITRE": "RESEAU AVANCE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "INFO",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Sécurité des réseaux : VPN, pare-feu, ACL, IDS/IPS",
                "VLAN et segmentation des réseaux",
                "Routage avancé : redistribution, haute disponibilité",
                "Supervision et monitoring (SNMP, Syslog, IPFIX)"
            ],
            "PREREQUIS": [
                "L2_RES2"
            ],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 60,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Wafa Badreddine"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "10h de TD sont sur machine"
            ],
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 5,
            "ID": "L3_FINAN",
            "TITRE": "SI FINANCIER",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "MIAGE",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Retraitement du bilan",
                "Analyse de l’entreprise à partir des SIG",
                "Tableaux des  flux de trésorerie",
                "Interprétation des résultats"
            ],
            "PREREQUIS": [
                "L2_COMPT"
            ],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 30,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Gestion"
        },
        {
            "SEMESTRE": 5,
            "ID": "L3_TRAN5",
            "TITRE": "TRANSVERSE S5",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "CT"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Anglais, communication, outils numériques, formation professionnelle"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 100,
            "GROUPES_CM": 0,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Transverse"
        },
        {
            "SEMESTRE": 6,
            "ID": "L3_DEVSI",
            "TITRE": "DEVELOPPEMENT DES SYSTEMES D'INFORMATION",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C2"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Découverte et apprentissage du Framework .NET 9, notamment Entity Framework et pattern MVVM",
                "Utilisation d'un environnement de développement (Visual Studio ou Rider) pour l'écriture de code, notamment utilisation du debugger",
                "Utilisation de GIT/GitHub en version simplifiée (commit, push, pull)",
                "Pratique des tests : tests fonctionnels, tests unitaires et d'intégration",
                "Utilisation d'un outil de planification de projet simple (comme Trello) pour le suivi de l'avancement du projet"
            ],
            "PREREQUIS": [
                "L3_CONSI"
            ],
            "CM": 8,
            "TD": 42,
            "TP": 0,
            "EFFECTIF": 90,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Catherine Barry",
                    "Anne Lapujade"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "TD sur machine"
            ],
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 6,
            "ID": "L3_IA",
            "TITRE": "INTELLIGENCE ARTIFICIELLE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C2"
                }
            ],
            "OBJECTIFS": [
                "Choisir un modèle et une méthode d'apprentissage en fonction des données à traiter",
                "Concevoir et paramétrer un réseau de neurones",
                "Evaluer quantitativement un modèle d'apprentissage"
            ],
            "CONTENU": [
                "Apprentissage par renforcement : bandit manchot, processus de Markov",
                "Apprentissage automatique : régression linéaire, arbre de décision, réseaux de neurones"
            ],
            "PREREQUIS": [
                "L2_ARBRE",
                "L1_MATH0",
                "L1_MATH1",
                "L1_PROBA"
            ],
            "CM": 12,
            "TD": 28,
            "TP": 0,
            "EFFECTIF": 90,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Rui Shibasaki"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "14h de TD sont sur machine"
            ],
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 6,
            "ID": "L3_MODEL",
            "TITRE": "MODELES DE CALCUL",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Ensembles énumérables, récursivement énumérables",
                "Présentation de modèles (tant que, primitives récursives)",
                "Transformer un algorithme récursif en itératif et vice versa",
                "Thèse de Church",
                "Présentation de problèmes semi indécidables (problème de l'arrêt)"
            ],
            "PREREQUIS": [
                "L2_ARBRE"
            ],
            "CM": 14,
            "TD": 16,
            "TP": 0,
            "EFFECTIF": 90,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Alain Cournier"
                ],
                "INTERVENANTS": [
                    "Stéphane Desvismes"
                ]
            },
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 6,
            "ID": "L3_MQD",
            "TITRE": "METHODES QUANTITATIVES ET DECISION",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "MIAGE",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                },
                {
                    "PARCOURS": "INFO",
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "OBJECTIFS": [
                "Modéliser un problème de planification ou d'ordonnancement",
                "Mettre en oeuvre l'algorithme du simplexe"
            ],
            "CONTENU": [
                "Objectif des méthodes quantitatives et décision (MQD)",
                "Les étapes d'un projet en MQD : problèmes d’ordonnancement et de planification de tâches dans un réseau informatique",
                "Modélisation par quantification (ordonnancement de tâches, production, gestion de stock)",
                "Résolution géométrique de l’ordonnancement et de la planification de tâches",
                "Différentes formes d'un modèle quantifié (forme générale, forme canonique d'un modèle, forme standard)",
                "Base, solution de base d'un modèle quantifié, optimalité",
                "Phase II primale du simplexe (démarrage de la méthode, résolution par points extrêmes)",
                "&Eacute;quivalence de modèles quantifiés et interprétation géométrique"
            ],
            "PREREQUIS": [
                "L2_ARBRE",
                "L2_MATH2"
            ],
            "CM": 12,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 50,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Mhand Hifi"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "4h de TD sont sur machine"
            ],
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 5,
            "ID": "L3_SEAV",
            "TITRE": "SYSTEME D'EXPLOITATION AVANCE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "INFO",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Programmation concurrente",
                "Ordonnancement",
                "Mémoire : segmentation, pagination, mémoire virtuelle, algorithme de pagination etc",
                "Structure d'un OS"
            ],
            "PREREQUIS": [
                "L2_SE2"
            ],
            "CM": 8,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 60,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Gil Utard"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "10h de TD sont sur machine"
            ],
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 6,
            "ID": "L3_PPD",
            "TITRE": "PROGRAMMATION PARALLELE ET DISTRIBUEE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "optionnel",
                    "ECTS": 3,
                    "BLOCS": "C1",
                    "PARCOURS": "INFO"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Parallélisme : algorithmes dans le modèle PRAM, introduction à d'autres modèles (CGM par exemple)",
                "Algorithmique distribué : présentation du modèle à passage de messages, algorithmes distribués pour des taches fondamentales (diffusion, exclusion mutuelle, routage)"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 20,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Stéphane Desvismes",
                    "Yoann Dieudonné"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "8h de TD sont sur machine"
            ],
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 6,
            "ID": "L3_STAGE",
            "TITRE": "STAGE",
            "TYPE": "STAGE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Minimum 8 semaines, une soutenance et un mini-rapport"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 90,
            "GROUPES_CM": 0,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique"
        },
        {
            "SEMESTRE": 6,
            "ID": "L3_MANAG",
            "TITRE": "MANAGEMENT DES SYSTEMES D'INFORMATION",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "PARCOURS": "MIAGE",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Concepts fondamentaux, management des SI et société, questions organisationnelles",
                "Thématiques stratégiques fondamentales",
                "Management de projet SI (aspects non-techniques)",
                "Questions économiques et financières en SI"
            ],
            "PREREQUIS": [
                "L3_FINAN"
            ],
            "CM": 16,
            "TD": 14,
            "TP": 0,
            "EFFECTIF": 30,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Emmanuel Ruzé"
                ],
                "INTERVENANTS": []
            },
            "STYLE": "Gestion"
        },
        {
            "SEMESTRE": 6,
            "ID": "L3_TRAN6",
            "TITRE": "TRANSVERSE S6",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "CT"
                }
            ],
            "OBJECTIFS": [],
            "CONTENU": [
                "Anglais, communication, outils numériques, formation professionnelle"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 100,
            "GROUPES_CM": 0,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Transverse"
        }
    ]
})