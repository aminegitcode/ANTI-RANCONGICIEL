addMaquette({
    "FORMATION": {
        "NOM": "Licence eMIAGE - 2026",
        "ETABLISSEMENT": "Université de Picardie - Jules Verne",
        "ANNEES": "2026/27",
        "NB_SEMESTRES": 6,
        "LMD": "L",
        "PARCOURS": [],
        "BLOCS": [
            {
                "NOM": "INFORMATIQUE",
                "DESCRIPTION": "Informatiques",
                "ID": "INFO"
            },
            {
                "NOM": "PARCOURS",
                "DESCRIPTION": "Organisation gestion",
                "ID": "GC"
            },
            {
                "NOM": "PP",
                "DESCRIPTION": "Professionnalisation",
                "ID": "PP"
            },
            {
                "NOM": "CT",
                "DESCRIPTION": "Transverse",
                "ID": "CT"
            }
        ],
        "RESPONSABLES": [],
        "M3C": [],
        "PRESENTATION": []
    },
    "MODULES": [
        {
            "SEMESTRE": [
                5,
                6
            ],
            "ID": "B210",
            "TITRE": "BASES DE DONNEES RELATIONNELLES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "INFO"
                }
            ],
            "CONTENU": [
                "Savoir concevoir et mettre en œuvre une base de données relationnelle",
                "Concevoir des systèmes complexes et conduire des projets collaboratifs"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 40,
            "TP": 0,
            "EFFECTIF": 14,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Laure Brisoux"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "commun L3 MIAGE"
            ],
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                5,
                6
            ],
            "ID": "B211",
            "TITRE": "PROGRAMMATION OBJET",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "INFO"
                }
            ],
            "CONTENU": [
                "Connaître les mécanismes de la programmation objet",
                "Résoudre des problèmes complexes en mobilisant les concepts fondamentaux de l'informatique"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 40,
            "TP": 0,
            "EFFECTIF": 9,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Sébastien Choplin"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "commun L3 MIAGE"
            ],
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                5,
                6
            ],
            "ID": "B213",
            "TITRE": "PROJET",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 9,
                    "BLOCS": "INFO"
                }
            ],
            "CONTENU": [
                "Mettre en pratique les mécanismes de l'approche objet",
                "Concevoir des systèmes complexes et conduire des projets collaboratifs"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 40,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Pierre-Yves Aillet"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                5,
                6
            ],
            "ID": "B222",
            "TITRE": "RESEAUX",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "INFO"
                }
            ],
            "CONTENU": [
                "Connaitre les bases du réseau"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 40,
            "TP": 0,
            "EFFECTIF": 12,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Sébastien Choplin"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                5,
                6
            ],
            "ID": "B350",
            "TITRE": "MODELISATION OBJET POUR LA CONCEPTION DES SYSTEMES D'INFORMATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "INFO"
                }
            ],
            "CONTENU": [
                "Maitriser l'approche objet en utilisant UML",
                "Résoudre des problèmes complexes en mobilisant les concepts fondamentaux de l'informatique"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 40,
            "TP": 0,
            "EFFECTIF": 12,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Anne Lapujade",
                    "Catherine Barry"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "commun L3 MIAGE"
            ],
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                5,
                6
            ],
            "ID": "DM",
            "TITRE": "DONNEES MASSIVES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "INFO"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 40,
            "TP": 0,
            "EFFECTIF": 11,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Florence Levé"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "commun L3 MIAGE"
            ],
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                5,
                6
            ],
            "ID": "C237",
            "TITRE": "FRAMEWORKS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "INFO"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 40,
            "TP": 0,
            "EFFECTIF": 1,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Nicolas Royackkers"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                5,
                6
            ],
            "ID": "C241",
            "TITRE": "PROGRAMMATION WEB",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "INFO"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 40,
            "TP": 0,
            "EFFECTIF": 11,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Nicolas Royackkers"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                5,
                6
            ],
            "ID": "A110",
            "TITRE": "MATHEMATIQUES FINANCIERES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "GC"
                }
            ],
            "CONTENU": [
                "Acquérir les bases du calcul financier",
                "Comprendre et interpréter les résultats des traitements"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 40,
            "TP": 0,
            "EFFECTIF": 1,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Dép. Mathématiques",
                "RESPONSABLES": [
                    "Stéphane Ducay"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                5,
                6
            ],
            "ID": "B406",
            "TITRE": "GESTION DES RESSOURCES HUMAINES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "GC",
                    "CHOIX": [
                        6,
                        [
                            "B406",
                            "B420",
                            "B421"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 40,
            "TP": 0,
            "EFFECTIF": 2,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Nadia Ghaddab"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                5,
                6
            ],
            "ID": "B420",
            "TITRE": "CONNAISSANCE DE L'ENTREPRISE 1",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "GC",
                    "CHOIX": [
                        6,
                        [
                            "B406",
                            "B420",
                            "B421"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Qu'est ce qu'une entreprise ?"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 4,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Marie Catalo"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                5,
                6
            ],
            "ID": "B421",
            "TITRE": "CONNAISSANCE DE L'ENTREPRISE 2",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "GC",
                    "CHOIX": [
                        6,
                        [
                            "B406",
                            "B420",
                            "B421"
                        ]
                    ]
                }
            ],
            "CONTENU": [
                "Fonctionnement de l'entreprise"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 23,
            "TP": 0,
            "EFFECTIF": 9,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "Vacataire",
                "RESPONSABLES": [
                    "Marie Catalo"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                5,
                6
            ],
            "ID": "B504",
            "TITRE": "ANGLAIS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [
                "Savoir comprendre oralement et à l'écrit des documents de difficulté modérée, s'exprimer oralement et à l'écrit"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 40,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 10,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESERVE": "PRAG",
                "RESPONSABLES": [
                    "Stéphanie Portemer"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "commun L3 MIAGE"
            ],
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                5,
                6
            ],
            "ID": "B509",
            "TITRE": "INITIATION A LA RECHERCHE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [
                "Savoir effectuer un travail de recherche documentaire, d’études et de synthèse"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 40,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Dominique Groux"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "commun L3 MIAGE"
            ],
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                5,
                6
            ],
            "ID": "B602",
            "TITRE": "STAGE PROFESSIONNEL",
            "TYPE": "STAGE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 15,
                    "BLOCS": "PP"
                }
            ],
            "CONTENU": [
                "Découvrir le monde de l'entreprise"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 11,
            "TP": 0,
            "EFFECTIF": 3,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Catherine Barry"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "commun L3 MIAGE"
            ],
            "OBJECTIFS": []
        }
    ]
})