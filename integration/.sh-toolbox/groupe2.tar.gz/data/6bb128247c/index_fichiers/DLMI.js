addMaquette({
    "FORMATION": {
        "NOM": "Double licence Math - Info",
        "ETABLISSEMENT": "Université de Picardie - Jules Verne",
        "ANNEES": "2026",
        "NB_SEMESTRES": 6,
        "LMD": "L",
        "PARCOURS": [],
        "M3C": [
            "Un module est validé si sa note est supérieure ou égale à 10",
            "Un bloc de compétences est validé si la moyenne pondérée des modules du bloc est supérieure ou égale à 10",
            "Si un bloc de compétence est validé, tous les modules du bloc le sont et ne peuvent être repassés",
            "Une année est validée si tous les blocs de compétences de l'année le sont ou si la moyenne pondérée des blocs est supérieure ou égale à 10 avec au moins 8 dans chaque bloc",
            "Un étudiant est AJAC (ajourné autorisé à continuer) s'il n'a pas validé son année mais a validé au moins 45 ECTS",
            "La licence est obtenue quand les 3 années sont validées"
        ],
        "BLOCS": [
            {
                "NOM": "C1",
                "DESCRIPTION": "",
                "ID": "C1"
            },
            {
                "NOM": "C2",
                "DESCRIPTION": "",
                "ID": "C2"
            },
            {
                "NOM": "C3",
                "DESCRIPTION": "Concevoir son projet professionnel",
                "ID": "C3"
            }
        ],
        "RESPONSABLES": [],
        "PRESENTATION": []
    },
    "MODULES": [
        {
            "SEMESTRE": 1,
            "ID": "RESTF01",
            "TITRE": "STRUCTURES FONDAMENTALES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Langage du calcul propositionnel (négation, connecteurs logiques, quantificateurs) et de la théorie naïve des ensembles (inclusion, intersection, réunion, complémentaire, produit, applications, injectivité, surjectivité, bijectivité, relations d'équivalence et d'ordre)",
                "Groupe des permutations (cardinalité, ordre d'un élément, transposition, cycle, parties génératrices, signature) et groupe des restes modulo n (structure, congruence, ordre d'un élément, groupe, sous-groupe)",
                "Anneau des entiers (division euclidienne, divisibilité, éléments irréductibles, décomposition en facteurs premiers, ppcm, pgcd et algorithme d'Euclide)",
                "Anneau des polynômes à coefficients réels ou complexes (racines et multiplicité, division euclidienne, divisibilité, décomposition en polynômes irréductibles, ppcm, pgcd et algorithme d'Euclide, théorème de Bézout)",
                "Anneau des restes modulo n (inversibilité, lemme chinois, exemples simples d'équations diophantiennes)",
                "Corps des nombres réels. Partie entière, densité des rationnels et irrationnels",
                "Suites de nombres réels et complexes (monotonie, arithmétique, géométrique, somme des premiers termes). Bornes supérieure et inférieure, limites supérieure et inférieure. Caractérisation des limites de suites. Critère de Cauchy, théorème de Bolzano-Weierstrass"
            ],
            "PREREQUIS": [],
            "CM": 18,
            "TD": 28,
            "TP": 0,
            "EFFECTIF": 96,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Maths",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "RECAM01",
            "TITRE": "ALGEBRE LINEAIRE 1.1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Nombres complexes : représentations d’un nombre complexe : conjugué, module, argument. Exponentielle complexe. Forme d’Euler, de Moivre",
                "Racines n-ièmes d’un nombre complexe. Applications à la trigonométrie",
                "Systèmes d’équations linéaires, méthode du pivot de Gauss, rang. On traitera divers exemples d'application aux sciences (électricité, biologie,...)",
                "Calcul matriciel (somme produit, transposée, inverse)",
                "Exemples d’utilisation issus de la géométrie : Equations de droite ou de plan, intersection; produit scalaire, transformations géométriques, changement de repère (cas orthonormé), exemple des coordonnées polaires, cylindriques, sphériques",
                "Notions élémentaires sur le déterminant d’une matrice : méthodes de calcul pour les déterminants 2x2 et 3x3, interprétation géométrique, applications",
                "Formules de Cramer 2x2 et 3x3. Produit mixte et produit vectoriel dans R3",
                "Espaces vectoriels sur le corps des nombres réels: Sous-espace, espace engendré par une partie, somme d’espaces vectoriels, somme directe, sous-espace supplémentaire. Base, dimension"
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 95,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Maths",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UEmath1.1",
            "TITRE": "ANALYSE 1.1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Fonctions usuelles (logarithme, exponentielles, fonctions puissances, fonctions trigonométriques). Limites et comportement asymptotique, croissances comparées",
                "Suites numériques (monotonie, arithmétique, géométrique, somme des premiers termes)",
                "Continuité, dérivabilité d’une fonction numérique. Tangente, convexité, inflexion. Calcul pratique des dérivées partielles (deux ou trois variables, pas de continuité des fonctions de plusieurs variables), utilisation pour les extrema de fonctions de deux variables",
                "Compléments sur les calculs de primitives et leur application au calcul d’intégrales : Intégration par partie, changement de variables, fractions rationnelles (cas simples)",
                "&Eacute;quations différentielles linéaires du premier ordre, méthode de la variation de la constante, équations différentielles linéaires du second ordre à coefficients constants. Image d’un intervalle [a,b] par une fonction continue réelle (admis). Egalité et inégalité des accroissements finis (pourra être admis)"
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Maths",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "THEGRA",
            "TITRE": "THEORIE DES GRAPHES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Matrices d’adjacence",
                "Nombre de chemin de longueur n",
                "Composantes connexes, chaînes, cycles",
                "Graphes orientés, non orientés, eulériens, hamiltoniens. théorèmes d'Euler, Kuratowski",
                "Graphes planaires. Formule d'Euler",
                "Problèmes de colorations des sommets, des arêtes (théorèmes de Vizing, König,...)",
                "Nombre chromatique, polynôme chromatique",
                "Théorème des 5 couleurs"
            ],
            "PREREQUIS": [],
            "CM": 16,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 20,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Maths",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "REBAP01",
            "TITRE": "ALGORITHMIQUE 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Algorithmique : notion de problème (données, résultats) et d'algorithmes pour le résoudre",
                "Structure de données (tableau à plusieurs dimensions)",
                "Etude d’un tri (tri par sélection)",
                "Variables, types (entier, réel, chaîne, booléen), expressions, affectations, éléments de logique",
                "Instructions, instructions conditionnelles, instructions répétitives (boucle avec ou sans compteur), indentation",
                "Programmes, sous-programmes, fonctions, passage de paramètres",
                "TPs : connaissances de bases d'un système de fichiers (répertoires ou dossiers, fichiers, création, déplacement, copier-coller...), programmation en langage C (compilation, exécution, débogage)",
                "Connaitre et maitriser les techniques de bases de l'algorithmique et de la programmation  (Structure conditionnelle, structure répétitive, tableaux, fonctions)",
                "Mettre en œuvre correctement un algorithme répondant à un problème simple"
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 24,
            "TP": 20,
            "EFFECTIF": 59,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 8,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UEinfo1.2",
            "TITRE": "REPRESENTATION DE L'INFORMATION",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Rappel de Numération : les différentes bases utilisées en Informatique, algorithmes de conversion",
                "Représentation d'informations : les chiffres, caractères, les entiers, entiers signés, les fractionnaires en virgule fixe (signé ou non), les fractionnaires en virgule flottante",
                "Opérations sur les nombres (entiers et réels) : rappel des algorithmes opératoires, identification de la véracité des résultats",
                "Encodage des caractères (ASCII, Unicode, ..)",
                "Codage des couleurs et des images",
                "Notion de compression de données",
                "Manipulation des fichiers et notion de flux",
                "Fichier texte, image",
                "Maitriser l'encodage numérique de l'information",
                "Identifier les limites des codages et de leurs opérations",
                "Utiliser des fichiers dans un programme"
            ],
            "PREREQUIS": [],
            "CM": 8,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 250,
            "GROUPES_CM": 1,
            "GROUPES_TD": 7,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "NOTES": [
                "10h de TD sont sur machine à 25 étudiants/groupe"
            ],
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "UEinfo1.3",
            "TITRE": "SYSTEME D'EXPLOITATION 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Terminologie / principes généraux",
                "Système de Fichiers",
                "Maîtrise du terminal (variables d’environnement, IO standard)",
                "Permissions, processus/jobs"
            ],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 14,
            "TP": 10,
            "EFFECTIF": 250,
            "GROUPES_CM": 1,
            "GROUPES_TD": 7,
            "GROUPES_TP": 14,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "SAE1",
            "TITRE": "SAE S1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Etude et recherche sur un projet d'informatique ou de mathématiques"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "CT1",
            "TITRE": "TRANSVERSE S1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Anglais ..."
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Transverse",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "REARF02",
            "TITRE": "ANALYSE 1.2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 9,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Fonctions numériques (à valeurs réelles et complexes) de la variable réelle : limite d’une fonction en un point, continuité, valeurs intermédiaires, image d’un intervalle, suites de fonctions, convergence point par point",
                "Dérivabilité, égalité et inégalité des accroissements finis, cas des fonctions à valeurs complexes",
                "Intégrale définie (fonctions continues par morceaux), convergence des sommes de Riemann, théorème fondamental de l’Analyse",
                "Savoir restituer et utiliser les résultats et raisonnements fondamentaux d’Analyse",
                "Savoir majorer ou minorer une fonction, ou une intégrale"
            ],
            "PREREQUIS": [],
            "CM": 28,
            "TD": 40,
            "TP": 0,
            "EFFECTIF": 105,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Maths",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "REPRS02",
            "TITRE": "PROBABILITES ET STATISTIQUES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Vocabulaire de la statistique. Statistique descriptive à une et deux variables : représentations graphiques, paramètre de position et de dispersion. Droite de régression des moindres carrés",
                "Introduction au calcul des probabilités. Probabilité conditionnelle. Indépendance",
                "Notions de variables aléatoires réelles discrètes et à densité. Moments. Lois usuelles (dont Binomiale, Poisson, Normale). Approximation de la Binomiale par la Normale, théorème central-limite."
            ],
            "PREREQUIS": [],
            "CM": 8,
            "TD": 16,
            "TP": 0,
            "EFFECTIF": 93,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Maths",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "REALL02",
            "TITRE": "ALGEBRE LINEAIRE 1.2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Applications linéaires sur R ou C : images, noyau, espace vectoriel des applications linéaires, endomorphismes linéaires, forme linéaire.",
                "Matrices : définition, sommes et produits de matrice. Espace vectoriel des matrices. Groupe des matrices inversibles. Matrices transposée.",
                "Matrice d’une application linéaire relativement à des bases données.  Matrice d’un endomorphisme. Changement de bases. Matrice de passage. Trace d’un endomorphisme et d’une matrice carrée. Rang d’une matrice. Matrices équivalentes. Matrices semblables.",
                "Matrices de projections, de rotations, de symétries."
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Maths",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.1",
            "TITRE": "ALGORITHMIQUE 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Rappels des notions algorithmiques vues en S1 et retour sur les tableaux, introduction des tableaux multidimensionnels",
                "Algorithmes de recherche (séquentielle / dichotomique / par interpolation)",
                "Algorithmes de tris quadratiques (bulle / sélection / insertion)",
                "Types énumérés et enregistrements",
                "Pointeurs et retour sur les passages de paramètres des fonctions/procédures"
            ],
            "PREREQUIS": [],
            "CM": 8,
            "TD": 12,
            "TP": 10,
            "EFFECTIF": 250,
            "GROUPES_CM": 1,
            "GROUPES_TD": 7,
            "GROUPES_TP": 14,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.10",
            "TITRE": "BASES DE DONNEES 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Introduction aux Systèmes d'Information",
                "Introduction et utilisation d'un Système de Gestion de Bases de Données",
                "Langage SQL (partie DML) et algèbre relationnelle",
                "Modèle E/A étendu",
                "Les règles de transformation du modèle E/A étendu vers le modèle relationnel",
                "Approfondissement du langage SQL : mise en œuvre de requêtes plus complexes à l’aide des fonctions agrégatives",
                "Optimisation algébrique et sous SQL des requêtes",
                "Présentation et justification de la classification des relations sous formes normales",
                "Algorithme de  décomposition des relations"
            ],
            "PREREQUIS": [],
            "CM": 8,
            "TD": 12,
            "TP": 10,
            "EFFECTIF": 250,
            "GROUPES_CM": 1,
            "GROUPES_TD": 7,
            "GROUPES_TP": 14,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.2",
            "TITRE": "LOGIQUE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "&Eacuteléments d'histoire et définitions de notions générales, liens avec l'informatique",
                "La logique propositionnelle : définition en tant que langage. Opérateurs logiques et formules. Tautologies. Fonctions booléennes et puissance expressive du langage de logique propositionnelle",
                "La logique du premier ordre : prédicats et fonctions, quantificateurs, occurrences de variables libres / liées. Définition en tant que langage. Interprétations, évaluations, modèles",
                "Les notions basiques de théories formelles : axiomes, règles de déduction, preuve, théorèmes",
                "Styles de preuve : directe, par l'absurde, induction (au travers d’exemples)",
                "Savoir écrire une formule logique",
                "&Ecirc;tre capable de déterminer si un raisonnement est correct ou non",
                "Savoir modéliser un problème en utilisant un formalisme logique",
                "&Ecirc;tre capable d'écrire une preuve rigoureuse"
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 250,
            "GROUPES_CM": 1,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "partiel et examen, max(examen,(partiel+examen)/2)",
                "SECONDE_CHANCE": "examen",
                "SESSION_2": "seconde chance"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Stéphane Desvismes"
                ],
                "INTERVENANTS": [
                    "Sami Cherif",
                    "Léo Robert"
                ]
            },
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.5",
            "TITRE": "WEB 1",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Généralités sur le Web : URL, HTTP(S), client/serveur, navigateur",
                "HTML et CSS",
                "Manipulation du DOM",
                "Programmation côté client en Javascript",
                "Programmation événementielle",
                "Structurer une page Web de façon sémantique en dissociant contenu et forme",
                "Rendre une page Web dynamique en manipulant le DOM",
                "Développer une interface Web côté client en HTML/CSS/JS"
            ],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 250,
            "GROUPES_CM": 1,
            "GROUPES_TD": 10,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "non",
                "SESSION_2": "non"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Frédéric Fürst"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "les 24h de TD sont sur machine à 25 étudiants/groupe"
            ],
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "UEinfo2.4",
            "TITRE": "RESEAU 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Modèles en couches (OSI, TCP/IP)",
                "Adressage IPv4 : adresses IP, masque, sous-réseaux",
                "Protocoles de base (ARP, ICMP, DHCP, HTTP…)",
                "Notions de client-serveur",
                "Équipements réseaux (switch, routeur)",
                "Réseaux LAN / WAN et topologies courantes"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 10,
            "TP": 10,
            "EFFECTIF": 250,
            "GROUPES_CM": 1,
            "GROUPES_TD": 7,
            "GROUPES_TP": 14,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "SAE2",
            "TITRE": "SAE S2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Etude et recherche sur un projet d'informatique ou de mathématiques"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "ct2",
            "TITRE": "TRANSVERSE S2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Anglais ..."
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 4,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Transverse",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "RESSF03",
            "TITRE": "EVN,  SUITES ET SERIES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 9,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Rappel sur les séries numériques.",
                "Suites de fonctions. (Fonctions définies sur R à valeurs réelles ou complexes)",
                "Convergence simple, uniforme, critère de Cauchy uniforme. Propriétés de la limite d’une suite de fonctions : Théorème de continuité, interversion de limites, intégrabilité, dérivabilité.",
                "Séries de fonctions. (Fonctions définies sur R à valeurs réelles ou complexes)",
                "Convergence simple, uniforme, critère de Cauchy uniforme. Convergence normale. Propriétés de la somme : continuité, limite en un point, intégrabilité, dérivabilité.",
                "Séries entières. Exemples classiques. Rayon de convergence, définition, détermination pratique.",
                "Propriétés de la convergence sur le disque de convergence. Opérations algébriques sur les séries entières. Dérivabilité, intégrabilité de la somme d’une série entière. Fonctions analytiques, propriétés. Fonctions analytiques usuelles. Applications à la résolution d’équations différentielles usuelles.",
                "Séries de Fourier : une introduction."
            ],
            "PREREQUIS": [],
            "CM": 30,
            "TD": 46,
            "TP": 0,
            "EFFECTIF": 51,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Maths",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "RETOP03",
            "TITRE": "ARITHMETIQUE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Arithmétique de Z. Sous-groupes de Z, divisibilité, division euclidienne, lemme de Gauss, pgcd, ppm, théorème de Bézout, algorithme d’Euclide, équation diophantienne ax+by=c, nombres premiers, congruences, l'anneau Z/nZ, caractérisations de éléments inversibles de Z/nZ, indicatrice d’Euler, petit théorème de Fermat, théorème d’Euler, théorème des restes chinois.",
                "Idéaux dans un anneau commutatif, interprétation de la divisibilité en termes d’idéaux de Z. Application à la cryptographie, l'algorithme RSA.",
                "La division euclidienne dans l'algèbre K[X] des polynômes à une variable à coefficients dans un corps K. Règles de calcul dans l’algèbre quotient K[X]/&lt;P&gt;, P un polynôme."
            ],
            "PREREQUIS": [],
            "CM": 16,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 54,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Maths",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "REALL03",
            "TITRE": "ALGEBRE LINEAIRE 2.1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 9,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Applications multilinéaires. Déterminants. Formes n-linéaires alternées. Déterminant de n vecteurs dans une base.",
                "Critère d’indépendance. Déterminants d’un endomorphisme, du composé de deux endomorphismes. Caractérisations des automorphismes.",
                "Déterminant et aire d'un parallélogramme. Déterminant d’une matrice carrée. Mineurs. Cofacteurs. Développement suivant une ligne ou une colonne.",
                "Applications des déterminants. Expression de l’inverse d’une matrice.",
                "Formule de Cramer. Résolution de systèmes linéaires.",
                "Réduction des matrices carrées : Valeurs propres, vecteurs propres d’un endomorphisme et d’une matrice carrée. Sous-espaces propres. Polynôme caractéristique.",
                "Trace d’un endomorphisme. Théorème de Cayley-Hamilton.",
                "Polynôme annulateur. Sous-espaces caractéristiques.",
                "Réduction d’une matrice carrée. Diagonalisation. Trigonalisation",
                "Applications: récurrence linéaire."
            ],
            "PREREQUIS": [],
            "CM": 30,
            "TD": 46,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Maths",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo3.1",
            "TITRE": "STRUCTURES LINEAIRES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Retour sur les algorithmes itératifs et introduction de la notion de récursivité",
                "Notions de piles, files, listes doublement chaînées",
                "Tables de hachage",
                "Introduction aux notions de correction, terminaison et de complexité algorithmique",
                "Retour sur les pointeurs et introduction des listes chaînées"
            ],
            "PREREQUIS": [
                "UEinfo2.1"
            ],
            "CM": 12,
            "TD": 28,
            "TP": 0,
            "EFFECTIF": 120,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo3.2",
            "TITRE": "PROGRAMMATION ET LANGAGE C",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Syntaxe : structures de contrôle, opérateurs et expressions",
                "Types, tableaux et pointeurs, passage de paramètres",
                "Gestion de la mémoire, programmation dynamique et algorithmes génériques",
                "Compilation séparée : pré-processeur, visibilité, édition de liens et atelier de compilation",
                "Librairie standard",
                "Maîtriser les types de données simples et complexes et les fonctions permettant de les manipuler en C",
                "Utiliser les fonctions de la librairie standard",
                "Maîtriser les étapes de la compilation d'un programme, utiliser la compilation séparée",
                "Connaître le fonctionnement du stockage en mémoire des données, utiliser les pointeurs de façon efficace et appropriée",
                "Créer un code clair et modulaire"
            ],
            "PREREQUIS": [
                "UEinfo2.1"
            ],
            "CM": 18,
            "TD": 16,
            "TP": 16,
            "EFFECTIF": 120,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo4.6",
            "TITRE": "PROGRAMMATION FONCTIONNELLE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Fonctions, fonctions récursives, composition de fonctions",
                "Type, inférence de type",
                "Types construits : types récursifs, types paramétrés",
                "Filtrage, gardes",
                "Portée des expressions",
                "Structures de données : exemple liste, arbres",
                "Gestion des exceptions",
                "Polymorphisme",
                "Applications en CAML ou Haskell",
                "Connaitre les bases de la programmation fonctionnelle",
                "&Eacute;crire des programmes dans un langage de programmation fonctionnelle"
            ],
            "PREREQUIS": [],
            "CM": 8,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 100,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "NOTES": [
                "10h de TD sont sur machine"
            ],
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo3.3",
            "TITRE": "BASES DE DONNEES RELATIONNELLES 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Modèle E/A étendu",
                "Les règles de transformation du modèle E/A étendu vers le modèle relationnel",
                "Approfondissement du langage SQL : mise en œuvre de requêtes plus complexes à l’aide des fonctions agrégatives",
                "Optimisation algébrique et sous SQL des requêtes",
                "Présentation et justification de la classification des relations sous formes normales",
                "Algorithme de  décomposition des relations",
                "Être capable de  concevoir et mettre en œuvre un schéma relationnel étendu, concevoir un modèle conceptuel des données",
                "Concevoir des requêtes agrégatives",
                "Concevoir des requêtes efficaces",
                "Rédiger et exécuter des requêtes SQL aggrégatives sur un SGBD relationnel, en manipulations de données (mono-table et multi-table) à partir d’une base existante"
            ],
            "PREREQUIS": [],
            "CM": 16,
            "TD": 20,
            "TP": 12,
            "EFFECTIF": 120,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "UEinfo3.4",
            "TITRE": "SYSTEME D'EXPLOITATION 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Scripts «avancés» : structures de contrôle, etc",
                "Expressions régulières : sed / grep / ...",
                "Introduction à la programmation système (syscalls POSIX)"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 14,
            "TP": 16,
            "EFFECTIF": 120,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "SAE3",
            "TITRE": "SAE S3",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Etude et recherche sur un projet d'informatique ou de mathématiques"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "CT3",
            "TITRE": "TRANSVERSE S3",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 38,
            "GROUPES_CM": 0,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Transverse",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "REALB04",
            "TITRE": "ALGEBRE LINEAIRE ET BILINEAIRE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Formes bilinéaires symétriques et antisymétriques. Dualité, formes quadratiques.",
                "Espaces vectoriels euclidiens : (Espaces vectoriels réels de dimension finie, munis d’une forme bilinéaire symétrique, positive, non dégénérée)",
                "Produit Scalaire. Inégalité de Cauchy-Schwarz, inégalité triangulaire, norme euclidienne. Existence de bases orthonormales (Méthode de Schmidt). Sous-espaces orthogonaux. Projections et symétries orthogonales.",
                "Adjoint d'un endomorphisme. Endomorphismes symétriques.",
                "Isométries d’un espace vectoriel euclidien. Matrices orthogonales.",
                "Changement de bases orthonormales.",
                "Formes sesquilinéaires. Formes hermitiennes. Endomorphismes hermitiens.",
                "Matrices hermitiennes.",
                "Diagonalisation des matrices symétriques réelles et hermitiennes."
            ],
            "PREREQUIS": [],
            "CM": 30,
            "TD": 46,
            "TP": 0,
            "EFFECTIF": 54,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Maths",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "REDO04",
            "TITRE": " INTEGRATION ET EQUATIONS DIFFERENTIELLES ORDINAIRES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Rappels sur les équations et systèmes différentiels ordinaires linéaires à coefficients constants. Méthode de variation des constantes. Méthodes élémentaires de résolution d’équations différentielles ordinaires non linéaires.",
                "Théorème de Cauchy-Lipschitz : existence et unicité de solution locale.",
                "Notion de solution maximale. Principe d’explosion. Continuité par rapport à la donnée initiale.",
                "AspECTS qualitatifs : Equations et systèmes différentiels ordinaires linéaires.",
                "Point fixes : classification des points d’équilibre (col, noeud).",
                "AspECTS qualitatifs : études de systèmes dynamiques en dimension 2, homoclines, espaces des phases, fonction de Lyapunov et systèmes gradients (principe d’invariance de La Salle). Linéarisation au voisinage des points fixes, stabilité. Utilisation d’une intégrale première. L’exemple du pendule pesant."
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 51,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Maths",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "REANN04",
            "TITRE": "ANALYSE NUMERIQUE 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Approximation polynomiale d’une fonction réelle : Interpolation de Lagrange, forme de Newton, points de Chebychev, estimation de l’erreur.",
                "Interpolation d’Hermite, méthode des moindres carrés.",
                "Polynômes de meilleure approximation",
                "Recherches des zéros d’une fonction réelle continue. Dichotomie, méthode de la sécante, méthode de Newton. Méthode de point fixe. Méthode d’accélération de convergence (méthode d’Aitken, extrapolation à la limite).",
                "Calcul approché d’intégrales. Formules de quadratures élémentaires : Formule de Newton Cotes, calcul de l’erreur. Méthode de Romberg.",
                "Méthode des rectangles, méthodes des trapèzes, méthode de Simpson.",
                "Introduction à l’approximation de solutions d’équations différentielles ordinaires."
            ],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 24,
            "TP": 6,
            "EFFECTIF": 50,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 2,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Maths",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "RECAD04",
            "TITRE": "COMBINATOIRE ET PROBABILITES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 49,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Maths",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.1",
            "TITRE": "ALGORITHMIQUE DES ARBRES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 5,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Parcours d'arbre",
                "Arbre binaire, ABR",
                "Arbres équilibrés, équilibrage",
                "B-arbre et application à la gestion des données",
                "Tri par tas",
                "Notion de preuve de programme, invariant",
                "Représentation des arbres",
                "Implémentation de différents algorithmes de manipulation d'arbres (parcours, ajout/suppression, ...)",
                "Réalisation d'un projet",
                "Savoir implémenter la structure d'arbre dans un programme",
                "Savoir implémenter les algorithmes de base sur les arbres et ABR",
                "Savoir choisir les types d'arbres et les algorithmes les plus adaptés pour un problème donné"
            ],
            "PREREQUIS": [],
            "CM": 8,
            "TD": 32,
            "TP": 0,
            "EFFECTIF": 120,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "(examen écrit de 2h+2*projet)/3",
                "SECONDE_CHANCE": "examen écrit de 2h",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Alain Cournier possible",
                    "Frédéric Fürst possible"
                ],
                "INTERVENANTS": [
                    "Sami Cherif"
                ]
            },
            "NOTES": [
                "16h de TD sont sur machine"
            ],
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.2",
            "TITRE": "LANGAGES FORMELS 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Notions de base (mots, langages, ...)",
                "Langages reconnaissables, automates finis",
                "Langages et expressions rationnelles (liens avec les outils de recherche utilisant des expressions régulières)",
                "Théorème de Kleene, algorithmes de passage d’un automate à une expression rationnelle et réciproquement",
                "Langage reconnu par un automate (algorithme de Mac Naughton et Yamada)",
                "Propriétés de fermeture rationnelles",
                "Déterminisme",
                "Propriétés de fermeture non rationnelles",
                "Minimalité",
                "Langages non reconnaissables, théorème de l'étoile",
                "Extraire des règles lexicales caractérisant un texte et concevoir une expression régulière le reconnaissant",
                "Proposer un automate efficace (facilement manipulable) pour représenter un langage",
                "Identifier les langages reconnaissables"
            ],
            "PREREQUIS": [],
            "CM": 14,
            "TD": 16,
            "TP": 0,
            "EFFECTIF": 120,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.3",
            "TITRE": "PROGRAMMATION OBJET 1",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Notion d'objet et de classe, méthodes, constructeurs",
                "Diagramme de classes en UML",
                "Encapsulation, visibilité",
                "Héritage",
                "Polymorphisme",
                "Abstraction : méthodes abstraites, classes abstraites, interfaces",
                "Packages",
                "Exception",
                "Concevoir et développer un programme suivant le paradigme objet",
                "Maitriser les différents mécanismes de la programmation objet en Java",
                "Exploiter ces mécanismes pour améliorer la qualité du logiciel produit: robustesse, extensibilité, réutilisabilité"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 120,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "examen",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Catherine Barry"
                ],
                "INTERVENANTS": [
                    "Sami Cherif"
                ]
            },
            "NOTES": [
                "14h de TD sont sur machine"
            ],
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.4",
            "TITRE": "WEB 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Fonctionnement d’une architecture client/serveur de contenu Web : Protocole HTTP, langage PHP, traitement de formulaires, sessions, upload",
                "Interfaçage avec une base de données",
                "Projet en Simfony",
                "Conception d'une BDR et accès via une interface Web",
                "Notion de test unitaire",
                "Concevoir une BDR",
                "Concevoir un site web dynamique, qui interagit avec une base de données",
                "Manipuler et conserver, côté serveur, des données provenant des utilisateurs d'un site web"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 40,
            "EFFECTIF": 120,
            "GROUPES_CM": 1,
            "GROUPES_TD": 0,
            "GROUPES_TP": 6,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "examen",
                "SESSION_2": "max(session1,seconde chance)"
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Yoann Dieudonné"
                ],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "UEinfo4.5",
            "TITRE": "RESEAU 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Adressage avancé : IPv4 et IPv6",
                "Routage : statique et dynamique (RIP, OSPF, BGP)",
                "Protocoles de transport : TCP / UDP, sockets",
                "Services réseaux essentiels : DNS, DHCP, SMTP, POP3/IMAP"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 120,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Wafa Badreddine",
                    "Gil Utard"
                ],
                "INTERVENANTS": []
            },
            "NOTES": [
                "10h de TD sont sur machine"
            ],
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "SAE4",
            "TITRE": "SAE S4",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Etude et recherche sur un projet d'informatique ou de mathématiques"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "CT4",
            "TITRE": "TRANSVERSE S4",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Anglais ..."
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 40,
            "GROUPES_CM": 0,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Transverse",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "REGAC05",
            "TITRE": "ALGEBRE 3.1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 8,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Groupes. Sous-groupes, groupes quotient, homomorphismes, noyau, image, groupes cycliques, groupes diédraux, groupes symétriques. Groupe opérant sur un ensemble.",
                "Anneaux, idéaux, quotients, morphismes d'anneaux, corps.",
                "Anneaux intègres, corps des fractions.",
                "Notions de base des anneaux euclidiens et principaux. Exemples de Z, Z/nZ, Z[i] (theoreme des deux carres...) et de l’anneau des polynômes à une indéterminée.",
                "Factorialité de Z et K[X], où K est un corps, pgcd, ppcm, théorème de Bezout.",
                "Corps finis. Caractéristique. Construction des corps finis."
            ],
            "PREREQUIS": [],
            "CM": 30,
            "TD": 45,
            "TP": 0,
            "EFFECTIF": 39,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Maths",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "RECAD05",
            "TITRE": "TOPOLOGIE ET CALCUL DIFFERENTIEL",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 8,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Notion d'espace topologique, base de voisinages, topologie produit, cas métrique. Parties d'un espace topologique, continuité, connexité, compacité.",
                "Cas des espaces vectoriels normés : applications linéaires continues, normes équivalentes, théorème de Riesz.",
                "Espace de Banach de fonctions bornées, continues, de classe Ck. Série dans un espace de Banach. Interprétation de la convergence normale.",
                "Théorèmes de Dini et de Stone-Weierstrass.",
                "Théorème d’Ascoli.",
                "Rappels concernant les fonctions de classe Ck d’un ouvert de Rn vers Rm (le cas des espaces vectoriels normés pourra aussi être abordé) : Définitions, accroissements finis, formule de Taylor, application aux extrema locaux.",
                "Théorèmes d’inversion locale, et des fonctions implicites et des extrema liés. Applications à la notion de sous-variété de Rn : diverses caractérisations, leur espace vectoriel ou affine tangent, application de classe Ck sur une sous-variété."
            ],
            "PREREQUIS": [],
            "CM": 30,
            "TD": 45,
            "TP": 0,
            "EFFECTIF": 37,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Maths",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "REANM05",
            "TITRE": "ANALYSE NUMERIQUE 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 20,
            "TD": 24,
            "TP": 6,
            "EFFECTIF": 23,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 2,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Maths",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.2",
            "TITRE": "ALGORITHMIQUE DES GRAPHES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Graphes",
                "Parcours d’un graphe, composantes connexes, cycles",
                "Algorithmes classiques de recherche du plus court chemin dans un graphe",
                "Arbre couvrant de coût minimum,  réalisation d’un réseau connexe à coût minimum",
                "Couplage maximum et problèmes d’affectation des tâches",
                "Implémentations des graphes",
                "Modéliser un problème sous forme de graphes, choisir le type de graphe le plus adapté",
                "Associer à chaque algorithme un problème et/ou un domaine d’application (p. e. points d’articulation et réseaux tolérants aux pannes etc.)",
                "Choisir et mettre en oeuvre l'algorithme de graphe le plus adapté à un problème donné, en tenant compte de son efficacité",
                "Implémenter un graphe de différentes façons (chainage, matrice) selon le traitement à effectuer"
            ],
            "PREREQUIS": [],
            "CM": 18,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 90,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.1",
            "TITRE": "LANGAGES FORMELS 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Langages non reconnaissables",
                "Notions de grammaires et de langages algébriques",
                "Analyse lexicale, analyse syntaxique, analyseur LL, analyseur LR, grammaire LR, SLR",
                "Production du code intermédiaire, production du code, optimisation du code",
                "Mini-projet (ex: développement d'un mini-compilateur avec Flex et Bison)"
            ],
            "PREREQUIS": [],
            "CM": 8,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 90,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "NOTES": [
                "10h de TD sont sur machine"
            ],
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.3",
            "TITRE": "ANALYSE ET CONCEPTION DES SYSTEMES D'INFORMATION",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Analyser et identifier les besoins des utilisateurs",
                "Modéliser l'existant",
                "Identifier les fonctionalités d'un SI",
                "Réaliser une maquette fonctionnelle",
                "Choisir une architecture de SI adaptée à des besoins",
                "Concevoir le déploiement d'un SI sur une infrastructure",
                "Rédiger un cahier des charges",
                "Planifier un projet"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 40,
            "TP": 0,
            "EFFECTIF": 90,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "NOTES": [
                "TD sur machine"
            ],
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo6.6",
            "TITRE": "DONNEES MASSIVES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Compréhension des paradigmes du Big Data",
                "Formats de données semi-structurés (XML, JSON, ...)",
                "Visualisation de données (temporelles, spatiales, graphes, ...)",
                "Utilisation de librairies dataviz (matplotlib, ...)",
                "Extraire, manipuler et visualiser des données structurées ou semi-structurées",
                "Elaborer un modèle de document NoSQL"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 8,
            "TP": 12,
            "EFFECTIF": 50,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 4,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.7",
            "TITRE": "CRYPTOLOGIE ET SECURITE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Cryptologie : bases mathématiques pour la sécurité de l’information, ordre de grandeur, fonctions à sens unique, arbres de Merkle, preuve de travail, compréhension et usage des Blockchains"
            ],
            "PREREQUIS": [],
            "CM": 8,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 28,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "NOTES": [
                "8h de TD sont sur machine"
            ],
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "UEinfo5.8",
            "TITRE": "SYSTEME D'EXPLOITATION AVANCE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Programmation concurrente",
                "Ordonnancement",
                "Mémoire : segmentation, pagination, mémoire virtuelle, algorithme de pagination etc",
                "Structure d'un OS"
            ],
            "PREREQUIS": [],
            "CM": 8,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 68,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "NOTES": [
                "10h de TD sont sur machine"
            ],
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "SAE5",
            "TITRE": "SAE S5",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Etude et recherche sur un projet d'informatique ou de mathématiques"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "CT5",
            "TITRE": "TRANSVERSE S5",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Anglais ..."
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 29,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Transverse",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "RETOG06",
            "TITRE": "ALGEBRE 3.2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 24,
            "TD": 36,
            "TP": 0,
            "EFFECTIF": 40,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Maths",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "REANC06",
            "TITRE": "MESURE ET INTEGRATION",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 9,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Notions et propriétés des Tribu, applications mesurables, mesures, ensembles négligeables, mesure de Lebesgue. Ces notions ne seront pas traitées dans le détails, cela sera fait au S6.",
                "Intégrale de Lebesgue et fonctions intégrables. Application aux mesures de comptage.",
                "Enoncés (sans démonstration) des Théorèmes de convergence, dérivation et continuité sous le signe somme, de Fubini et de changement de variables.",
                "Applications : intégrales à paramètres, intégrales multiples, espaces L^p, convolution de fonctions., transformée de Fourier"
            ],
            "PREREQUIS": [],
            "CM": 40,
            "TD": 50,
            "TP": 0,
            "EFFECTIF": 38,
            "GROUPES_CM": 1,
            "GROUPES_TD": 2,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Maths",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "REINT06",
            "TITRE": "ANALYSE COMPLEXE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 24,
            "TD": 36,
            "TP": 0,
            "EFFECTIF": 22,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Maths",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.2",
            "TITRE": "INTELLIGENCE ARTIFICIELLE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Apprentissage par renforcement : bandit manchot, processus de Markov",
                "Apprentissage automatique : régression linéaire, arbre de décision, réseaux de neurones",
                "Choisir un modèle et une méthode d'apprentissage en fonction des données à traiter",
                "Concevoir et paramétrer un réseau de neurones",
                "Evaluer quantitativement un modèle d'apprentissage"
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 28,
            "TP": 0,
            "EFFECTIF": 90,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "NOTES": [
                "14h de TD sont sur machine"
            ],
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.8",
            "TITRE": "PROGRAMMATION PARALLELE ET DISTRIBUEE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Parallélisme : algorithmes dans le modèle PRAM, introduction à d'autres modèles (CGM par exemple)",
                "Algorithmique distribué : présentation du modèle à passage de messages, algorithmes distribués pour des taches fondamentales (diffusion, exclusion mutuelle, routage)"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 20,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "NOTES": [
                "8h de TD sont sur machine"
            ],
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.3",
            "TITRE": "MODELES DE CALCUL",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Ensembles énumérables, récursivement énumérables",
                "Présentation de modèles (tant que, primitives récursives)",
                "Transformer un algorithme récursif en itératif et vice versa",
                "Thèse de Church",
                "Présentation de problèmes semi indécidables (problème de l'arrêt)"
            ],
            "PREREQUIS": [],
            "CM": 14,
            "TD": 16,
            "TP": 0,
            "EFFECTIF": 90,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.1",
            "TITRE": "DEVELOPPEMENT DES SYSTEMES D'INFORMATION",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Découverte et apprentissage du Framework .NET 9, notamment Entity Framework et pattern MVVM",
                "Utilisation d'un environnement de développement (Visual Studio ou Rider) pour l'écriture de code, notamment utilisation du debugger",
                "Utilisation de GIT/GitHub en version simplifiée (commit, push, pull)",
                "Pratique des tests : tests fonctionnels, tests unitaires et d'intégration",
                "Utilisation d'un outil de planification de projet simple (comme Trello) pour le suivi de l'avancement du projet"
            ],
            "PREREQUIS": [],
            "CM": 8,
            "TD": 42,
            "TP": 0,
            "EFFECTIF": 90,
            "GROUPES_CM": 1,
            "GROUPES_TD": 3,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "NOTES": [
                "TD sur machine"
            ],
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "UEinfo6.4",
            "TITRE": "METHODES QUANTITATIVES ET DECISION",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Objectif des méthodes quantitatives et décision (MQD)",
                "Les étapes d'un projet en MQD : problèmes d’ordonnancement et de planification de tâches dans un réseau informatique",
                "Modélisation par quantification (ordonnancement de tâches, production, gestion de stock)",
                "Résolution géométrique de l’ordonnancement et de la planification de tâches",
                "Différentes formes d'un modèle quantifié (forme générale, forme canonique d'un modèle, forme standard)",
                "Base, solution de base d'un modèle quantifié, optimalité",
                "Phase II primale du simplexe (démarrage de la méthode, résolution par points extrêmes)",
                "&Eacute;quivalence de modèles quantifiés et interprétation géométrique",
                "Modéliser un problème de planification ou d'ordonnancement",
                "Mettre en oeuvre l'algorithme du simplexe"
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 20,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "NOTES": [
                "4h de TD sont sur machine"
            ],
            "STYLE": "Informatique",
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "SAE6",
            "TITRE": "SAE S6",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Etude et recherche sur un projet d'informatique ou de mathématiques"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "CT6",
            "TITRE": "TRANSVERSE S6",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Anglais ..."
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 31,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "STYLE": "Transverse",
            "OBJECTIFS": []
        }
    ]
})