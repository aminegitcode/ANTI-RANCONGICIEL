addMaquette({
    "FORMATION": {
        "NOM": "Licence Informatique ULCO 2024/25",
        "ETABLISSEMENT": "Université Littoral - Cöte d'Opale",
        "ANNEES": "2024/25",
        "NB_SEMESTRES": 6,
        "LMD": "L",
        "PARCOURS": [],
        "M3C": [],
        "BLOCS": [
            {
                "NOM": "C1",
                "DESCRIPTION": "Elaborer une modélisation numérique d'un problème et de ses données",
                "ID": "C1"
            },
            {
                "NOM": "C2",
                "DESCRIPTION": "Développer une solution informatique",
                "ID": "C2"
            },
            {
                "NOM": "C3",
                "DESCRIPTION": "Administrer une infrastructure informatique",
                "ID": "C3"
            },
            {
                "NOM": "C4",
                "DESCRIPTION": "Mettre en œuvre un projet",
                "ID": "C4"
            },
            {
                "NOM": "C5",
                "DESCRIPTION": "Construire son projet professionnel",
                "ID": "C5"
            }
        ],
        "RESPONSABLES": [],
        "PRESENTATION": []
    },
    "MODULES": [
        {
            "SEMESTRE": 1,
            "ID": "1.1",
            "TITRE": "ALGORITHMIQUE 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Notions de base (variable, fonction, conditionnelle, itération et tableau) et Python"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "A. Lewandowski",
                    "V. Marion"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "1.2",
            "TITRE": "ARCHITECTURE ET SYSTEME 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Chaine de traitement et architectures (Camera → FPGA → CPU)",
                "Approfondissement Camera / Image",
                "Echantillonnage / quantification",
                "Codage des images et stockage",
                "Opérations booléennes, opérateurs morphologique de base et traitements plus évolués"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "E. Poisson-Caillault",
                    "P.-A. Hebert"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "1.3",
            "TITRE": "WEB 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Architecture d’une page Web, langage à bases (HTML) et langage de feuille de style (CSS)"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "J. Druel",
                    "J. Lesage"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "1.4",
            "TITRE": "MATHEMATIQUES 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Fonctions, suite et limites"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "1.5",
            "TITRE": "MATHEMATIQUES 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Ensembles, relations et applications"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "1.6",
            "TITRE": "MATHEMATIQUES 3",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Nombres complexes, géométrie cartésienne, isométries et similitudes"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "1.7",
            "TITRE": "PHYSIQUE 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "1.8",
            "TITRE": "CHIMIE 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "1.9",
            "TITRE": "PHYSIQUE 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1",
                    "CHOIX": [
                        3,
                        [
                            "1.9",
                            "1.10"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "1.10",
            "TITRE": "CHIMIE 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1",
                    "CHOIX": [
                        3,
                        [
                            "1.9",
                            "1.10"
                        ]
                    ]
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "1.11",
            "TITRE": "ANGLAIS",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 25,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.1",
            "TITRE": "ALGORITHMIQUE 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Algorithmique en langage C"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "A. Chotard",
                    "V. Marion",
                    "S. Tari"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.2",
            "TITRE": "ALGORITHMIQUE 3",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Algorithmique avancée en langage C"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "A. Chotard",
                    "V. Marion",
                    "S. Tari"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.3",
            "TITRE": "BASE DE DONNEES 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Modélisation des Système d’Information, formalisme UML",
                "Modèle Conceptuel des Données (MCD)",
                "Modèle Logique de Données Relationnel (MLD-R)",
                "Règles de passage du MCD au MLD-R (Dépendances fonctionnelles, formes normes 1NF, 2NF, 3NF, BCNF)"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "A. Ahmad"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.4",
            "TITRE": "PROJET 1",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C4"
                }
            ],
            "CONTENU": [
                "Projet en langage C"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.5",
            "TITRE": "MATHEMATIQUES 4",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Dérivabilité, formules de Taylor, calcul intégral"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.6",
            "TITRE": "MATHEMATIQUES 5",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Systèmes linéaires, calcul matriciel, espaces vectoriels et applications linéaires"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.7",
            "TITRE": "MATHEMATIQUES 6",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Arithmétique de Z, arithmétiques des polynômes"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.8",
            "TITRE": "MATHEMATIQUES 7",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Calcul différentiel, équations différentielles, courbes paramétrées"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.9",
            "TITRE": "ANGLAIS",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 25,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.10",
            "TITRE": "PPP",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "2.11",
            "TITRE": "CERTIFICATION",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "3.1",
            "TITRE": "ALGORITHMIQUE 4",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Arbre : structure données et algorithmes en langage C"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "V. Marion"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "3.2",
            "TITRE": "LANGAGES A OBJET 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Concepts objets (objets, classes, héritage, encapsulation, constructeurs et méta-classe) en Java"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "G. Bourguin"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "3.3",
            "TITRE": "ARCHITECTURE ET SYSTEME 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Architecture d’un système d’exploitation et Linux"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "3.4",
            "TITRE": "BASE DE DONNEES 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Algèbre Relationnelle",
                "Opérateurs ensemblistes",
                "Agrégats",
                "Requêtes et langage SQL (MySQL)",
                "Passage du MLD-R au MPD"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "A. Ahmad"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "3.5",
            "TITRE": "WEB 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Modèle dynamique couche cliente (JS/JQuery)"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "G. Bourguin"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "3.6",
            "TITRE": "INTELLIGENCE ARTIFICIELLE 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Représentation et interprétation d’une variable (nuage de points, distribution, statistique de base, histogramme, mode, représentation temporelle, catégorielle, boite à moustache, tendance, cycle, modélisation/prédiction et régression)",
                "Représentation et interprétation bi-variée (visualisation 2D, changement d’espace, graphe, corrélation, clustering)",
                "Représentation 3D"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "E. Poisson-Caillault"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "3.7",
            "TITRE": "MATHEMATIQUES 8",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Algèbre linéaire"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "3.8",
            "TITRE": "MATHEMATIQUES 9",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Algèbre linéaire - applications"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "3.9",
            "TITRE": "ANGLAIS",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 25,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "3.10",
            "TITRE": "UNITE D'OUVERTURE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "4.1",
            "TITRE": "ALGORITHMIQUE 5",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Graphe : structure données et algorithmes en langage C"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "C. Renaud"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "4.2",
            "TITRE": "LANGAGES A OBJET 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Polymorphisme",
                "Classes abstraites, interfaces",
                "Généricité",
                "Exceptions",
                "APIs en Java"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "G. Bourguin"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "4.3",
            "TITRE": "ARCHITECTURE ET SYSTEME 3",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Gestion ressources (processus, mémoire, ...)",
                "Programmation concurrente (fork, threads, sémaphores)"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "4.4",
            "TITRE": "WEB 3",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": [
                        2,
                        1
                    ],
                    "BLOCS": [
                        "C2",
                        "C3"
                    ]
                }
            ],
            "CONTENU": [
                "Modèle client-serveur",
                "Protocole HTTP et le langage PHP"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "G. Bourguin"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "4.5",
            "TITRE": "INFORMATIQUE THEORIQUE 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Dénombrement",
                "Automates finis",
                "Corrections d’algorithme et complexité"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "4.6",
            "TITRE": "MATHEMATIQUES 10",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Analyse numérique"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "4.7",
            "TITRE": "PROJET 2",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C4"
                }
            ],
            "CONTENU": [
                "Développement d'une application en Java"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "4.8",
            "TITRE": "PROJET 3",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C4"
                }
            ],
            "CONTENU": [
                "Développement d'une application Web"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "4.9",
            "TITRE": "ANGLAIS",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 25,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "4.10",
            "TITRE": "PPP",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "5.1",
            "TITRE": "PROGRAMMATION FONCTIONNELLE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Conditions",
                "Pattern matching",
                "Liste, tuple",
                "Fonctions récursives",
                "Fonctions d’ordre supérieur",
                "Langage Haskell"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "J. Dehos"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "5.2",
            "TITRE": "LANGAGES A OBJET 3",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "Rappel des concepts objets (encapsulation, héritage, polymorphisme)",
                "Spécificités du C++ (héritage multiple, instance/référence/pointeur, classe abstraite, surcharge des opérateurs)"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "J. Buisine"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "5.3",
            "TITRE": "RESEAUX 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Codage",
                "Réseaux locaux",
                "TCP/IP",
                "Ingénierie des protocoles",
                "Modélisation des réseaux et nouvelles architectures des réseaux"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "P. Sondi"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "5.4",
            "TITRE": "BASE DE DONNEES 3",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "SQL avancé",
                "Procédures embarquées (PL-SQL)",
                "B-Tree",
                "Optimisation (ANALYSE, AUTOTRACE, EXPLAIN PLAN)",
                "Opération Physiques et introduction à l'administration BD"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "A. Ahmad"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "5.5",
            "TITRE": "GENIE LOGICIEL 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C4"
                }
            ],
            "CONTENU": [
                "Introduction au GL",
                "Documentation",
                "Versionning",
                "Interfaçage",
                "Intégration continue"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "J. Dehos"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "5.6",
            "TITRE": "INFORMATIQUE THEORIQUE 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Machine de de Turing",
                "Calculabilité, décidabilité",
                "Méthodes formelles et grammaire"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "S. Verel"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "5.7",
            "TITRE": "INTELLIGENCE ARTIFICIELLE 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Historique de l’IA",
                "Recherche bidirectionnelle",
                "Minmax/alphabeta",
                "Recherche Monte-Carlo",
                "Algorithme A*",
                "Applications sur les jeux "
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "A. Chotard"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "5.8",
            "TITRE": "PROBABILITES ET STATISTIQUES",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Modèle probabiliste",
                "Variables aléatoires discrètes et continues",
                "Simulation de Monté Carlo",
                "Génération de variables aléatoires"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "M. Zribi"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "5.9",
            "TITRE": "ANGLAIS",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 25,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 5,
            "ID": "5.10",
            "TITRE": "UNITE D'OUVERTURE",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 25,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "6.1",
            "TITRE": "LANGAGE A OBJET 4",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C2"
                }
            ],
            "CONTENU": [
                "C++ avancé : containers, flux, fonctions lambda et template"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "J. Buisine",
                    "E. Ramat"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "6.2",
            "TITRE": "RESEAUX 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Codage",
                "Réseaux locaux",
                "TCP/IP",
                "Ingénierie des protocoles",
                "Modélisation des réseaux",
                "Nouvelles architectures des réseaux"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "P. Sondi"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "6.3",
            "TITRE": "ADMINISTRATION SYSTEMES ET RESEAUX",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C3"
                }
            ],
            "CONTENU": [
                "Administration systèmes",
                "Services réseaux",
                "Supervision",
                "Pare-feux",
                "IDS/IPS"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "P. Sondi"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "6.4",
            "TITRE": "GENIE LOGICIEL 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C4"
                }
            ],
            "CONTENU": [
                "UML",
                "Gestion d'erreurs",
                "Tests",
                "Refactoring",
                "Design patterns (MVC, client/serveur)"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "J. Dehos"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "6.5",
            "TITRE": "INFORMATIQUE THEORIQUE 3",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Introduction à la compilation (analyse lexicale et syntaxique)"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": [
                    "A. Chotard"
                ]
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "6.6",
            "TITRE": "PROJET 4",
            "TYPE": "SAE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C4"
                }
            ],
            "CONTENU": [
                "Gestion de projets en équipe"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "6.7",
            "TITRE": "OPTION 1",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [
                "Exemples : informatique graphique, IA avancé, Web avancé, programmation VHDL, vision/supervision et traitement de données"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "6.8",
            "TITRE": "OPTION 2",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [
                "Exemples : informatique graphique, IA avancé, Web avancé, programmation VHDL, vision/supervision et traitement de données"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 27,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "6.9",
            "TITRE": "ANGLAIS",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 25,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 6,
            "ID": "6.10",
            "TITRE": "PPP",
            "TYPE": "RESSOURCE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C5"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 10,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        }
    ]
})