addMaquette({
    "FORMATION": {
        "NOM": "Master INFO - 2026",
        "ETABLISSEMENT": "Université de Picardie - Jules Verne",
        "ANNEES": "2026",
        "NB_SEMESTRES": 4,
        "LMD": "M",
        "PARCOURS": [
            {
                "ID": "ISRI",
                "NOM": "ISRI",
                "DESCRIPTION": "Ingénierie des Systèmes et Réseaux Informatiques",
                "ANNEES": [
                    1,
                    2
                ]
            },
            {
                "ID": "OASIS",
                "NOM": "OASIS",
                "DESCRIPTION": "Optimisation et Algorithmique des Systèmes Intelligents et Sécurisés",
                "ANNEES": [
                    1,
                    2
                ]
            }
        ],
        "BLOCS": [
            {
                "ID": "C1",
                "NOM": "DISCIPLINAIRE-CONNEXE",
                "DESCRIPTION": ""
            },
            {
                "ID": "CT",
                "NOM": "TRANSVERSE",
                "DESCRIPTION": ""
            }
        ],
        "RESPONSABLES": [
            "Parcours ISRI : gil.utard@u-picardie.fr",
            "Parcours OASIS : stephane.devismes@u-picardie.fr"
        ],
        "M3C": [],
        "PRESENTATION": [
            "Le parcours OASIS du master reflète les thèmes de recherche informatique des laboratoires MIS et EPROAD en s’articulant autour de 6 domaines majeurs :",
            "&nbsp;&nbsp;&nbsp;&nbsp; • Systèmes distribués",
            "&nbsp;&nbsp;&nbsp;&nbsp; • Optimisation",
            "&nbsp;&nbsp;&nbsp;&nbsp; • Réseaux et données",
            "&nbsp;&nbsp;&nbsp;&nbsp; • Intelligence artificielle",
            "&nbsp;&nbsp;&nbsp;&nbsp; • Sécurité",
            "&nbsp;&nbsp;&nbsp;&nbsp; • Robotique",
            "<br>En plus des modules découlant de ces domaines, il comportera quelques modules transversaux et deux stages obligatoires (8 semaines en première année et 6 mois en deuxième année). Les stages pourront être effectué dans des laboratoires de recherche ainsi qu’en entreprise. Le sujet de stage de deuxième année devra clairement être un stage « recherche ».",
            "Plusieurs modules seront mutualisés avec le parcours ISRI afin de limiter les coûts. Ainsi, le planning sera coordonné sur celui d’ISRI.",
            "<br><u>Débouchés</u> : ",
            "&nbsp;&nbsp;&nbsp;&nbsp; • Enseignement supérieur et académique",
            "&nbsp;&nbsp;&nbsp;&nbsp; • Recherche publique (universités, CNRS, INRIA…)",
            "&nbsp;&nbsp;&nbsp;&nbsp; • R&D privés (industries technologiques, start-ups, grandes entreprises)",
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ◦ Optimisation pour les transports, logistique, énergie, planification industrielle, gestion de réseaux complexes",
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ◦ Ingénierie en robotique et systèmes autonomes (industrie, santé, mobilité, défense)",
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ◦ Optimisation multi-agents et coordination de systèmes distribués",
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ◦ R&D en systèmes embarqués, IoT et cybersécurité",
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ◦ Gestion et analyse intelligente de données complexes",
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ◦ Conception et validation de systèmes critiques (transport, aéronautique, médical, télécoms)",
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ◦ Architecture ou Ingénierie en systèmes distribués, réseaux intelligents et infrastructures sécurisées",
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ◦ Développement de solutions pour le cloud, l’edge computing, ..."
        ]
    },
    "MODULES": [
        {
            "SEMESTRE": 1,
            "ID": "M1I_ANG",
            "TITRE": "ANGLAIS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 40,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "M1I_MATH1",
            "TITRE": "MATHEMATIQUES POUR L'INFORMATIQUE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Probabilités et statistiques",
                "Algèbre linéaire",
                "Théorie des nombres"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 10,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "(CC1+CC2)/2",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Léo Robert",
                    "Claire Delaplace"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "M1I_SE1",
            "TITRE": "ADMINISTRATION ET SECURISATION DES SE 1",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "M1I_SE2",
            "TITRE": "ADMINISTRATION ET SECURISATION DES SE 2",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "M1I_ALDIS",
            "TITRE": "ALGORITHMIQUE DISTRIBUEE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Introduction à l'algorithmique distribuée",
                "Algorithme de circulation de jeton",
                "Propagation d'information avec retour",
                "Horloges de Lamport",
                "Algorithmes de calcul de tables de routage",
                "Snapshot de Chandy & Lamport",
                "Simulation d'algorithmes distribuées",
                "FLP : impossibilité du Consensus"
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Alain Cournier",
                    "Stéphane Devismes"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "M1I_RESIN",
            "TITRE": "RESEAUX LOCAUX ET INTERNET",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "IPv4/6, routeur"
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "M1I_RESCO",
            "TITRE": "RESEAUX ET COMMUNICATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Algo routage"
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "M1I_RO1",
            "TITRE": "RECHERCHE OPERATIONNELLE 1",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OASIS",
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Programmation linéaire",
                "Algorithme du simplexe",
                "Dualité",
                "Programmation mixte-entière",
                "Branch-and-Bound"
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "max(Examen,(partiel+examen)/2)",
                "SECONDE_CHANCE": "non",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Rui Shibasaki"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "M1I_HPC",
            "TITRE": "HPC",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OASIS",
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Introduction au parallélisme",
                "Architectures parallèles",
                "Modèles de programmation parallèle",
                "Programmation parallèle",
                "Analyse de performances"
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Jerry Lacmou",
                    "Gael Le Mahec",
                    "Gil Utard"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "M1I_IACOG",
            "TITRE": "IA COGNITIVISTE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OASIS",
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Histoire de l’IA",
                "Représentation de la connaissance",
                "Web sémantique",
                "Systèmes Experts",
                "Perspectives",
                "Séminaire ontologies"
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "0.5 CC + 0.5 soutenance [avec CC : Mini-projet]",
                "SECONDE_CHANCE": "non",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Dominique Groux"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "M1I_CRYPT",
            "TITRE": "CRYPTOGRAPHIE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Notions de bases sur la cryptographie : chiffrement symétrique/asymétrique, fonctions de hachages, signatures"
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Léo Robert",
                    "Claire Delaplace"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "M1I_IMGVI",
            "TITRE": "IMAGE / VISION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OASIS",
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Fondamentaux de la vision (caméra perspective couleur/nuances de gris)",
                "Etalonnage de caméra perspective",
                "Calcul de pose, changement de repère",
                "Etalonnage \"hand-eye\""
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Pascal Vasseur"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "M1I_IA1",
            "TITRE": "INTRODUCTION A L'IA",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Apprentissage par renforcement, multi-armed bandits",
                "Processus de décision markovien, apprentissage par différence temporelle",
                "Apprentissage automatique, méthodes de régression et classification",
                "Réseaux de neuronnes, large language models (LLMs)"
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "Projet/Examen (Examen 70% Projet 30%)",
                "SECONDE_CHANCE": "non",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Rui Shibasaki",
                    "Yu Li"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "M1I_FONDA",
            "TITRE": "INFORMATIQUE FONDAMENTALE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OASIS",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "La théorie de la complexité est le domaine de l'informatique théorique, qui étudie formellement le temps de calcul, l'espace mémoire… requis par un algorithme pour résoudre un problème algorithmique. Il s'agit donc d'étudier la difficulté intrinsèque des problèmes, de les organiser par classes de complexité et d'étudier les relations entre les classes de complexité. La théorie de la calculabilité… de l'informatique théorique qui vise à identifier les limites de ce qui peut être calculé par un algorithme (indépendamment du temps nécessaire pour effectuer ce calcul).",
                "Dans ce cours nous allons faire une étude approfondie de ces deux concepts fondamentaux de l’informatique."
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 25,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Alain Cournier",
                    "Yu Li"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "M1I_BIGDA",
            "TITRE": "BIG DATA",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Modèles d’organisation de données, problématiques liées au passage à l’échelle",
                "Visualisation",
                "Analyse de données hétérogènes",
                "Applications (détection d’anomalies, ...)"
            ],
            "PREREQUIS": [],
            "CM": 8,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Florence Levé"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "M1I_FAUTE",
            "TITRE": "TOLERANCE AUX FAUTES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Protocole du bit alterné",
                "Algorithmes tolérants les pannes permanentes de processsus (crashes): Algorithme de Ben Or, Set Flooding, algorithme tolérant les processus \"mort-nés\"",
                "Détecteurs de pannes : définition, réduction, algorithmes, consensus à base de détecteurs de pannes"
            ],
            "PREREQUIS": [],
            "CM": 7.5,
            "TD": 7.5,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Alain Cournier",
                    "Stéphane Devismes"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "M1I_STABI",
            "TITRE": "ALGORITHMES DISTRIBUES STABILISANTS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OASIS",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Introduction à l'autostabilisation",
                "Algorithme de Dijkstra",
                "Exemples d'algorithmes autostabilisants (contruction d'arbre couvrant, MIS, ...)",
                "Généralisation de l'autostabilisation",
                "Spécialisation de l'autostabilisation",
                "Stabilisation instantanée",
                "Simulation d'algorithmes autostabilisants"
            ],
            "PREREQUIS": [],
            "CM": 7.5,
            "TD": 7.5,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Alain Cournier",
                    "Stéphane Devismes"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "M1I_HEURI",
            "TITRE": "HEURISTIQUES ET METAHEURISTIQUES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OASIS",
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Recherche locale",
                "Métaheuristiques",
                "Algorithmes mimétiques",
                "Études des paysages"
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Laure Brisoux",
                    "Corinne Lucet"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "M1I_CHAIN",
            "TITRE": "BLOCKCHAIN, FONDEMENTS ET APPLICATIONS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Architecture d’une blockchain, notion de transaction, d’ancrage, de réplication d’état, de permissioned/no permissoned",
                "Etude des différents types de consensus (PoW,PoS, BFT)",
                "Présentation de différentes blockchain (Bitcoin, Ethereum, IOTA, HyperLedger, …)",
                "Conception de smart contract",
                "Expérimentation avec HyperLedger"
            ],
            "PREREQUIS": [],
            "CM": 8,
            "TD": 22,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Gil Utard",
                    "Wafa Badreddine"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "M1I_LOGIC",
            "TITRE": "LOGIQUE ET CONTRAINTES POUR LA DECISION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OASIS",
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Retour sur la théorie de complexité (Théorème de Cook)",
                "Satisfiabilité propositionnelle (SAT)",
                "Algorithmes de résolution: DPLL & CDCL",
                "Solveurs modernes et heuristiques",
                "Certification pour la décision",
                "Recherche locale pour la Satisfiabilité",
                "Encodages logiques et applications"
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "0.4 CC + 0.6 Examen [avec CC : partiel ou TD machine noté ou projet]",
                "SECONDE_CHANCE": "non",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Sami Cherif"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "M1I_SECUP",
            "TITRE": "SECURITE PROUVABLE ET ANONYMISATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Anonymisation des données",
                "Sécurité prouvable : modèles de sécurité, analyse calculatoire et symbolique de protocoles"
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Léo Robert",
                    "Gael Le Mahec"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "M1I_ROBOT",
            "TITRE": "ROBOTIQUE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OASIS",
                    "MODALITE": "obligatoire",
                    "ECTS": 4,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Modélisation des robots (bras anthropomorphe, robot mobile à pattes) : modèle géométrique, modèle cinématique",
                "Programmation des robots (ROS2 en simulation et sur robot réel) : locomotion, préhension, planification"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Jordan Caracotte"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "M1I_STAG1",
            "TITRE": "STAGE",
            "TYPE": "STAGE",
            "STATUT": [
                {
                    "PARCOURS": "OASIS",
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Stage 8 semaines"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "M1I_IAML",
            "TITRE": "IA ET MACHINE LEARNING",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 3,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "M1I_SECUA",
            "TITRE": "PROTOCOLES DE SECURITE AVANCES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "PKI, TLS, projet"
            ],
            "PREREQUIS": [],
            "CM": 8,
            "TD": 16,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 2,
            "ID": "M1I_BDAV",
            "TITRE": "BD AVANCEES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Transactions, opti, administration, NOSql"
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 1,
            "ID": "M1I_DEVOP",
            "TITRE": "METHODOLOGIE DEVOPS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "CI/CD, intégration continue"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                1,
                2
            ],
            "ID": "M1I_PP1",
            "TITRE": "PROJET PROFESSIONNEL 1",
            "TYPE": "STAGE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 15,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [
                "Stage long 20 semaines"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "M2I_ANG",
            "TITRE": "ANGLAIS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 0,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "M2I_MOBIL",
            "TITRE": "ALGORITHMIQUE MOBILE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OASIS",
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Introduction aux systèmes distribués mobiles et leurs principaux modèles.",
                "Protocoles fondamentaux (e.g., élection de leader, exploration, rassemblement, dispersion).",
                "Analyse des hypothèses, de la validité, de la complexité et des compromis associés.",
                "Tolérance aux fautes dans les systèmes mobiles (e.g., panne franches, pannes Byzantines, etc.)."
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "(CC1+CC2)/2",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Yoann Dieudonné"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "M2I_RO2",
            "TITRE": "RECHERCHE OPERATIONNELLE 2",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OASIS",
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Méthodes de décomposition, Ex. : Dantzig-Wolfe, Benders, Lagrangian",
                "Méthodes polyhédrales",
                "Programmation dynamique"
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "Examen 50% Projet 50%",
                "SECONDE_CHANCE": "non",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Rui Shibasaki",
                    "Corinne Lucet"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "M2I_TEMPO",
            "TITRE": "ACQUISITION ET TRAITEMENT DE DONNEES TEMPORELLES",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OASIS",
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Le module abordera des problématiques de recherche actuelles liées à l’acquisition et au traitement de données temporelles, avec application à la santé (données physiologiques, mouvement), à la musique (données symboliques, signal), ..."
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Florence Levé",
                    "David Durand"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "M2I_OPTIM",
            "TITRE": "LOGIQUE ET CONTRAINTES POUR L'OPTIMISATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OASIS",
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Satisfiabilité Maximum (MaxSAT)",
                "Algorithmes de résolution : algorithmes itératifs, séparation et évaluation",
                "Certification pour l'optimisation",
                "Recherche locale et approximation pour Max-SAT",
                "Autres extensions : MinSAT, #SAT et SMT",
                "Encodages logiques et applications"
            ],
            "PREREQUIS": [],
            "CM": 12,
            "TD": 18,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "0.4 CC + 0.6 Soutenance [avec CC : TD machine noté ou projet]",
                "SECONDE_CHANCE": "non",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Sami Cherif"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "M2I_QUANT",
            "TITRE": "ORDINATEUR QUANTIQUE ET CRYPTOGRAPHIE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OASIS",
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Cryptographie post-quantique (intro, lattices, codes), calcul quantique.], ..."
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "CC",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Léo Robert",
                    "Claire Delaplace"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "M2I_AUTON",
            "TITRE": "SYSTEME AUTONOME",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "OASIS",
                    "MODALITE": "obligatoire",
                    "ECTS": 6,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Intégration de capteurs de vision sur plateforme mobile",
                "Planification et interaction multi-robots",
                "Communication inter-robots"
            ],
            "PREREQUIS": [],
            "CM": 6,
            "TD": 24,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "projet (livrable + soutenance)",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [
                    "Jordan Caracotte",
                    "Pascal Vasseur"
                ],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "M2I_STAG2",
            "TITRE": "STAGE",
            "TYPE": "STAGE",
            "STATUT": [
                {
                    "PARCOURS": "OASIS",
                    "MODALITE": "obligatoire",
                    "ECTS": 23,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Stage 6 mois"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "M2I_PT1",
            "TITRE": "PROJET THEMATIQUE 1",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 4,
            "TD": 26,
            "TP": 0,
            "EFFECTIF": 15,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "M2I_PROSP",
            "TITRE": "PROJET DE SPECIALITE",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 4,
            "TD": 26,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "M2I_RESMO",
            "TITRE": "RESEAUX MOBILES ET SANS FIL",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Wifi, 5G, Lora"
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "M2I_SECU3",
            "TITRE": "ADMINISTRATION ET SECURISATION DES SE 3",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "M2I_CLOUD",
            "TITRE": "INFRASTRUCTURES CLOUD, VIRTUALISATION, CONTENEURISATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Virtualisation, cloud public"
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "M2I_CYBER",
            "TITRE": "CYBER : VULNERABILITES ET INVESTIGATIONS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "M2I_BACKB",
            "TITRE": "ARCHITECTURE RESEAU BACKBONE ET METROPOLITAIN",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 2,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Pentesting, hardening"
            ],
            "PREREQUIS": [],
            "CM": 30,
            "TD": 30,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "M2I_DEVOP",
            "TITRE": "METHODOLOGIE DEVSECOPS 2",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "Terraform, sécurité CI/CD, compliance"
            ],
            "PREREQUIS": [],
            "CM": 15,
            "TD": 15,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "M2I_MARCH",
            "TITRE": "MARCHES PROFESSIONNELS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [
                "Séminaires, insertion"
            ],
            "PREREQUIS": [],
            "CM": 30,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "M2I_PT2",
            "TITRE": "PROJET THEMATIQUE 2",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [
                "Gestiond de projet, cas pratique"
            ],
            "PREREQUIS": [],
            "CM": 4,
            "TD": 26,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "M2I_CTF",
            "TITRE": "CTF CRYPTABYSS",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "C1"
                }
            ],
            "CONTENU": [
                "CTF, sécurité offensive"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 3,
            "ID": "M2I_METHO",
            "TITRE": "METHODES DE PROGRAMMATION",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [
                "Événementiel, Design Pattern"
            ],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": 4,
            "ID": "M2I_IOT",
            "TITRE": "IOT",
            "TYPE": "UE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 1,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [],
            "PREREQUIS": [],
            "CM": 10,
            "TD": 20,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 1,
            "GROUPES_TD": 1,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        },
        {
            "SEMESTRE": [
                3,
                4
            ],
            "ID": "M2I_PP2",
            "TITRE": "PROJET PROFESSIONNEL 2",
            "TYPE": "STAGE",
            "STATUT": [
                {
                    "PARCOURS": "ISRI",
                    "MODALITE": "obligatoire",
                    "ECTS": 15,
                    "BLOCS": "CT"
                }
            ],
            "CONTENU": [
                "Stage long 20 semaines"
            ],
            "PREREQUIS": [],
            "CM": 0,
            "TD": 0,
            "TP": 0,
            "EFFECTIF": 0,
            "GROUPES_CM": 0,
            "GROUPES_TD": 0,
            "GROUPES_TP": 0,
            "M3C": {
                "SESSION_1": "",
                "SECONDE_CHANCE": "",
                "SESSION_2": ""
            },
            "ENSEIGNANTS": {
                "RESPONSABLES": [],
                "INTERVENANTS": []
            },
            "OBJECTIFS": []
        }
    ]
})